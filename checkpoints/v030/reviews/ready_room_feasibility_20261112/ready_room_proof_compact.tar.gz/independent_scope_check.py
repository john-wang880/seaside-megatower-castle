"""Read-only host topology/local-plane and protected-box feasibility checks."""
import pathlib,json,hashlib,collections,numpy as np
P=pathlib.Path(__file__).resolve().parent;raw=(P/'HOSTS.json').read_bytes();hosts=json.loads(raw)
G=np.array([[6.9,27.7,28.9],[14.1,32.6,32.15]],float)
room=np.array([[7,27.8,29],[14,32.4,32.05]],float);door=np.array([[8,32.4,29],[9.4,32.6,31.45]],float)
protected={'south_original_pier':[[10.6,34.6,29],[11.4,35.4,32.05]],'north_original_pier':[[10.6,38.2,29],[11.4,39,32.05]],'retained_roof_band':[[10.6,32.5,31.8],[11.4,40.5,32.05]],'S30_table_envelope':[[12,34.9,29],[13,35.5,30.006001]],'S11_cloak_stand':[[13.73,34.43,29],[14.37,35.07,30.77]]}
def overlap(a,b):return bool(np.all(np.minimum(a[1],b[1])-np.maximum(a[0],b[0])>0))
def clip(poly):
 p=[np.array(x)for x in poly]
 for axis in range(3):
  for bound,sign in [(G[0,axis],1),(G[1,axis],-1)]:
   q=[]
   for a,b in zip(p,p[1:]+p[:1]):
    da=(a[axis]-bound)*sign;db=(b[axis]-bound)*sign
    if da>=0:q.append(a)
    if (da<0)!=(db<0):q.append(a+(b-a)*da/(da-db))
   p=q
   if not p:return []
 return p
out={'hosts_sha256':hashlib.sha256(raw).hexdigest(),'host_checks':[],'protected_boxes':[]}
for o in hosts:
 v=np.array(o['vertices']);t=np.array(o['triangles']);edges=collections.Counter();direct=collections.Counter();nonaxis=[];local=0
 for i,row in enumerate(t):
  for a,b in zip(row,np.roll(row,-1)):edges[tuple(sorted((int(a),int(b))))]+=1;direct[int(a),int(b)]+=1
  poly=clip(v[row])
  if len(poly)>2:
   area=sum(np.linalg.norm(np.cross(poly[j]-poly[0],poly[j+1]-poly[0]))/2 for j in range(1,len(poly)-1))
   if area>0:
    local+=1
    if not any(np.max(v[row,axis])==np.min(v[row,axis])for axis in range(3)):nonaxis.append(i)
 out['host_checks'].append({'name':o['name'],'closed_edges':all(n==2 for n in edges.values()),'oriented_edges':all(direct[a,b]==direct[b,a]==1 for a,b in edges),'local_positive_area_triangles':local,'nonaxis_local_triangles':nonaxis})
for name,b in protected.items():
 b=np.array(b);out['protected_boxes'].append({'name':name,'room_overlaps':overlap(room,b),'door_overlaps':overlap(door,b),'guard_overlaps':overlap(G,b)})
out['plane_partition_preconditions_pass']=all(a['closed_edges'] and a['oriented_edges'] and not a['nonaxis_local_triangles'] for a in out['host_checks'])
out['protected_cavities_pass']=all(not a['room_overlaps'] and not a['door_overlaps'] for a in out['protected_boxes'])
out['scope']='Three supplied host mesh topology, exact-coordinate axis planarity of positive-area triangles clipped to proposed guard, and disjointness from named protected boxes. Does NOT prove host completeness, no additional containing solids/instances, self-intersection absence, route clearance, finite-cell occupancy, float32 integration or buildability. Roof-band guard overlap requires unchanged-occupancy preservation, not removal.'
(P/'INDEPENDENT_SCOPE.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
