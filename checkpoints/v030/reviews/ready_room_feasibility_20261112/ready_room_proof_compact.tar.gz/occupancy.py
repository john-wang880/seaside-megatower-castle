import json,pathlib,hashlib,itertools,numpy as np
P=pathlib.Path(__file__).resolve().parent
hosts=json.loads((P/'HOSTS.json').read_text()); local=json.loads((P/'LOCAL.json').read_text())
def f(x):return float(np.float32(x))
lo=np.array([f(x)for x in [6.85,27.65,28.85]]);hi=np.array([f(x)for x in [14.15,32.65,32.2]])
room=[[f(x)for x in [7,27.8,29]],[f(x)for x in [14,32.4,32.05]]];door=[[f(x)for x in [8,32.4,29]],[f(x)for x in [9.4,32.6,31.45]]]
# LOCAL used smaller box: recompute exhaustive triangle-AABB overlap for expanded guard.
tri=[];cuts=[{lo[i],hi[i],room[0][i],room[1][i],door[0][i],door[1][i]} for i in range(3)];summ=[]
for h in hosts:
 v=np.array(h['vertices']);t=v[np.array(h['triangles'])];n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);vol=np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6
 assert vol>0,(h['name'],vol)
 ix=np.all(t.max(axis=1)>=lo,axis=1)&np.all(t.min(axis=1)<=hi,axis=1)
 zero=np.count_nonzero(n,axis=1)==0; degenerate=int(zero.sum());ix=ix & ~zero
 assert np.all(np.count_nonzero(n[ix],axis=1)==1),'non-axis local triangle requires different partition'
 for a in t[ix]:
  for i in range(3):cuts[i].update(float(x)for x in a[:,i]if lo[i]<x<hi[i])
 tri.append(t[~zero]);summ.append({'name':h['name'],'signed_volume':vol,'local_triangles':int(ix.sum()),'zero_area_source_triangles_excluded':degenerate})
xs=[sorted(x)for x in cuts];assert all(all(b>a for a,b in zip(x,x[1:]))for x in xs)
def contains(t,p):
 q=t-p;a,b,c=q[:,0],q[:,1],q[:,2];la=np.linalg.norm(a,axis=1);lb=np.linalg.norm(b,axis=1);lc=np.linalg.norm(c,axis=1)
 det=np.einsum('ij,ij->i',a,np.cross(b,c));d=la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb
 w=np.arctan2(det,d).sum()/(2*np.pi);assert min(abs(w),abs(abs(w)-1))<1e-7,('ambiguous winding',w,p)
 return bool(abs(w)>.5)
cells=[];exc=0;void=0
for ids in itertools.product(*[range(len(x)-1)for x in xs]):
 a=np.array([xs[i][k]for i,k in enumerate(ids)]);b=np.array([xs[i][k+1]for i,k in enumerate(ids)]);p=(a+b)/2
 occ=[contains(t,p)for t in tri];cav=any(np.all(p>c[0])and np.all(p<c[1])for c in [room,door]);volume=float(np.prod(b-a));old=any(occ);new=old and not cav
 if cav:
  exc+=volume if old else 0;void+=volume if not old else 0
 cells.append({'index':ids,'source_inside':occ,'cavity':bool(cav),'retained_solid':new})
# Every retained non-door room wall must meet source solid immediately on outside.
# Inspect grid neighbours of cavity cells: retain original existing void at door exit, not manufacture walls.
cm={tuple(c['index']):c for c in cells};interfaces=[]
for c in cells:
 if not c['cavity']:continue
 for ax in range(3):
  for d in [-1,1]:
   j=list(c['index']);j[ax]+=d;q=cm.get(tuple(j))
   if q and not q['cavity'] and not q['retained_solid']:interfaces.append({'cell':c['index'],'axis':ax,'direction':d})
result={'source_sha256':local['source_sha256'],'hosts_sha256':hashlib.sha256((P/'HOSTS.json').read_bytes()).hexdigest(),'guard':[lo.tolist(),hi.tolist()],'cavities':[room,door],'axes':xs,'hosts':summ,'cells':cells,'excavated_volume':exc,'preexisting_void_in_cavity':void,'cavity_to_existing_void_interfaces':interfaces,'scope':'Closed oriented host-mesh winding classification on every finite axis-partition cell; float64 numeric classifications, not exact rational or structural certification. No candidate constructed.'}
(P/'OCCUPANCY.json').write_text(json.dumps(result,indent=2));print('cells',len(cells),'excavated',exc,'existing_void',void,'open interfaces',len(interfaces));print(interfaces[:20])
