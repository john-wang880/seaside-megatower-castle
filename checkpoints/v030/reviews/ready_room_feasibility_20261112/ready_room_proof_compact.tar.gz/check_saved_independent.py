import json,pathlib,hashlib,runpy,numpy as np
P=pathlib.Path(__file__).resolve().parent;N=P/'native'
for name in ['SAVED_GEOMETRY.json','RECEIPT.json','shell_candidate.blend']:assert (N/name).is_file(),name
G=json.loads((P/'GEOMETRY.json').read_text());S=json.loads((N/'SAVED_GEOMETRY.json').read_text());R=json.loads((N/'RECEIPT.json').read_text())
assert len(S)==len(G['meshes'])==4
for g,s in zip(G['meshes'],S):
 for k in ['name','vertices','faces']:assert g[k]==s[k],(s['name'],k)
assert hashlib.sha256((N/'shell_candidate.blend').read_bytes()).hexdigest()==R['candidate_sha256']
assert hashlib.sha256((P/'GEOMETRY.json').read_bytes()).hexdigest()==R['geometry_sha256']
# Re-run full pure geometry checks then independently classify triangles assembled from saved export.
q=runpy.run_path(str(P/'independent_geometry_check.py'));O=q['O'];axes=O['axes'];T=[q['fan'](np.array(s['vertices']),s['faces'])for s in S]
for c in O['cells']:
 p=np.array([(axes[a][k]+axes[a][k+1])/2 for a,k in enumerate(c['index'])]);assert any(q['inside'](t,p)for t in T)==c['retained_solid']
out={'saved_export_exact_to_reviewed_geometry':True,'bounded_cells_reclassified_from_saved_export':len(O['cells']),'candidate_sha256':R['candidate_sha256'],'source_sha256':R['source_sha256'],'status':'UNLIT SHELL CANDIDATE ONLY; not final architectural, lighting or functional acceptance','limitations':'Reads Blender re-export and receipt; source-complement and rollback performed by integrate.py, not independently re-opened in this check.'}
(N/'INDEPENDENT_SAVED_REVIEW.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
