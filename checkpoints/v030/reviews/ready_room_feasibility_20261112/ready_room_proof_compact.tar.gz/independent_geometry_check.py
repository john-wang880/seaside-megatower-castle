import json,pathlib,itertools,collections,numpy as np,hashlib
P=pathlib.Path(__file__).resolve().parent
G=json.loads((P/'GEOMETRY.json').read_text());O=json.loads((P/'OCCUPANCY.json').read_text());H=json.loads((P/'HOSTS.json').read_text());lo,hi=map(np.array,O['guard'])
def fan(v,faces):return np.array([[v[f[0]],v[b],v[c]]for f in faces for b,c in zip(f[1:],f[2:])])
def inside(t,p):
 a,b,c=(t-p).transpose(1,0,2);la,lb,lc=[np.linalg.norm(x,axis=1)for x in [a,b,c]];w=np.arctan2(np.einsum('ij,ij->i',a,np.cross(b,c)),la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb).sum()/(2*np.pi)
 assert min(abs(w),abs(abs(w)-1))<1e-7,(p,w)
 return abs(w)>.5
T=[];stats=[]
for m in G['meshes']:
 v=np.array(m['vertices']);t=fan(v,m['faces']);e=collections.Counter((a,b)for f in m['faces']for a,b in zip(f,f[1:]+f[:1]));assert all(n==1 and e[b,a]==1 for (a,b),n in e.items());vol=float(np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6);assert vol>0
 T.append(t);stats.append({'name':m['name'],'directed_closed':True,'signed_volume':vol})
# All candidate surfaces crossing guard are axis-aligned and confined to existing partition support planes.
axes=O['axes']
for t in T:
 q=t[np.all(t.max(1)>=lo,1)&np.all(t.min(1)<=hi,1)]
 for p in q:
  n=np.cross(p[1]-p[0],p[2]-p[0]);ax=np.flatnonzero(n)
  if not len(ax):continue
  assert len(ax)==1
  a=int(ax[0]);assert float(p[0,a])in axes[a],('new partition plane',a,p)
mis=[]
for c in O['cells']:
 p=np.array([(axes[a][k]+axes[a][k+1])/2 for a,k in enumerate(c['index'])]);actual=any(inside(t,p)for t in T)
 if actual!=c['retained_solid']:mis.append(c['index'])
assert not mis
# Face domain verification independent polygon clipping.
def area(p):return abs(sum(np.cross(a,b) for a,b in zip(p,p[1:]+p[:1])))/2 if len(p)>2 else 0.
def clipline(p,a,b):
 out=[]
 for x,y in zip(p,p[1:]+p[:1]):
  dx=float(np.cross(b-a,x-a));dy=float(np.cross(b-a,y-a));ix=dx>=0;iy=dy>=0
  if ix:out.append(x)
  if ix!=iy:out.append(x+(y-x)*dx/(dx-dy))
 return out
 def_unused=0
def intersect(p,q):
 if sum(np.cross(a,b)for a,b in zip(q,q[1:]+q[:1]))<0:q=q[::-1]
 for a,b in zip(q,q[1:]+q[:1]):
  p=clipline(p,a,b)if p else []
 return p
remote=0;domains=[]
for h,m in zip(H,G['meshes']):
 vv=np.array(h['vertices']);nv=np.array(m['vertices']);groups=collections.defaultdict(list)
 for f,l in zip(m['faces'],m['face_lineage']):
  if l['kind']=='remote_original':
   assert nv[f].tolist()==vv[h['faces'][l['source_face']]].tolist();remote+=1
  elif l['kind']=='clipped_source_domain':groups[l['source_face']].append(nv[f])
 for fid,polys in groups.items():
  original=vv[h['faces'][fid]];a=next(i for i in range(3)if np.ptp(original[:,i])==0);uv=[i for i in range(3)if i!=a];orig=[list(vv[t][:,uv])for t in h['triangles']if set(t)<=set(h['faces'][fid])];actual=[list(p[:,uv])for p in polys]
  # guard intersection on face plane is a rectangle, subtract its area from source.
  rect=[np.array(x)for x in [(lo[uv[0]],lo[uv[1]]),(hi[uv[0]],lo[uv[1]]),(hi[uv[0]],hi[uv[1]]),(lo[uv[0]],hi[uv[1]])]]
  expected=sum(area(p)-area(intersect(p,rect)) for p in orig)
  got=sum(area(p)for p in actual);assert abs(got-expected)<1e-4,(fid,got,expected)
  for p in actual:
   assert area(intersect(p,rect))<1e-4
   covered=sum(area(intersect(p,q))for q in orig);assert abs(covered-area(p))<1e-4
  overlap=sum(area(intersect(p,q))for i,p in enumerate(actual)for q in actual[i+1:]);assert overlap<1e-4
  domains.append({'host':h['name'],'face':fid,'expected_area':float(expected),'actual_area':float(got),'area_error':float(got-expected),'overlap_area':float(overlap)})
# no source face omitted without being wholly inside guard
for h,m in zip(H,G['meshes']):
 covered={l['source_face'] for l in m['face_lineage']if 'source_face'in l}
 for i,f in enumerate(h['faces']):
  if i not in covered:
   v=np.array(h['vertices'])[f];assert np.all(v>=lo)and np.all(v<=hi),(h['name'],i)
report={'geometry_sha256':hashlib.sha256((P/'GEOMETRY.json').read_bytes()).hexdigest(),'meshes':stats,'partition_cells_checked':len(O['cells']),'occupancy_mismatches':mis,'exact_remote_face_cycles':remote,'affected_domains':domains,'scope':'Pure JSON candidate review. Existing guard partition exhaustively matches planned old union minus cavities; outside source cycles and clipped domains verified. Directed closure not a general self-intersection proof; saved Blender candidate still requires re-export and validation.'}
report.update(clipped_domain_area_tolerance=1e-4,max_clipped_domain_area_error=max(abs(x['area_error'])for x in domains),max_domain_overlap_area=max(x['overlap_area']for x in domains),clipped_domain_note='Float32 intersections allow small area differences; remote cycles exact, clipped domains not bit-exact.')
(P/'INDEPENDENT_GEOMETRY.json').write_text(json.dumps(report,indent=2));print('PASS',len(O['cells']),remote,len(domains))
