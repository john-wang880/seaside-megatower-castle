import bpy,sys,json,pathlib,hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=pathlib.Path(__file__).resolve().parent;src=pathlib.Path(sys.argv[-1]);assert hashlib.sha256(src.read_bytes()).hexdigest()=='a6c9715064ae0ea8ee58f369f46ceb3352bfc84fb53687b30bffd35bf38bd9ce'
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False);dg=bpy.context.evaluated_depsgraph_get();low=(6.8,27.6,28.8);high=(14.2,32.7,32.25);out=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or o.hide_render:continue
 name=o.name
 e=o.evaluated_get(dg);m=e.to_mesh();m.calc_loop_triangles();vv=[e.matrix_world@v.co for v in m.vertices]
 if not vv or any(max(v[i]for v in vv)<[8.1,30,29.025][i] or min(v[i]for v in vv)>[9.3,38.1,31.1][i]for i in range(3)):e.to_mesh_clear();continue
 out.append({'name':name,'vertices':[list(e.matrix_world@v.co)for v in m.vertices],'triangles':[list(t.vertices)for t in m.loop_triangles],'faces':[list(p.vertices)for p in m.polygons],'modifiers':[x.type for x in o.modifiers],'vertex_groups':[x.name for x in o.vertex_groups],'users':o.data.users,'materials':[x.name if x else None for x in m.materials]});e.to_mesh_clear()
(P/'ROUTE_OBJECTS.json').write_text(json.dumps(out))
