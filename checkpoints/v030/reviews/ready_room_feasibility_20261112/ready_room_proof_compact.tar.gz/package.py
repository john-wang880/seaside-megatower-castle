import pathlib,tarfile,json,hashlib
P=pathlib.Path(__file__).resolve().parent
omitted=['ALL_LOCAL_OBJECTS.json','ROUTE_OBJECTS.json','native/shell_candidate.blend']
(P/'REGENERATE.json').write_text(json.dumps({'source_model_sha256':'a6c9715064ae0ea8ee58f369f46ceb3352bfc84fb53687b30bffd35bf38bd9ce','omitted_reproducible_outputs':{n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in omitted},'order':['Blender export_all.py SOURCE.blend','python components.py','python occupancy.py','python build_geometry.py','python independent_geometry_check.py','Blender integrate.py SOURCE.blend','Blender check_native.py SOURCE.blend','python check_saved_independent.py'],'note':'Unaccepted unlit shell research only. Export scripts are Blender background Python scripts with source path last. Do not overwrite accepted S30.'},indent=2))
files=[x for x in P.rglob('*')if x.is_file() and x.suffix in ['.py','.json','.md','.png'] and x.name!='CHECKSUMS.json'and '__pycache__'not in x.parts and str(x.relative_to(P))not in omitted]
(P/'CHECKSUMS.json').write_text(json.dumps({str(x.relative_to(P)):hashlib.sha256(x.read_bytes()).hexdigest()for x in files},indent=2));files.append(P/'CHECKSUMS.json')
with tarfile.open(P.parent/'ready_room_proof_compact.tar.gz','w:gz')as t:
 for f in files:t.add(f,arcname=str(f.relative_to(P)))
f=P.parent/'ready_room_proof_compact.tar.gz';print(f.stat().st_size,hashlib.sha256(f.read_bytes()).hexdigest())
