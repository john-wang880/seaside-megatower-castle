import json,pathlib,itertools,numpy as np,hashlib
P=pathlib.Path(__file__).resolve().parent
O=json.loads((P/'OCCUPANCY.json').read_text()); H=json.loads((P/'HOSTS.json').read_text()); C=json.loads((P/'COMPONENTS.json').read_text())
tri=[np.array(h['vertices'])[h['triangles']] for h in H]
def inside(t,p):
 a,b,c=(t-p).transpose(1,0,2); la,lb,lc=[np.linalg.norm(x,axis=1) for x in [a,b,c]]
 w=np.arctan2(np.einsum('ij,ij->i',a,np.cross(b,c)),la*lb*lc+np.einsum('ij,ij->i',a,b)*lc+np.einsum('ij,ij->i',b,c)*la+np.einsum('ij,ij->i',c,a)*lb).sum()/(2*np.pi)
 assert min(abs(w),abs(abs(w)-1))<1e-7,(p,w)
 return abs(w)>.5
cav=O['cavities']
def cut(p):return any(np.all(p>r[0])and np.all(p<r[1]) for r in cav)
def classify_box(lo,hi):
 lo=np.array(lo);hi=np.array(hi);cuts=[{lo[i],hi[i]} for i in range(3)]
 for r in cav:
  for i in range(3):cuts[i].update(x[i]for x in r if lo[i]<x[i]<hi[i])
 for t in tri:
  q=t[np.all(t.max(1)>=lo,1)&np.all(t.min(1)<=hi,1)];n=np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]);q=q[np.any(n!=0,1)];n=n[np.any(n!=0,1)]
  assert np.all(np.count_nonzero(n,axis=1)==1),'nonaxis surface'
  for i in range(3):cuts[i].update(float(x)for x in q[:,:,i].flatten()if lo[i]<x<hi[i])
 axes=[sorted(x)for x in cuts];n=0;remaining=0.;old=0.
 for j in itertools.product(*[range(len(x)-1)for x in axes]):
  a=np.array([axes[i][k]for i,k in enumerate(j)]);b=np.array([axes[i][k+1]for i,k in enumerate(j)]);p=(a+b)/2;v=float(np.prod(b-a));occ=any(inside(t,p)for t in tri);n+=1
  old+=v if occ else 0;remaining+=v if occ and not cut(p) else 0
 return dict(cells=n,box=[lo.tolist(),hi.tolist()],source_occupied_volume=old,planned_remaining_occupied_volume=remaining,total_volume=float(np.prod(hi-lo)))
route=classify_box([8.1,30,29.025],[9.3,38.1,31.1]);floor=classify_box([8.1,30,28.99],[9.3,38.1,29])
def clip(poly,axis,bound,sign):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=sign*(a[axis]-bound)>=0;ib=sign*(b[axis]-bound)>=0
  if ia:out.append(a)
  if ia!=ib:out.append(a+(b-a)*((bound-a[axis])/(b[axis]-a[axis])))
 return out
terrain=[]
for o in C:
 if not o['name'].startswith('V010'):continue
 for t in np.array(o['vertices'])[o['triangles']]:
  p=list(t)
  for ax,l,h in [(0,7,14),(1,27.8,32.4)]:
   p=clip(p,ax,l,1)if p else [];p=clip(p,ax,h,-1)if p else []
  if len(p)>=3:terrain.extend(x[2]for x in p)
interfaces=[]
for e in O['cavity_to_existing_void_interfaces']:
 ids=e['cell'];lo=[O['axes'][i][j]for i,j in enumerate(ids)];hi=[O['axes'][i][j+1]for i,j in enumerate(ids)];interfaces.append(dict(**e,cell_bounds=[lo,hi]))
r={'route':route,'floor_thin_slab':floor,'terrain_clipped_z_extrema':[min(terrain),max(terrain)],'open_interfaces':interfaces,'instance_scope':json.loads((P/'INSTANCE_SCOPE.json').read_text()),'components':[{k:o[k] for k in ['name','guard','route','closed_edges']}for o in C],'scope':'Independent finite axis-cell winding of existing three closed hosts minus proposed cavities. Route above floor only, floor evaluated separately. Not saved-candidate validation or structural/human-use certification.'}
(P/'INDEPENDENT_ROUTE.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
