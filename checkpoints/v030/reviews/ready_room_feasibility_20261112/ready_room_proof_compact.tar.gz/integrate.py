import bpy,sys,pathlib,json,hashlib
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P));import snapshot_support as sn
src=pathlib.Path(sys.argv[-1]);assert hashlib.sha256(src.read_bytes()).hexdigest()=='a6c9715064ae0ea8ee58f369f46ceb3352bfc84fb53687b30bffd35bf38bd9ce'
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
hosts=json.loads((P/'HOSTS.json').read_text());g=json.loads((P/'GEOMETRY.json').read_text());assert g['pass'];before=sn.snap();cs=sn.collections_snapshot();targets={h['name'] for h in hosts};tn={bpy.data.objects[n].data.name for n in targets};raw={n:sn.mesh_snapshot(bpy.data.objects[n].data,ignore_owned_weights=True)for n in targets}
assert not any(n.name.startswith('S31 |')for n in bpy.data.objects)
col=bpy.data.collections.new('S31 | reversible readiness room');bpy.context.scene.collection.children.link(col)
for m in g['meshes']:
 me=bpy.data.meshes.new(m['name']);me.from_pydata(m['vertices'],[],m['faces']);me.update();me.materials.append(bpy.data.materials['Citadel • weathered limestone']);o=bpy.data.objects.new(m['name'],me);col.objects.link(o)
 assert [list(v.co)for v in me.vertices]==m['vertices'];assert [list(p.vertices)for p in me.polygons]==m['faces']
def controls(add):
 for n in targets:
  o=bpy.data.objects[n]
  if add:
   assert not o.modifiers and not o.vertex_groups
   gr=o.vertex_groups.new(name='S31 preserved source');gr.add(list(range(len(o.data.vertices))),1,'REPLACE');mod=o.modifiers.new('S31 reversible room mask','MASK');mod.vertex_group=gr.name;mod.invert_vertex_group=True
  else:o.modifiers.remove(o.modifiers['S31 reversible room mask']);o.vertex_groups.remove(o.vertex_groups['S31 preserved source'])
 bpy.context.view_layer.update()
controls(True);after=sn.snap()
for c,old in before.items():
 if isinstance(old,dict):
  ex=targets if c in ['objects','visible_evaluated'] else tn if c=='meshes' else set()
  assert all(after[c].get(k)==v for k,v in old.items()if k not in ex),c
 else:assert after[c]==old,c
for n in targets:assert sn.mesh_snapshot(bpy.data.objects[n].data,ignore_owned_weights=True)==raw[n]
controls(False);rb=sn.snap()
for c,old in before.items():
 if isinstance(old,dict):assert all(rb[c].get(k)==v for k,v in old.items()),c
 else:assert rb[c]==old,c
controls(True);newcs=sn.collections_snapshot();assert all(newcs['collections'][k]==v for k,v in cs['collections'].items())
(P/'native').mkdir(exist_ok=True);out=P/'native/shell_candidate.blend';assert not out.exists();bpy.ops.wm.save_as_mainfile(filepath=str(out),compress=True)
bpy.ops.wm.open_mainfile(filepath=str(out),use_scripts=False);saved=[]
for m in g['meshes']:
 o=bpy.data.objects[m['name']];assert [list(v.co)for v in o.data.vertices]==m['vertices'];assert [list(p.vertices)for p in o.data.polygons]==m['faces'];saved.append({'name':o.name,'vertices':[list(v.co)for v in o.data.vertices],'faces':[list(p.vertices)for p in o.data.polygons]})
for n in targets:
 o=bpy.data.objects[n];e=o.evaluated_get(bpy.context.evaluated_depsgraph_get());me=e.to_mesh();assert len(me.vertices)==0;e.to_mesh_clear()
(P/'native/SAVED_GEOMETRY.json').write_text(json.dumps(saved));(P/'native/RECEIPT.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'geometry_sha256':hashlib.sha256((P/'GEOMETRY.json').read_bytes()).hexdigest(),'old_complement_preserved':True,'rollback_pass':True,'saved_geometry_exact':True,'status':'UNLIT SHELL CANDIDATE ONLY, not accepted version'},indent=2))
