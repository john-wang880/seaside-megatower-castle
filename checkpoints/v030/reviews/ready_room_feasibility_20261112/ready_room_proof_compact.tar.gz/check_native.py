import bpy,sys,pathlib,json,hashlib
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P));import snapshot_support as sn
src=pathlib.Path(sys.argv[-1]);r=json.loads((P/'native/RECEIPT.json').read_text());assert hashlib.sha256(src.read_bytes()).hexdigest()==r['source_sha256'];bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False);old=sn.snap();cs=sn.collections_snapshot();targets={x['name']for x in json.loads((P/'HOSTS.json').read_text())};meshes={bpy.data.objects[n].data.name for n in targets};raw={n:sn.mesh_snapshot(bpy.data.objects[n].data,ignore_owned_weights=True)for n in targets}
bpy.ops.wm.open_mainfile(filepath=str(P/'native/shell_candidate.blend'),use_scripts=False);new=sn.snap()
for c,v in old.items():
 if isinstance(v,dict):
  ex=targets if c in ['objects','visible_evaluated']else meshes if c=='meshes'else set();assert all(new[c].get(k)==a for k,a in v.items()if k not in ex),c
 else:assert new[c]==v,c
for n in targets:
 o=bpy.data.objects[n];assert sn.mesh_snapshot(o.data,ignore_owned_weights=True)==raw[n];assert len(o.modifiers)==1 and o.modifiers[0].type=='MASK' and o.modifiers[0].invert_vertex_group
ncs=sn.collections_snapshot();assert all(ncs['collections'][k]==v for k,v in cs['collections'].items());assert ncs['root_objects']==cs['root_objects'];assert set(ncs['root_children'])==set(cs['root_children'])|{'S31 | reversible readiness room'}
(P/'native/PRESERVATION.json').write_text(json.dumps({'candidate_sha256':r['candidate_sha256'],'source_complement_saved_reopen_pass':True,'target_raw_geometry_materials_preserved_except_owned_weights':True,'original_collections_preserved':True,'scope':'snapshot-supported categories, target masks explicitly exempted only for evaluated/object and weights differences'},indent=2))
