import json,pathlib,numpy as np,collections
P=pathlib.Path(__file__).resolve().parent
out=[]
for o in json.loads((P/'ALL_LOCAL_OBJECTS.json').read_text()):
 vv=np.array(o['vertices']);par=list(range(len(vv)))
 def root(x):
  while par[x]!=x:par[x]=par[par[x]];x=par[x]
  return x
 for face in o['faces']:
  for j in face[1:]:par[root(j)]=root(face[0])
 gs=collections.defaultdict(list)
 for i in range(len(vv)):gs[root(i)].append(i)
 fs=collections.defaultdict(list);ts=collections.defaultdict(list)
 for face in o['faces']:fs[root(face[0])].append(face)
 for tri in o['triangles']:ts[root(tri[0])].append(tri)
 for k,ids in gs.items():
  v=vv[ids];lo=v.min(axis=0);hi=v.max(axis=0)
  guard=bool(np.all(hi>=[6.85,27.65,28.85])and np.all(lo<=[14.15,32.65,32.2]));route=bool(np.all(hi>=[8.1,30,29.025])and np.all(lo<=[9.3,38.1,31.1]))
  if not(guard or route):continue
  m={i:j for j,i in enumerate(ids)};faces=[[m[i]for i in f]for f in fs[k]];tris=[[m[i]for i in f]for f in ts[k]];edge=collections.Counter(tuple(sorted((a,b)))for f in faces for a,b in zip(f,f[1:]+f[:1]));out.append({'name':o['name'],'component':k,'guard':guard,'route':route,'min':lo.tolist(),'max':hi.tolist(),'closed_edges':bool(edge)and all(n==2 for n in edge.values()),'vertices':v.tolist(),'faces':faces,'triangles':tris})
(P/'COMPONENTS.json').write_text(json.dumps(out));print([(o['name'],o['component'],len(o['vertices']),o['guard'],o['route'],o['closed_edges'])for o in out])
