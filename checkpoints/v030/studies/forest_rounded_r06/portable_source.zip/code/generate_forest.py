#!/usr/bin/env python3
"""Deterministic CPU-only forest bough meshes, frozen r01 axes and exact envelopes.

No Blender, rendering, scene mutation, shader mutation, or whole-crown convex hull.
Every emitted coordinate is an IEEE754 binary32 value represented losslessly in JSON.
Original stem vertex slots and face index triples are retained exactly.
"""
from __future__ import annotations
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import struct
import numpy as np

HERE = Path(__file__).resolve().parent
DEFAULT_INPUT = HERE.parents[1] / 'recovery_20261102/r01/reproduce/forest/inputs'
COUNTS = {'low': 9, 'narrow': 10, 'broad': 12}
DISTRIBUTION = {'low': (12, 16), 'narrow': (5, 17, 8), 'broad': (3, 7, 2)}
REPRESENTATIVES = ['source_axis_27970','source_axis_17660']
FACE_ROLES = {'root_stem': 0, 'woody_continuation': 1, 'slender_leader': 2,
              'bough_inner_cap': 3, 'bough_side': 4, 'bough_outer_cap': 5}
ALGORITHM = 'frozen-r01-irregular-spindles-v1'
REVISION = 'upper-r02-two-overlapping-swept-boughs'
MASS_REVISION = 'r06-rounded-three-ring-convex-clusters-shortened-narrow-crown'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def f32(a):
    return np.asarray(a, dtype=np.float32).astype(np.float64)


def stable_rng(seed, tree_id):
    # Defined hash stream, independent of Python hash randomization / NumPy PRNG.
    counter = 0
    while True:
        b = hashlib.sha256(f'{ALGORITHM}|{seed}|{tree_id}|{counter}'.encode()).digest()
        counter += 1
        for i in range(0, 32, 8):
            yield int.from_bytes(b[i:i+8], 'big') / 2**64


def signed_volume(v, faces):
    v = np.asarray(v, dtype=float)
    q = v - v.mean(axis=0)
    t = q[np.asarray(faces, dtype=int)]
    return float(np.einsum('ij,ij->i', t[:,0], np.cross(t[:,1],t[:,2])).sum()/6)


def planes(v, faces):
    t = np.asarray(v, dtype=float)[np.asarray(faces, dtype=int)]
    n = np.cross(t[:,1]-t[:,0], t[:,2]-t[:,0])
    length = np.linalg.norm(n, axis=1)
    if np.any(length == 0):
        raise ValueError('Degenerate plane')
    return n / length[:,None], t[:,0]


def inward_margin(v, faces, point):
    n, origins = planes(v, faces)
    return float(np.min(-np.einsum('ij,ij->i', n, np.asarray(point)-origins)))


def spindle_faces(n):
    """Rings 0..n-1 and n..2n-1; inner and outer poles 2n, 2n+1."""
    faces = []
    roles = []
    for i in range(n):
        j = (i+1) % n
        faces += [(2*n,j,i)]
        roles += [FACE_ROLES['bough_inner_cap']]
    for i in range(n):
        j = (i+1) % n
        faces += [(i,j,n+j),(i,n+j,n+i)]
        roles += [FACE_ROLES['bough_side']]*2
    for i in range(n):
        j = (i+1) % n
        faces += [(n+i,n+j,2*n+1)]
        roles += [FACE_ROLES['bough_outer_cap']]
    return faces, roles


def oriented(v, faces):
    if signed_volume(v, faces) < 0:
        return [(a,c,b) for a,b,c in faces]
    return [tuple(f) for f in faces]


class Envelope:
    """Consecutive actual source slabs, not a global convex envelope.

    A slab's side planes are the planes of *both actual triangles* of each
    source quad. Their intersection is a conservative core of that closed
    frustum, including its binary32 triangulation imperfections. Testing each
    horizontally clipped emitted triangle against all these planes proves
    the whole triangle lies in the actual source crown, not just its vertices.
    """
    def __init__(self, candidate):
        self.cv = candidate['crown_vertex_count']
        self.vertices = np.asarray(candidate['vertices'][:self.cv], dtype=float)
        self.zs = sorted(set(self.vertices[:,2]))
        self.rings = [self.vertices[self.vertices[:,2] == z] for z in self.zs]
        self.centers = [r.mean(axis=0) for r in self.rings]
        self.height = self.zs[-1] - self.zs[0]
        self.cells = []
        for lo,hi in zip(self.zs,self.zs[1:]):
            fs = [f for f in candidate['triangles'] if max(f)<self.cv
                  and min(self.vertices[f,2]) == lo and max(self.vertices[f,2]) == hi]
            n, o = planes(self.vertices, fs)
            midpoint = (self.center(lo) + self.center(hi))/2
            assert np.all(np.einsum('ij,ij->i', n, midpoint-o) < 0)
            self.cells.append({'lo':lo, 'hi':hi, 'faces':fs, 'n':n, 'o':o})

    def center(self, z):
        i = min(max(np.searchsorted(self.zs,z,side='right')-1,0),len(self.zs)-2)
        t = (z-self.zs[i])/(self.zs[i+1]-self.zs[i])
        return self.centers[i]*(1-t)+self.centers[i+1]*t

    def cell_margin(self, i, p):
        c=self.cells[i]
        return min(p[2]-c['lo'], c['hi']-p[2],
                   float(np.min(-np.einsum('ij,ij->i',c['n'],p-c['o']))))

    def shrink_into_cell(self, vertices, anchor, cell, safety=0.965):
        c=self.cells[cell]
        n=np.vstack((c['n'],[0,0,-1],[0,0,1]))
        o=np.vstack((c['o'],[0,0,c['lo']],[0,0,c['hi']]))
        room=-np.einsum('ij,ij->i',n,anchor-o)
        assert min(room)>0
        delta=(np.asarray(vertices)-anchor)@n.T
        limits=np.where(delta>0,room/np.maximum(delta,1e-300),np.inf)
        scale=min(1.0,float(np.min(limits))*safety)
        return f32(anchor+(np.asarray(vertices)-anchor)*scale),scale

    def float_contains(self, vertices, faces, atol=1e-9):
        """Development precheck only. Final certificate is exact integer arithmetic."""
        v=np.asarray(vertices)
        for f in faces:
            t=v[list(f)]
            for c in self.cells:
                if max(t[:,2])<c['lo'] or min(t[:,2])>c['hi']:
                    continue
                pts=clipped_points(t,c['lo'],c['hi'])
                if len(pts) and np.max(np.einsum('pki,ki->pk',np.asarray(pts)[:,None,:]-c['o'],c['n']))>atol:
                    return False
        return min(v[:,2])>=self.zs[0]-atol and max(v[:,2])<=self.zs[-1]+atol


def clipped_points(triangle,lo,hi):
    pts=[p for p in triangle if lo<=p[2]<=hi]
    for p,q in ((triangle[0],triangle[1]),(triangle[1],triangle[2]),(triangle[2],triangle[0])):
        if p[2]>q[2]:p,q=q,p
        if q[2]>p[2]:
            for z in (lo,hi):
                if p[2]<z<q[2]:pts.append(p+(q-p)*((z-p[2])/(q[2]-p[2])))
    return pts


def prism(bottom, top, r0, r1, angle):
    vs=[]
    for center,r in ((bottom,r0),(top,r1)):
        for k in range(4):
            a=angle+2*math.pi*k/4
            vs.append(np.asarray(center)+[r*math.cos(a),r*math.sin(a),0])
    fs=[]
    for i in range(4):
        j=(i+1)%4
        fs.extend([(i,j,4+j),(i,4+j,4+i)])
    fs += [(0,2,1),(0,3,2),(4,5,6),(4,6,7)]
    vs=f32(vs)
    return vs,oriented(vs,fs)


def lerp_z(a,b,z):
    return a+(b-a)*((z-a[2])/(b[2]-a[2]))


def leader(bottom, top, radius, angle):
    vs=[]
    for t,r in ((0.23,radius),(0.64,radius*0.47)):
        center=bottom*(1-t)+top*t
        for k in range(3):
            a=angle+2*math.pi*k/3
            vs.append(center+[r*math.cos(a),r*math.sin(a),0])
    vs += [bottom,top]
    vs=f32(vs)
    fs,_=spindle_faces(3)
    return vs,oriented(vs,fs)


def bough(anchor, angle, radius, dz, rand, massive=False):
    """Narrow tapered branchlet, biased upward, not a whole-crown tier."""
    u=np.array([math.cos(angle),math.sin(angle),0.])
    side=np.array([-u[1],u[0],0.]); up=np.array([0.,0.,1.])
    width=radius*(0.22+0.08*next(rand))
    thickness=dz*(0.18+0.055*next(rand))
    phase=next(rand)*math.pi*2
    rise=dz*(0.08+0.06*next(rand))
    vs=[]
    for x,side_scale,height_scale,shift in ((0.20,0.82,0.78,-0.035),(0.64,0.46,0.58,0.035)):
        center=anchor+u*(radius*x)+up*(rise*x)+side*(width*shift)
        for k in range(5):
            a=phase+2*math.pi*k/5
            vs.append(center+side*(width*side_scale*math.cos(a))+up*(thickness*height_scale*math.sin(a)))
    vs.append(anchor-u*(radius*0.17)+side*(0.02*width)-up*(0.035*thickness))
    vs.append(anchor+u*(radius*(0.94+0.035*next(rand))) - side*(0.055*width)+up*rise)
    fs,rs=spindle_faces(5)
    return np.asarray(vs),oriented(vs,fs),rs


def swept_upper_bough(env, anchor, angle, index, original_vertices, previous_anchor):
    """Replace only the two terminal-cell boughs, retaining 12v/20t topology.

    Their original short lateral shape left disjoint foliage-height bands.
    Two unequal, leaning closed spindles now overlap along the living leader.
    The first straddles the actual shoulder; all triangles are subsequently
    certified against the actual source slabs. The original random draws are
    still consumed, so every preceding component remains byte-identical.
    """
    h=env.height; z0=env.zs[0]; shoulder=(env.zs[-2]-z0)/h
    previous_fraction=(previous_anchor[2]-z0)/h
    if index==0:
        low,high=previous_fraction-0.035,0.885
        ring_fractions=(previous_fraction+0.006,0.795)
    else:
        low,high=0.785,0.980
        ring_fractions=(low+(high-low)*0.24,low+(high-low)*0.65)
    u=np.array([math.cos(angle),math.sin(angle),0.])
    side=np.array([-u[1],u[0],0.])
    # Retain the source bough's deterministic unequal shape through its side
    # imbalance, but use oblique cross-sections, never full radial crown tiers.
    raw=np.asarray(original_vertices)-anchor
    asym=float(np.clip(np.mean(raw[:5]@side)/(np.max(np.abs(raw@side))+1e-15),-.15,.15))
    phase=0.31+0.37*math.sin(angle)+asym
    vs=[]
    for fraction,fullness,lean in ((ring_fractions[0],0.73,0.17),(ring_fractions[1],0.79,0.20)):
        z=z0+h*fraction
        axis=env.center(z)
        cell=next(c for c in env.cells if c['lo']<=z<=c['hi'])
        room=-np.einsum('ij,ij->i',cell['n'],axis-cell['o'])
        horizontal=np.linalg.norm(cell['n'][:,:2],axis=1)
        radius=float(np.min(room/horizontal))
        center=axis+u*(radius*lean)+side*(radius*asym)
        for k in range(5):
            a=phase+2*math.pi*k/5
            # A fixed affine tilt of each cross-section produces oblique
            # unequal lobes, while the retained azimuth supplies side bias.
            delta=(u*math.cos(a)+side*math.sin(a))*(radius*fullness)
            delta[2]=h*(high-low)*0.040*(0.65*math.cos(a)+math.sin(a))
            vs.append(center+delta)
    for fraction,lean in ((low,0.025),(high,0.035)):
        z=z0+h*fraction; axis=env.center(z)
        vs.append(axis+u*(h*lean*(1-fraction)))
    fs,rs=spindle_faces(5)
    vs=f32(vs);fs=oriented(vs,fs)
    # Preserve the designed height span. A transverse-only fit is sufficient
    # if a skewed source envelope needs additional room; never shorten a tip.
    for attempt in range(16):
        if env.float_contains(vs,fs):break
        fitted=[]
        for p in vs:
            center=env.center(p[2]);q=center+(p-center)*np.array([.94,.94,1.])
            fitted.append(q)
        vs=f32(fitted);fs=oriented(vs,fs)
    else:raise AssertionError('Swept upper bough cannot fit exact source envelope')
    return vs,fs,rs,{'upper_revision':REVISION,
                     'designed_height_interval':[low,high],
                     'transverse_fit_scale':.94**attempt}


def _integer_coordinates(source, vertices):
    allv=[list(map(float,p)) for p in source]+[list(map(float,p)) for p in vertices]
    denominators=[x.as_integer_ratio()[1] for p in allv for x in p]
    scale=max(denominators)  # Powers of two: exact common denominator.
    ints=[[x.as_integer_ratio()[0]*(scale//x.as_integer_ratio()[1]) for x in p] for p in allv]
    return ints[:len(source)],ints[len(source):],scale


def _sub(a,b):return [a[i]-b[i] for i in range(3)]
def _cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def _dot(a,b):return sum(x*y for x,y in zip(a,b))


def exact_triangle_certificate(envelope, vertices, faces):
    """Exact binary32-rational certificate, including crossings of every slab.

    Plane determinants and horizontal-edge interpolation numerators are Python
    integers. No tolerance, sample points, hull substitute, or float predicate.
    Each clipped triangle is convex; a linear plane inequality at all its
    vertices certifies its entire filled surface. Slab boundary points are
    checked in both adjacent cells, conservatively retaining both surfaces.
    """
    old,new,scale=_integer_coordinates(envelope.vertices,vertices)
    cells=[]
    for c in envelope.cells:
        lo=int(float(c['lo'])*scale);hi=int(float(c['hi'])*scale)
        ps=[]
        for a,b,d in c['faces']:
            normal=_cross(_sub(old[b],old[a]),_sub(old[d],old[a]))
            ps.append((normal,_dot(normal,old[a])))
        cells.append((lo,hi,ps))
    count=0; slices=0
    for fi,f in enumerate(faces):
        t=[new[i] for i in f]
        if min(p[2] for p in t)<cells[0][0] or max(p[2] for p in t)>cells[-1][1]:
            raise AssertionError(f'Triangle {fi}: outside crown height')
        for ci,(lo,hi,ps) in enumerate(cells):
            if max(p[2] for p in t)<lo or min(p[2] for p in t)>hi:continue
            slices+=1
            for normal,offset in ps:
                ds=[_dot(normal,p)-offset for p in t]
                for p,d in zip(t,ds):
                    if lo<=p[2]<=hi:
                        count+=1
                        if d>0:raise AssertionError(f'Triangle {fi}, slab {ci}: original vertex outside facet')
                for i,j in ((0,1),(1,2),(2,0)):
                    if t[i][2]>t[j][2]:i,j=j,i
                    zi,zj=t[i][2],t[j][2]
                    if zi==zj:continue
                    for z in (lo,hi):
                        if zi<z<zj:
                            count+=1
                            numerator=(zj-z)*ds[i]+(z-zi)*ds[j]
                            if numerator>0:raise AssertionError(f'Triangle {fi}, slab {ci}: clipped edge outside facet')
    return {'method':'exact_integer_plane_determinants_after_horizontal_triangle_clipping',
            'triangle_slices':slices,'exact_inequalities':count,'tolerance':0}


def rounded_hull_faces(vs):
    from scipy.spatial import ConvexHull
    hull=ConvexHull(vs)
    assert len(hull.vertices)==20 and len(hull.simplices)==36, 'Rounded cluster hull topology drift'
    grouped={3:[],4:[],5:[]}
    for tri,equation in zip(hull.simplices,hull.equations):
        a,b,c=map(int,tri)
        if np.dot(np.cross(vs[b]-vs[a],vs[c]-vs[a]),equation[:3])<0:b,c=c,b
        face=(a,b,c);m=face.index(min(face));face=face[m:]+face[:m]
        role=3 if 18 in face else 5 if 19 in face else 4
        grouped[role].append(face)
    assert [len(grouped[r])for r in [3,4,5]]==[6,24,6], 'Rounded cap/band topology drift'
    return [f for r in [3,4,5]for f in sorted(grouped[r])],[r for r in [3,4,5]for _ in grouped[r]]


def build_tree(source, plan, material, seed):
    env=Envelope(source); source_height=env.height; h=source_height*(0.80 if plan['role']=='narrow' else 1.0); z0=env.zs[0]; zmax=z0+h
    cv=source['crown_vertex_count'];old=np.asarray(source['vertices'],dtype=float)
    stemfaces=[tuple(f) for f in source['triangles'] if min(f)>=cv]
    assert len(stemfaces)==8 and len(old)-cv==6
    rand=stable_rng(seed,source['id']); phase=next(rand)*2*math.pi
    radius=max(np.linalg.norm((r-c)[:,:2],axis=1).max() for r,c in zip(env.rings,env.centers))
    stemcenter=old[cv:cv+3].mean(axis=0)
    bottom=np.array([stemcenter[0],stemcenter[1],z0+0.005*h])
    top=env.center(z0+0.775*h)
    woodv,woodf=prism(bottom,top,radius*0.031,radius*0.011,phase+0.4)
    # Limit the central cross-section if unusually thin frozen geometry requires it.
    for attempt in range(12):
        if env.float_contains(woodv,woodf):break
        woodv,woodf=prism(bottom,top,radius*0.031*(.8**(attempt+1)),radius*0.011*(.8**(attempt+1)),phase+0.4)
    else:raise AssertionError(f'{source["id"]}: continuation cannot fit')
    leadertop=env.center(zmax)
    leaderbottom=lerp_z(top,leadertop,z0+0.665*h)
    leadv,leadf=leader(leaderbottom,leadertop,radius*0.028,phase+1.2)
    for attempt in range(12):
        if env.float_contains(leadv,leadf):break
        leadv,leadf=leader(leaderbottom,leadertop,radius*0.028*(.8**(attempt+1)),phase+1.2)
    else:raise AssertionError(f'{source["id"]}: leader cannot fit')
    # Vertex allocation uses retired crown slots first, skipping all frozen stem slots.
    vertices=[None]*len(old)
    for i in range(cv,len(old)):vertices[i]=source['vertices'][i]
    available=list(range(cv))
    triangles=list(stemfaces); face_roles=[FACE_ROLES['root_stem']]*8
    components=[{'name':'root_stem','vertex_indices':list(range(cv,len(old))),
                 'face_range':[0,8], 'parent':None}]
    local={'root_stem':(old,stemfaces)}
    def add(name,v,fs,roles,parent,anchor,details=None):
        nonlocal available
        inds=[]
        for p in v:
            if available:
                i=available.pop(0);vertices[i]=p.tolist()
            else:i=len(vertices);vertices.append(p.tolist())
            inds.append(i)
        start=len(triangles)
        triangles.extend(tuple(inds[i] for i in f) for f in fs)
        face_roles.extend(roles)
        pv,pf=local[parent]
        margin=min(inward_margin(v,fs,anchor),inward_margin(pv,pf,anchor))
        if margin<=1e-7:
            raise AssertionError(f'{source["id"]} {name}: no strictly positive attachment ({margin})')
        components.append({'name':name,'vertex_indices':inds,'face_range':[start,len(triangles)],
                           'parent':parent,'attachment_witness':list(map(float,anchor)),
                           'attachment_ball_radius':margin*0.5, **(details or {})})
        local[name]=(v,fs)
    woodanchor=lerp_z(bottom,top,max(z0+0.015*h,old[cv:,2].min()+0.015*h))
    add('woody_continuation',woodv,woodf,[FACE_ROLES['woody_continuation']]*12,
        'root_stem',woodanchor)
    leaderanchor=lerp_z(leaderbottom,leadertop,z0+0.765*h)
    add('slender_leader',leadv,leadf,[FACE_ROLES['slender_leader']]*12,
        'woody_continuation',leaderanchor)
    # Independent upright volumetric branch clusters. They intentionally span
    # original source slabs; final exact clipping certifies the complete faces.
    # Unlike r04 no radial full-reach blade is flattened at a slab boundary.
    number = 14 if plan['role']=='low' else 18
    for bidx in range(number):
        fraction=0.09+0.81*(bidx+0.5)/number
        fraction += (next(rand)-0.5)*0.018
        z=z0+h*fraction
        parent='woody_continuation' if fraction<0.74 else 'slender_leader'
        pa,pb=(bottom,top) if parent=='woody_continuation' else (leaderbottom,leadertop)
        anchor=lerp_z(pa,pb,z)
        angle=phase+bidx*(math.pi*(3-math.sqrt(5)))+(next(rand)-0.5)*0.55
        u=np.array([math.cos(angle),math.sin(angle),0.]);side=np.array([-u[1],u[0],0.])
        span=h*(0.30 if plan['role']=='low' else 0.22)
        lo=max(z0+0.008*h,z-0.46*span); hi=min(z0+0.985*h,z+0.65*span)
        # Three rounded convex sections rather than broad bell-like bands.
        # A fixed, explicit 6x3+2 vertex hull gives 36 triangles per cluster.
        # Narrow crown/leader is shortened entirely inside the source envelope.
        vs=[];rsizes=[]
        cluster_phase=next(rand)*2*math.pi
        width_jitter=0.94+0.08*next(rand)
        levels=(0.18,0.50,0.82)
        for level in levels:
            zr=lo+(hi-lo)*level;axis=lerp_z(pa,pb,zr)
            cell=next(c for c in env.cells if c['lo']<=zr<=c['hi'])
            room=-np.einsum('ij,ij->i',cell['n'],axis-cell['o'])
            horiz=np.linalg.norm(cell['n'][:,:2],axis=1)
            rsizes.append(float(np.min(room/horiz)))
        # A shared cross-section scale keeps a concave radius profile even
        # where the source narrows strongly; final containment still exact.
        rad=min(rsizes)*0.86*width_jitter
        for level,fullness,twist in zip(levels,(0.65,1.0,0.65),(-0.035,0.045,-0.015)):
            zr=lo+(hi-lo)*level
            center=lerp_z(pa,pb,zr)+u*(rad*0.15)
            for j in range(6):
                ang=cluster_phase+twist+2*math.pi*j/6
                vs.append(center+rad*fullness*(u*math.cos(ang)+side*0.79*math.sin(ang)))
        vs.append(lerp_z(pa,pb,lo)+u*(rad*0.15))
        vs.append(lerp_z(pa,pb,hi)+u*(rad*0.15))
        vs=f32(vs);fs,roles=rounded_hull_faces(vs)
        # Only transverse contraction; preserve vertical volume and anchor.
        for attempt in range(30):
            if env.float_contains(vs,fs) and inward_margin(vs,fs,anchor)>1e-7:break
            vs=f32([lerp_z(pa,pb,q[2])+(q-lerp_z(pa,pb,q[2]))*np.array([.94,.94,1.]) for q in vs]);fs=oriented(vs,fs)
        else:raise AssertionError('Volumetric cluster cannot fit source with strict attachment')
        add(f'bough_{bidx:02d}',vs,fs,roles,parent,anchor,
            {'mass_revision':'r06-rounded-six-sided-three-ring-convex-clusters','azimuth_rad':angle%(2*math.pi),'anchor_height_fraction':fraction,'height_span_fraction':[(lo-z0)/h,(hi-z0)/h],'original_height_scale':h/source_height,'cluster_topology':'6 sides x 3 rings + 2 poles; 36 convex hull triangles','transverse_fit_scale':.94**attempt})
    assert not available and all(p is not None for p in vertices)
    proof=exact_triangle_certificate(env,vertices,triangles[8:])
    return {'id':source['id'],'source_seed':plan['source_seed'],'role':plan['role'],
            'source_crown_vertex_count':cv,'vertices':vertices,'triangles':triangles,
            'face_role_indices':face_roles,'face_smooth':[r>=3 for r in face_roles],
            'face_material_indices':[material['source_material_index']]*len(triangles),
            'components':components, 'envelope_certificate':proof,
            'stem_original_face_indices':source['triangles'][-8:]}


def load_inputs(path):
    p=Path(path)
    a=json.loads((p/'arrays.json').read_text());plan=json.loads((p/'plan.json').read_text());m=json.loads((p/'material_map.json').read_text())
    return a,{x['id']:x for x in plan['candidates']},{x['id']:x for x in m['rows']},m['materials']


def generate(input_dir=DEFAULT_INPUT, seed=20261102, ids=None):
    assert ids is not None and len(ids)==2 and set(ids)==set(REPRESENTATIVES), 'This prototype supports only the exact two representatives'
    arrays,plans,materials,material_names=load_inputs(input_dir)
    source=arrays['candidates']
    if ids is not None:
        by={s['id']:s for s in source}
        source=[by[i] for i in ids]
    trees=[build_tree(s,plans[s['id']],materials[s['id']],seed) for s in source]
    triangles=sum(len(t['triangles']) for t in trees)
    assert triangles<=160000
    return {'schema':'production_forest_numeric_arrays_v1', 'algorithm':ALGORITHM,'revision':MASS_REVISION,'seed':seed,
            'status':'CPU_GEOMETRY_AND_EXACT_ENVELOPE_CERTIFICATE_ONLY_NOT_BLENDER_OR_ART_APPROVAL',
            'source_sha256':arrays['source_sha256'],
            'input_sha256':{n:sha(Path(input_dir)/(n+'.json')) for n in ('arrays','plan','material_map')},
            'coordinate_space':'SOURCE_WORLD_SPACE_IDENTITY_TRANSFORM_REQUIRED',
            'shader_contract':'No shaders changed. Geometry.Position remains source world-space semantics.',
            'material_contract':'Source material indices only; no new material or palette assignment.',
            'materials':material_names,'face_roles':FACE_ROLES,
            'budget':{'new_forest_cap_excluding_HIGH':160000,'triangles':triangles,
                      'remaining_to_cap':None,'HIGH_included':False,'scope':'TWO_TREE_EXPERIMENT_ONLY_NO_FULL_FOREST_BUDGET_CLAIM'},
            'counts':{'trees':len(trees),'roles':dict(Counter(t['role'] for t in trees)),
                      'components':sum(len(t['components']) for t in trees),
                      'vertices':sum(len(t['vertices']) for t in trees)},
            'candidates':trees}


def write_json(path,data):
    Path(path).write_text(json.dumps(data,separators=(',',':'),allow_nan=False)+'\n')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',type=Path,default=DEFAULT_INPUT)
    parser.add_argument('--output',type=Path,default=HERE/'representative_arrays.json')
    parser.add_argument('--seed',type=int,default=20261102)
    parser.add_argument('--representatives-only',action='store_true')
    args=parser.parse_args()
    result=generate(args.inputs,args.seed,REPRESENTATIVES)
    write_json(args.output,result)
    print(json.dumps({'output':str(args.output),'sha256':sha(args.output),'budget':result['budget'],'counts':result['counts']},indent=2))

if __name__=='__main__':main()
