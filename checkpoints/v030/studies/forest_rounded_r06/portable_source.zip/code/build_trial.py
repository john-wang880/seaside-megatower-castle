"""Explicit two-tree r06 disposable study copy; no rendering or canonical writes."""
import argparse, hashlib, json, os, sys
from pathlib import Path
sys.dont_write_bytecode = True

def need(value, message):
    if not value: raise RuntimeError(message)

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def clean(path, existing=True):
    p = Path(path).absolute()
    need('..' not in p.parts and p.resolve() == p and not any(q.is_symlink() for q in [p, *p.parents]), 'Aliased path')
    need(p.is_file() if existing else p.parent.is_dir() and not os.path.lexists(p), 'Missing input or occupied output')
    return p

def main():
    need(not sys.flags.optimize, 'Optimized Python refused')
    parser = argparse.ArgumentParser()
    for field in ['baseline', 'baseline-sha', 'payload', 'payload-sha', 'qa-common', 'output', 'report']:
        parser.add_argument('--' + field, required=True)
    args = parser.parse_args(sys.argv[sys.argv.index('--') + 1:])
    src, payload, common = clean(args.baseline), clean(args.payload), clean(args.qa_common)
    out, report = clean(args.output, False), clean(args.report, False)
    need(len({src, payload, common, out, report}) == 5 and out.suffix == '.blend' and report.suffix == '.json', 'Path role collision')
    need(args.baseline_sha == 'b9b71ca13b2ba3f8cdb32e16b326a3baaa904f0cc1c2d3f558979fb33a0923a1', 'Wrong reviewed baseline')
    need(sha(src) == args.baseline_sha and sha(payload) == args.payload_sha, 'Pinned inputs changed')
    data = json.loads(payload.read_text())
    rows = data['candidates']
    ids = [r['id'] for r in rows]
    expected = {f'source_axis_{n}' for n in [27970,17660]}
    need(len(rows) == 2 and set(ids) == expected, 'Exact representative subset required')
    need(sum(len(r['triangles']) for r in rows) == 1216, 'Trial triangle budget changed')
    pins = {str(p): sha(p) for p in [src, payload, common, common.with_name('snapshot_support.py'), Path(__file__)]}
    import bpy
    need(bpy.app.version == (5,2,3) and not bpy.data.filepath, 'Reviewed fresh Blender required')
    sys.path.insert(0, str(common.parent))
    import native_common as c
    bpy.ops.wm.open_mainfile(filepath=str(src), load_ui=False, use_scripts=False)
    before, old_ui = c.normalized(c.snap())
    old = {}
    material_names = ['Cypress needles — deep blue green','Fir needles — forest green','Sunlit needle tips','Distant sea pines','Pine bark']
    made = []
    for row in rows:
        name = 'UNACCEPTED r01 | woodland ' + row['id']
        obj = bpy.data.objects[name]
        need(obj.type == 'MESH' and not obj.modifiers and obj.data.users == 1, 'Unexpected proxy ownership')
        need(not obj.data.use_fake_user, 'Unexpected old retention flag')
        old[name] = obj.data
        mesh_name = 'TRIAL | bough mass ' + row['id']
        need(mesh_name not in bpy.data.meshes, 'New namespace collision')
        me = bpy.data.meshes.new(mesh_name)
        me.from_pydata(row['vertices'], [], row['triangles'])
        need(data['materials'] == material_names, 'Material pointer order changed')
        for name in material_names: me.materials.append(bpy.data.materials[name])
        need(len(row['face_material_indices']) == len(me.polygons), 'Material assignment count')
        need(row['face_smooth']==[role>=3 for role in row['face_role_indices']],'Explicit new foliage smooth contract')
        for polygon, slot, smooth in zip(me.polygons, row['face_material_indices'],row['face_smooth']):
            need(type(slot) is int and 0 <= slot < 5, 'Invalid material slot')
            polygon.material_index = slot
            polygon.use_smooth = smooth
        me.update()
        need([list(v.co) for v in me.vertices] == row['vertices'], 'Native coordinate cast changed payload')
        need([list(p.vertices) for p in me.polygons] == row['triangles'], 'Native topology changed payload')
        old[obj.name].use_fake_user = True
        obj.data = me
        made.append({'id': row['id'], 'object': obj.name, 'mesh': me.name, 'retained_old_mesh': old[obj.name].name, 'triangles': len(me.polygons)})
    bpy.context.view_layer.update()
    # Exact rollback comparison prevents broad object/property exceptions.
    new = {name: bpy.data.objects[name].data for name in old}
    for name, me in old.items(): bpy.data.objects[name].data = me
    restored, new_ui = c.normalized(c.snap())
    for category, prior in before.items():
        actual = restored[category]
        need(all(actual.get(k) == v for k,v in prior.items()) if category == 'meshes' else actual == prior,
             'Rollback source category drift: ' + category)
    need(set(restored['meshes']) - set(before['meshes']) == {r['mesh'] for r in made}, 'Unexpected mesh delta')
    need(set(restored['objects']) == set(before['objects']), 'Unexpected object delta')
    for name, me in new.items(): bpy.data.objects[name].data = me
    bpy.context.view_layer.update()
    need(all(sha(p) == h for p,h in pins.items()), 'Input/runtime mutation')
    result = bpy.ops.wm.save_as_mainfile(filepath=str(out), copy=True, compress=True, check_existing=False)
    need('FINISHED' in result and all(sha(p) == h for p,h in pins.items()), 'Save/input failure')
    record = {'status':'DISPOSABLE two-tree r06 craft trial; independent saved QA and actual views pending',
              'baseline_sha256':args.baseline_sha,'payload_sha256':args.payload_sha,'candidate_sha256':sha(out),
              'candidate_bytes':out.stat().st_size,'objects':made,'source_categories':list(before),
              'rollback_categories_exact':True,'old_proxy_fake_user_delta':{m.name:[False,True] for m in old.values()},
              'all_other_objects_material_graphs_coast_HIGH_unchanged':True,'rendered':False,'production_release':False,
              'pins':pins,'ui_exception_scope':'Only three inherited subdivision selection cache exceptions from archived normalized helper.'}
    report.write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'candidate_sha256':record['candidate_sha256'],'bytes':record['candidate_bytes'],'trial_triangles':1216}))

if __name__ == '__main__': main()
