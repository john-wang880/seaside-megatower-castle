"""CPU-only 18-tree palette assignment; never changes geometry or source files."""
from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
import math
from pathlib import Path

SOURCE_SHA = "9f020b7ec6eda309d674653598b169f65ba5dc1d1f194ffa31323f6393feda35"
PALETTE_SHA = "bd613c5fed64d27dc0153d29ffec5e06350505be625351bfb7901795401329bc"
FROZEN_GEOMETRY_SHA = "bdd6c81d9b5d27122c27475d375bb9dd4f322c0de86bdb793794fccc441e86e3"
TRIAL_IDS = frozenset("source_axis_" + x for x in (
    "6210", "104520", "77930", "27970", "13620", "39310", "26720", "17660",
    "25820", "11660", "56340", "122130", "2130", "15720", "10430", "21280",
    "44660", "67810"))
MATERIALS = ["Cypress needles — deep blue green", "Fir needles — forest green",
             "Sunlit needle tips", "Distant sea pines"]
ROLES = {"root_stem": 0, "woody_continuation": 1, "slender_leader": 2,
         "bough_inner_cap": 3, "bough_side": 4, "bough_outer_cap": 5}
BOUGHS = {"low": 9, "narrow": 10, "broad": 12}
COUNTS = {"low": 212, "narrow": 232, "broad": 272}


class GuardError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise GuardError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        allow_nan=False, separators=(",", ":")).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def area(vertices, triangle):
    a, b, c = (vertices[i] for i in triangle)
    u = [b[i] - a[i] for i in range(3)]
    v = [c[i] - a[i] for i in range(3)]
    cross = [u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0]]
    return math.hypot(*cross) / 2


def geometry_digest(row):
    return digest({k: v for k, v in row.items() if k != "face_material_indices"})


def connected_faces(triangles, ids):
    pending = set(ids)
    if not pending:
        return False
    stack = [pending.pop()]
    while stack:
        i = stack.pop()
        neighbors = {j for j in pending if len(set(triangles[i]) & set(triangles[j])) >= 2}
        pending -= neighbors
        stack.extend(neighbors)
    return not pending


def upward_fan_patch(row, component):
    """Largest complete edge-connected upward-facing group of a distal fan."""
    triangles, vertices = row["triangles"], row["vertices"]
    lo, hi = component["face_range"]
    positive = set()
    for i in range(lo, hi):
        if row["face_role_indices"][i]!=5: continue
        a, b, c = (vertices[j] for j in triangles[i])
        normal_z = (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])
        if normal_z > 0:  # Horizontal and downward faces are not upper surfaces.
            positive.add(i)
    groups = []
    while positive:
        group = {min(positive)}
        positive -= group
        stack = list(group)
        while stack:
            i = stack.pop()
            neighbors = {j for j in positive if len(set(triangles[i]) & set(triangles[j])) >= 2}
            positive -= neighbors
            group |= neighbors
            stack.extend(neighbors)
        groups.append(sorted(group))
    return max(groups, key=lambda ids: (math.fsum(area(vertices, triangles[i]) for i in ids),
                                       tuple(-i for i in ids))) if groups else []


def validate_palette(plan):
    require(plan.get("source_sha256") == SOURCE_SHA, "Wrong palette source")
    require(plan.get("count") == 18 and plan.get("scope_status") ==
            "APPROVED_SCOPE_18_DISPOSABLE_TRIAL_MAPPING_ONLY", "Only approved 18-tree trial permitted")
    require(plan.get("materials") == MATERIALS, "Palette materials changed")
    rows = plan.get("rows", [])
    require(len(rows) == 18 and {r.get("id") for r in rows} == TRIAL_IDS,
            "Wrong or duplicate palette IDs")
    for r in rows:
        a = r["source_associated_triangle_area_by_slot"]
        require(len(a) == 4 and all(type(x) in (int, float) and math.isfinite(x) and x >= 0
                                   for x in a) and sum(a) > 0, "Invalid source material areas")
        require(not r["authored_fallback"] and r["in_first_trial"], "Authored fallback outside trial authority")
        require(r["role"] in BOUGHS and r["budget_triangles"] == COUNTS[r["role"]], "Wrong palette role/budget")
        base = max((0, 1), key=lambda j: (a[j], -j))
        require(a[base] > 0 and r["base_slot"] == base, "Base not source-evidenced dark choice")
        options = [i for i in (0, 1, 3) if i != base and a[i] > 0]
        secondary = max(options, key=lambda j: (a[j], -j)) if options else None
        secondary_fraction = min(.16, a[secondary] / sum(a[i] for i in (0, 1, 3))) if secondary is not None else 0
        tip_fraction = min(.06, a[2] / sum(a))
        require(r["secondary_slot"] == secondary and
                r["secondary_target_foliage_area_fraction"] == secondary_fraction,
                "Secondary material/area rule changed")
        require(r["tip_slot"] == (2 if tip_fraction else None) and
                r["tip_target_foliage_area_fraction"] == tip_fraction, "Tip material/area rule changed")
        require(r["base_target_foliage_area_fraction"] == 1-secondary_fraction-tip_fraction,
                "Base area allocation changed")
    return {r["id"]: r for r in rows}


def validate_geometry(data, plans):
    require(data.get("schema") == "production_forest_numeric_arrays_v1", "Unknown geometry schema")
    require(data.get("source_sha256") == SOURCE_SHA, "Wrong geometry source")
    require(data.get("coordinate_space") == "SOURCE_WORLD_SPACE_IDENTITY_TRANSFORM_REQUIRED",
            "World-coordinate contract missing")
    require(data.get("face_roles") == ROLES and data.get("materials") == MATERIALS,
            "Geometry role/material definitions changed")
    require("palette_application" not in data, "Already palette-processed input refused")
    rows = data.get("candidates", [])
    require(len(rows) == 18 and {r.get("id") for r in rows} == TRIAL_IDS,
            "Input must be exactly representative 18, not full forest")
    require(data.get("counts", {}).get("trees") == 18, "Geometry count metadata mismatch")
    for r in rows:
        require(r["role"] == plans[r["id"]]["role"], "Role differs from palette")
        vs, ts, roles, mats = (r[k] for k in ("vertices", "triangles", "face_role_indices", "face_material_indices"))
        require(all(len(v) == 3 and all(type(x) in (int, float) and math.isfinite(x) for x in v) for v in vs),
                "Invalid/nonfinite vertex")
        require(len(ts) == COUNTS[r["role"]] and len(roles) == len(ts) == len(mats), "Face/count length mismatch")
        require(all(len(t) == 3 and len(set(t)) == 3 and all(type(i) is int and 0 <= i < len(vs) for i in t)
                    for t in ts), "Invalid triangle indices")
        require(all(type(i) is int and 0 <= i < 4 for i in mats), "Unexpected input material index")
        require(all(type(i) is int and 0 <= i <= 5 for i in roles), "Unexpected role index")
        require(all(math.isfinite(area(vs, t)) and area(vs, t) > 0 for t in ts), "Degenerate/nonfinite face area")
        components = r["components"]
        names = [c["name"] for c in components]
        require(len(set(names)) == len(names), "Duplicate component name")
        require(set(names) == {"root_stem", "woody_continuation", "slender_leader"} |
                {f"bough_{i:02d}" for i in range(BOUGHS[r["role"]])}, "Wrong component inventory")
        covered = []
        for c in components:
            lo, hi = c["face_range"]
            require(type(lo) is int and type(hi) is int and 0 <= lo < hi <= len(ts), "Bad component face range")
            cv = c["vertex_indices"]
            require(len(cv) == len(set(cv)) and all(type(i) is int and 0 <= i < len(vs) for i in cv),
                    "Bad component vertex indices")
            require(all(set(ts[i]) <= set(cv) for i in range(lo, hi)), "Face outside declared component")
            expected = {"root_stem": [0]*8, "woody_continuation": [1]*12, "slender_leader": [2]*12}.get(c["name"],
                                                                                                          [3]*5+[4]*10+[5]*5)
            require(roles[lo:hi] == expected, "Component role or distal-fan schema mismatch")
            if c["name"].startswith("bough_"):
                fan = list(range(hi-5, hi))
                require(connected_faces(ts, fan) and len(set.intersection(*(set(ts[i]) for i in fan))) == 1,
                        "Distal fan not contiguous around one pole")
            covered.extend(range(lo, hi))
        require(sorted(covered) == list(range(len(ts))), "Component coverage overlap or gap")
    require(sum(len(r["triangles"]) for r in rows) == 4376 and data["budget"]["triangles"] == 4376,
            "Trial triangle budget mismatch")


def choose_patches(row, plan):
    areas = [area(row["vertices"], t) for t in row["triangles"]]
    foliage_area = math.fsum(a for a, role in zip(areas, row["face_role_indices"]) if role >= 2)
    branches = [c for c in row["components"] if c["name"].startswith("bough_")]
    branch_faces = lambda c: list(range(*c["face_range"]))
    key = lambda name: digest(f"forest_production_trial_v1:{row['id']}:{name}")
    secondary_limit = plan["secondary_target_foliage_area_fraction"] * foliage_area
    eligible = [c for c in branches if plan["secondary_slot"] is not None and
                math.fsum(areas[i] for i in branch_faces(c)) <= secondary_limit]
    secondary = max(eligible, key=lambda c: (math.fsum(areas[i] for i in branch_faces(c)), key(c["name"]))) if eligible else None
    tip_limit = plan["tip_target_foliage_area_fraction"] * foliage_area
    fans = []
    for c in branches:
        if c is secondary:
            continue  # Preserve the complete secondary bough as one contiguous patch.
        lo, hi = c["face_range"]
        faces = upward_fan_patch(row, c)
        mass = math.fsum(areas[i] for i in faces)
        height = math.fsum(row["vertices"][v][2] for v in c["vertex_indices"]) / len(c["vertex_indices"])
        if faces and plan["tip_slot"] == 2 and mass <= tip_limit:
            fans.append({"component": c["name"], "faces": faces, "area": mass, "height": height})
    choices = [(f,) for f in fans] + list(itertools.combinations(fans, 2))
    choices = [c for c in choices if math.fsum(areas[i] for f in c for i in f["faces"]) <= tip_limit]
    chosen = max(choices, key=lambda c: (math.fsum(areas[i] for f in c for i in f["faces"]),
                 math.fsum(f["height"] for f in c)/len(c), key(":".join(f["component"] for f in c)))) if choices else ()
    mats = [4 if role < 2 else plan["base_slot"] for role in row["face_role_indices"]]
    secondary_faces = branch_faces(secondary) if secondary else []
    for i in secondary_faces:
        mats[i] = plan["secondary_slot"]
    for fan in chosen:
        for i in fan["faces"]:
            mats[i] = 2
    return mats, {"secondary_component": secondary["name"] if secondary else None,
                  "secondary_faces": secondary_faces,
                  "tip_components": [f["component"] for f in chosen],
                  "tip_faces": [f["faces"] for f in chosen]}


def verify_assignment(original, changed, plan):
    require(geometry_digest(original) == geometry_digest(changed), "Geometry/metadata changed during palette assignment")
    roles, mats = changed["face_role_indices"], changed["face_material_indices"]
    require(len(mats) == len(roles) and all(type(i) is int and 0 <= i <= 4 for i in mats), "Bad output material indices")
    require(all(m == 4 for m, r in zip(mats, roles) if r < 2), "Bark must be slot4")
    require(all(m != 4 for m, r in zip(mats, roles) if r >= 2), "Bark on foliage")
    require(all(m == plan["base_slot"] for m, r in zip(mats, roles) if r == 2), "Leader must remain dark base")
    sec, tips = [], []
    for c in changed["components"]:
        if not c["name"].startswith("bough_"):
            continue
        lo, hi = c["face_range"]
        cm = mats[lo:hi]
        if plan["secondary_slot"] is not None and plan["secondary_slot"] in cm:
            require(all(m == plan["secondary_slot"] for m in cm), "Secondary must occupy one whole bough")
            sec.append(c["name"])
        else:
            require(all(m == plan["base_slot"] for m in cm[:15]), "Nonbase material outside distal fan")
            actual_tip_faces = [i for i in range(lo, hi) if mats[i] == 2]
            expected_tip_faces = upward_fan_patch(changed, c)
            require(all(m in (plan["base_slot"], 2) for m in cm[15:]), "Unknown distal fan material")
            require(not actual_tip_faces or actual_tip_faces == expected_tip_faces,
                    "Tip patch must be complete connected upper-facing distal subset")
            if actual_tip_faces:
                tips.append(c["name"])
    require(len(sec) <= 1 and len(tips) <= 2, "Too many material patches")
    areas = [area(changed["vertices"], t) for t in changed["triangles"]]
    foliage = math.fsum(a for a, r in zip(areas, roles) if r >= 2)
    totals = [math.fsum(a for a, m, r in zip(areas, mats, roles) if m == slot and r >= 2) for slot in range(4)]
    tip_area = totals[2]
    secondary_area = totals[plan["secondary_slot"]] if plan["secondary_slot"] is not None else 0
    require(tip_area <= plan["tip_target_foliage_area_fraction"] * foliage, "Tip area exceeds source/6% limit")
    require(secondary_area <= plan["secondary_target_foliage_area_fraction"] * foliage, "Secondary area exceeds source/16% limit")
    require(not tips or plan["tip_slot"] == 2, "Tips added without source evidence")
    return {"foliage_area": foliage, "bark_area": math.fsum(a for a, r in zip(areas, roles) if r < 2),
            "foliage_area_by_slot": totals, "foliage_fraction_by_slot": [a/foliage for a in totals],
            "secondary_area": secondary_area, "secondary_fraction": secondary_area/foliage,
            "tip_area": tip_area, "tip_fraction": tip_area/foliage,
            "secondary_components": sec, "tip_components": tips}


def apply(data, palette):
    plans = validate_palette(palette)
    validate_geometry(data, plans)
    output = copy.deepcopy(data)
    reports = []
    for old, new in zip(data["candidates"], output["candidates"]):
        plan = plans[old["id"]]
        mats, patches = choose_patches(old, plan)
        new["face_material_indices"] = mats
        measurements = verify_assignment(old, new, plan)
        reports.append({"id": old["id"], "geometry_sha256_before": geometry_digest(old),
            "geometry_sha256_after": geometry_digest(new), "vertices_sha256": digest(old["vertices"]),
            "triangles_sha256": digest(old["triangles"]), "face_roles_sha256": digest(old["face_role_indices"]),
            "material_indices_sha256": digest(mats), "base_slot": plan["base_slot"],
            "secondary_slot": plan["secondary_slot"], "tip_slot": plan["tip_slot"],
            "source_area_by_slot": plan["source_associated_triangle_area_by_slot"],
            "base_provenance": plan["base_selection"], "authored_fallback": False,
            "secondary_target_fraction": plan["secondary_target_foliage_area_fraction"],
            "tip_target_fraction": plan["tip_target_foliage_area_fraction"],
            "secondary_omission": "no_whole_bough_fits_area_limit" if plan["secondary_slot"] is not None and not patches["secondary_faces"] else None,
            "tip_face_rule": "Complete largest edge-connected strictly upward-facing role5 subset; zero/downward normal Z excluded",
            "tip_omission": "no_complete_upper_distal_patch_fits_area_limit" if plan["tip_slot"] == 2 and not patches["tip_faces"] else None,
            **patches, **measurements})
    output["materials"] = MATERIALS + ["Pine bark"]
    output["material_contract"] = "Existing foliage slots0-3 and existing Pine bark pointer at slot4; material graphs/world coordinates must remain unchanged in native adapter."
    output["palette_application"] = {"schema": "representative18_palette_v1", "source_sha256": SOURCE_SHA,
        "palette_sha256": PALETTE_SHA, "algorithm": "whole-bough-secondary-and-up-to-two-upper-distal-fan-patches-v1",
        "scope": "18_DISPOSABLE_REPLACEMENTS_ONLY_NOT_FULL_FOREST_AUTHORITY", "geometry_unchanged": True,
        "native_material_pointer_graph_verification": "REQUIRED_NOT_PERFORMED_BY_CPU_SCRIPT"}
    return output, {"pass": True, "scope": "CPU_PALETTE_ONLY_NOT_NATIVE_OR_ART_APPROVAL",
        "trees": 18, "triangles_unchanged": 4376, "rows": reports}


def read_regular(path):
    path = Path(path).absolute()
    require(path.is_file() and not path.is_symlink() and path.resolve() == path, "Input must be regular nonaliased file")
    return path, json.loads(path.read_text()), sha(path)


def write_new(path, value):
    path = Path(path).absolute()
    require(path.parent.is_dir() and path.parent.resolve() == path.parent and not path.exists(), "Output exists or parent is missing/aliased")
    with path.open("x", encoding="utf-8") as file:
        json.dump(value, file, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
        file.write("\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--palette", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists() and not args.report.exists(), "Outputs must be new")
    require(args.output.absolute() != args.report.absolute(), "Output/report paths must differ")
    source, data, source_sha = read_regular(args.input)
    require(source_sha == FROZEN_GEOMETRY_SHA, "Frozen representative geometry changed")
    palette_path, palette, palette_sha = read_regular(args.palette)
    require(palette_sha == PALETTE_SHA, "Pinned approved trial palette changed")
    output, report = apply(data, palette)
    require(sha(source) == source_sha and sha(palette_path) == palette_sha, "Input changed while applying palette")
    output["palette_application"].update({"input_geometry_file_sha256": source_sha, "script_sha256": sha(__file__)})
    write_new(args.output, output)
    require(json.loads(args.output.read_text()) == output, "Written output changed")
    require(sha(source) == source_sha and sha(palette_path) == palette_sha, "Source mutated")
    for before, after in zip(data["candidates"], json.loads(args.output.read_text())["candidates"]):
        verify_assignment(before, after, {r["id"]: r for r in palette["rows"]}[before["id"]])
    report.update({"source_sha256": SOURCE_SHA, "input_geometry_file_sha256_before": source_sha,
        "input_geometry_file_sha256_after": sha(source), "palette_file_sha256": palette_sha,
        "script_sha256": sha(__file__), "output_file_sha256": sha(args.output),
        "output_geometry_sha256": digest([geometry_digest(r) for r in output["candidates"]]),
        "geometry_and_source_files_unchanged": True})
    write_new(args.report, report)
    print(json.dumps({"pass": True, "output": str(args.output), "report": str(args.report),
                      "trees": 18, "triangles": 4376}))


if __name__ == "__main__":
    main()
