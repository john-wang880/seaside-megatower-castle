# Portable r06 two-tree source-reproduction package

Actual detail views are pending. This is a two-tree study, not an accepted production release or new formal model. It uses 14/18 convex rounded clusters, with three six-vertex rings plus two poles each (36 triangles per cluster). The generated narrow crown is shortened to 80% inside the unchanged source envelope; original source root/stem remains exact. Total1216triangles for source_axis_27970 and17660 does not demonstrate the unchanged160k full-forest budget. Original r01 coast remains a rejected study backdrop and is not adopted into canonical v030.

## Required explicit inputs

- Existing Blender5.2.3, Python3 with NumPy and SciPy. No install, download, autoexecution or preference changes are performed.
- Exact v030 model: SHA2569f020b7ec6eda309d674653598b169f65ba5dc1d1f194ffa31323f6393feda35,47,842,841 bytes. Restore from Git commit143e60c2c26af603b7a0d2f00ff897797c663286 using its checkpoints/v030/restore_checkpoint.py.
- Exact verified r01 study extraction: restore checkpoints/v030/studies/landscape_r01 at commitae118943b27e25bc24c8b51d846f40b6e8b2a4c6, join its64 parts with its restore_study.py, verify ZIP SHA4b2c492beb1f9e95a37a0256d788a33646adaed8649a92b35c5126874bbfebb1 (61,982,750 bytes) and extract into a clean directory. Its381-file inventory is checked by the controller against the pinned FILES.json hash. Do not modify that extraction.
- New external output directory, outside source, study and this bundle. Inputs and outputs must not be symlinked or aliased. Use absolute paths without parent traversal.

## Run

python -B run.py --blender ABS_BLENDER --source ABS_V030 --study-root ABS_R01_EXTRACTION --output-dir NEW_ABS_OUTPUT

Add --preflight-only for read-only identity/path/inventory checks. Add --cpu-only for exact source-numeric and palette reconstruction with no native calls; this does not establish native or artistic acceptance. Optional --baseline ABS_EXISTING_R01 may reuse an existing reconstructed baseline, but its full original r01 independent QA still runs before use. Omit it for the complete source-only route. Do not reuse an occupied output. Caller coordinates the single heavy Blender worker.

The full route prepares and rebuilds r01 from exact v030, then runs the original independent r01 QA (2 native+2 CPU calls, frozen exact geometry/normal semantics and13 source categories). Only after this passes does it bind r06 templates to the actual reconstructed baseline serialization SHA. Baseline file hashes may vary across fresh saves; no geometric or preservation test is removed. BASELINE_BINDING.json records exact template/bound hashes and the sole hash-literal replacement. The frozen source-origin registry is relocated to bundled copies with unchanged pinned bytes.

The r06 numeric generator and original palette patch module reconstruct exact expected numeric/payload hashes. R06 build and saved-native/independent exact geometry gates then run. All original root/stem, attachment, manifold/volume, exact-rational envelope, materials, old meshes, lights/world/cameras and rollback checks remain. The final SUMMARY.json is technical only, never art/production approval. No rendering, Git operations, deletion, remote upload or original-model writes occur.

## Included dependencies

code/ holds byte-identical executed r06 geometry/build/gate templates and the explicitly pinned palette module with its complete role-5 six-face upper fan adaptation. data/ holds exact four frozen source JSONs, palette plan, frozen per-tree source snapshots with relative origin names, and expected numeric/payload arrays. SPEC.json pins external sources and expected outputs. FILES.json covers all bundle files except itself. No dependency on a mutable r03 directory or original candidate blend remains. Native common/snapshot helpers come from the complete pinned external r01 study, not private workspace paths.

## Tests and limits

python -B test_runner.py --source ABS_V030 --study-root ABS_R01_EXTRACTION --report NEW_ABS_REPORT

Pure tests cover actual source/study preflight, relocation and exact CPU reconstruction, immutable inventory, path/symlink guards, wrong source, occupied/nested output, unsafe manifest, and incorrect baseline binding. They intentionally use a fake Blender executable to prove no native job is launched. Full native portable replay must be run separately; Linux execution does not imply native Windows validation. Original r06 local saved-native validation is distinct from this newly packaged controller.

## Additional r06 protections

Only new foliage faces have explicit true face_smooth flags. Root/stem and generated woody/leader faces remain flat. Native QA verifies every polygon use_smooth and inverse sharp_face value; original source objects and normal semantics remain protected. The independent exact triangle gate also verifies every cluster is convex, explicit 6/24/6 face roles, positive-volume attachments, unchanged material area caps and precise original envelopes.

Run `python -B test_geometry.py --report NEW_ABS_REPORT` for deterministic/reversed-order reconstruction and 14 negative geometry/material/smoothing controls. Run from a migrated bundle too. Evidence reports are external outputs and do not mutate this package. Visual acceptance is pending; do not interpret technical PASS as art acceptance or production authorization.
