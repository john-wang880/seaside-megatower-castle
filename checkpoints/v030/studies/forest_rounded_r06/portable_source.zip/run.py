"""Portable source-only r06 two-tree reconstruction; no downloads or canonical writes."""
import argparse,copy,hashlib,importlib.util,json,os,re,shutil,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent

def need(v,m):
 if not v:raise RuntimeError(m)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def write_new(p,data):
 with Path(p).open('x') as f:f.write(json.dumps(data,indent=2)+'\n')
def clean(x):
 p=Path(x);need('..'not in p.parts,'Parent traversal refused');p=p.absolute();need(p.resolve()==p and not any(q.is_symlink()for q in [p,*p.parents]),'Aliased path refused');return p
def inventory(root):
 need(not any(p.is_symlink()for p in root.rglob('*')),'Symlink in immutable input')
 return {p.relative_to(root).as_posix():sha(p)for p in sorted(root.rglob('*'))if p.is_file()}
def safe_manifest(m):
 need(isinstance(m,dict)and all(type(k)is str and not Path(k).is_absolute()and '..'not in Path(k).parts and type(v)is str and re.fullmatch('[0-9a-f]{64}',v)for k,v in m.items()),'Unsafe manifest')
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def preflight(blender,source,study,out,baseline=None):
 need(not sys.flags.optimize,'Optimized Python refused')
 spec=load(ROOT/'SPEC.json');manifest=load(ROOT/'FILES.json');safe_manifest(manifest);inv=inventory(ROOT)
 need({k:v for k,v in inv.items()if k!='FILES.json'}==manifest,'Portable bundle inventory mismatch')
 need(blender.is_file()and source.is_file()and study.is_dir(),'Missing explicit inputs')
 need(sha(source)==spec['canonical_source_sha256']and source.stat().st_size==spec['canonical_source_bytes'],'Wrong canonical source')
 sm=study/'FILES.json';need(sm.is_file()and sha(sm)==spec['r01_root_manifest_sha256'],'Wrong r01 source study manifest')
 si=inventory(study);source_manifest=load(sm)
 need(isinstance(source_manifest,dict)and all(isinstance(v,dict)and set(v)=={'bytes','sha256'}and type(v['bytes'])is int and v['bytes']>=0 for v in source_manifest.values()),'r01 manifest record schema')
 manifest={k:v['sha256']for k,v in source_manifest.items()};safe_manifest(manifest)
 need({k:v for k,v in si.items()if k!='FILES.json'}==manifest,'r01 source study inventory mismatch')
 need(all((study/k).stat().st_size==v['bytes']for k,v in source_manifest.items()),'r01 source study byte counts')
 need(not os.path.lexists(out),'Output must be new')
 for protected in [ROOT,study,source.parent,blender.parent]:need(not out.is_relative_to(protected)and not protected.is_relative_to(out),'Output aliases immutable input tree')
 if baseline:
  need(baseline.is_file()and not baseline.samefile(source),'Invalid explicit baseline')
  need(not out.is_relative_to(baseline.parent)and not baseline.parent.is_relative_to(out),'Output aliases baseline input tree')
 frozen=load(ROOT/'data/FROZEN_TEMPLATE.json')
 for name,h in frozen['origin_relative_sha256'].items():
  need(Path(name).name==name and sha(ROOT/'data/inputs'/name)==h,'Frozen input pin mismatch')
 return spec,inv,si

def bind_runtime(out,spec,baseline_sha):
 """Retain exact templates, change only source-verified serialization identity."""
 bound=out/'bound';shutil.copytree(ROOT/'code',bound)
 records=[]
 for rel in spec['baseline_binding_templates']:
  original=ROOT/rel;dest=bound/Path(rel).relative_to('code');text=original.read_text();old=spec['historical_baseline_sha256']
  need(text.count(old)==1,'Baseline template occurrence mismatch '+rel)
  dest.write_text(text.replace(old,baseline_sha))
  records.append({'template':rel,'template_sha256':sha(original),'bound_sha256':sha(dest),'only_change':'Historical baseline serialization SHA replaced by fully QA-verified reconstructed baseline SHA','old':old,'new':baseline_sha})
 frozen=load(ROOT/'data/FROZEN_TEMPLATE.json');frozen['baseline_sha256']=baseline_sha
 frozen['origin_sha256']={str(ROOT/'data/inputs'/name):h for name,h in frozen.pop('origin_relative_sha256').items()}
 write_new(out/'FROZEN_RUNTIME.json',frozen);write_new(out/'BASELINE_BINDING.json',records)
 return bound,frozen

def regenerate(bound,out,frozen):
 spec=load(ROOT/'SPEC.json');gen=module('portable_r06_gen',bound/'generate_forest.py');palette=module('portable_original_palette',bound/'original_palette.py');gate=module('portable_r06_gate',bound/'qa/geometry_gate.py')
 need(sha(bound/'original_palette.py')==spec['palette_module_sha256'],'Pinned six-face palette module drift')
 numeric=gen.generate(ROOT/'data/inputs',ids=spec['ids']);numeric=json.loads(json.dumps(numeric))
 raw=json.dumps(numeric,separators=(',',':'),allow_nan=False)+'\n';need(hashlib.sha256(raw.encode()).hexdigest()==spec['expected_numeric_sha256'],'Numeric source reproduction drift')
 pal=load(ROOT/'data/PALETTE_2.json');gate.validate_frozen_and_palette(frozen,pal)
 plans={r['id']:r for r in pal['rows']};payload=copy.deepcopy(numeric)
 for old,new in zip(numeric['candidates'],payload['candidates']):
  plan=plans[old['id']];new['face_material_indices'],patches=palette.choose_patches(old,plan);palette.verify_assignment(old,new,plan)
 payload['materials']=pal['materials']+['Pine bark']
 payload['palette_application']={'scope':'TWO_TREE_DISPOSABLE_R06_ONLY','algorithm':'Original source-evidenced patch allocation; complete role5 upper fan topology generalized from 5 to 6 sides','palette_module_sha256':sha(bound/'original_palette.py'),'full_forest':False}
 rawpayload=json.dumps(payload,separators=(',',':'),allow_nan=False)+'\n';need(hashlib.sha256(rawpayload.encode()).hexdigest()==spec['expected_payload_sha256'],'Palette source reproduction drift')
 gate.verify_geometry_lineage(payload,numeric);report=gate.run(payload,frozen,pal)
 (out/'ARRAYS.json').write_text(raw);(out/'PAYLOAD.json').write_text(rawpayload);write_new(out/'CPU_REPRODUCTION.json',report)
 return sha(out/'PAYLOAD.json')

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for name in ['blender','source','study-root','output-dir']:ap.add_argument('--'+name,required=True)
 ap.add_argument('--baseline',help='Optional existing r01 baseline; always independently revalidated before use. Omit for full source-only baseline reconstruction.')
 ap.add_argument('--preflight-only',action='store_true');ap.add_argument('--cpu-only',action='store_true',help='Pure recipe replay only; uses historical baseline identity, no native execution or production approval.')
 a=ap.parse_args();blender,source,study,out=map(clean,[a.blender,a.source,a.study_root,a.output_dir]);baseline=clean(a.baseline)if a.baseline else None
 spec,inv,si=preflight(blender,source,study,out,baseline)
 if a.preflight_only:print('PREFLIGHT PASS; no outputs/native execution');return
 out.mkdir(parents=True);env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',XDG_CACHE_HOME=str(out/'cache'));commands=[]
 def flags(**kw):return [v for k,x in kw.items()for v in ['--'+k.replace('_','-'),str(x)]]
 def run(name,cmd):
  commands.append(cmd);(out/'COMMANDS.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (out/(name+'.log')).open('x')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,cwd=out)
  need(r.returncode==0,'Stage failed: '+name)
 def native(script,args):return [str(blender),'--background','--factory-startup','--disable-autoexec','--threads','8','--python-exit-code','1','--python',str(script),'--']+args
 if a.cpu_only:
  bound,frozen=bind_runtime(out,spec,spec['historical_baseline_sha256']);regenerate(bound,out,frozen)
  need(inventory(ROOT)==inv and inventory(study)==si,'Immutable input drift')
  write_new(out/'SUMMARY.json',{'pass':True,'scope':'CPU_ONLY_NO_NATIVE_OR_ART_APPROVAL','no_native_calls':True,'numeric_and_payload_exact':True});print('CPU REPRODUCTION PASS');return
 if baseline is None:
  modeldir=out/'baseline_model';modeldir.mkdir();baseline=modeldir/'rebuilt.blend'
  run('prepare_baseline',[sys.executable,'-B',str(study/'reproduce/prepare_inputs.py')]+flags(source=source,output=modeldir/'inputs.json'))
  run('build_baseline',native(study/'reproduce/build_scene.py',flags(source=source,inputs=modeldir/'inputs.json',output=baseline,report=modeldir/'build.json')))
 baseline_sha=sha(baseline)
 run('verify_baseline',[sys.executable,'-B',str(study/'qa/run_qa.py')]+flags(blender=blender,source=source,candidate=baseline,candidate_sha=baseline_sha,output_dir=out/'baseline_qa'))
 proof=load(out/'baseline_qa/SUMMARY.json');need(proof['pass']and proof['historical_saved_geometry_semantics_exact']and proof['candidate_sha256']==baseline_sha,'Baseline semantic proof missing')
 bound,frozen=bind_runtime(out,spec,baseline_sha);payload_sha=regenerate(bound,out,frozen);modeldir=out/'r06_model';modeldir.mkdir();candidate=modeldir/'trial.blend';common=study/'qa/native_common.py'
 bound_inv=inventory(bound);runtime_frozen_sha=sha(out/'FROZEN_RUNTIME.json')
 run('build_r06',native(bound/'build_trial.py',flags(baseline=baseline,baseline_sha=baseline_sha,payload=out/'PAYLOAD.json',payload_sha=payload_sha,qa_common=common,output=candidate,report=modeldir/'build.json')))
 candidate_sha=sha(candidate)
 run('saved_r06',native(bound/'qa/saved_native.py',flags(baseline=baseline,canonical=source,candidate=candidate,candidate_sha=candidate_sha,geometry=out/'PAYLOAD.json',frozen=out/'FROZEN_RUNTIME.json',palette=ROOT/'data/PALETTE_2.json',native_common=common,report=out/'SAVED_NATIVE.json',export=out/'ACTUAL_SAVED_ARRAYS.json')))
 run('geometry_r06',[sys.executable,'-B',str(bound/'qa/geometry_gate.py')]+flags(geometry=out/'ACTUAL_SAVED_ARRAYS.json',frozen=out/'FROZEN_RUNTIME.json',palette=ROOT/'data/PALETTE_2.json',report=out/'SAVED_GEOMETRY.json',numeric_geometry=out/'ARRAYS.json'))
 need(load(out/'SAVED_NATIVE.json')['pass']and load(out/'SAVED_GEOMETRY.json')['pass'],'Saved QA not passed')
 need(inventory(ROOT)==inv and inventory(study)==si and inventory(bound)==bound_inv,'Immutable recipes changed')
 need(sha(out/'FROZEN_RUNTIME.json')==runtime_frozen_sha and sha(source)==spec['canonical_source_sha256']and sha(baseline)==baseline_sha and sha(candidate)==candidate_sha,'Models/runtime binding changed')
 write_new(out/'SUMMARY.json',{'pass':True,'scope':'TWO_TREE_R06_TECHNICAL_REPRODUCTION_ONLY_NO_ART_OR_PRODUCTION_APPROVAL','source_sha256':sha(source),'baseline_sha256':baseline_sha,'candidate_sha256':candidate_sha,'numeric_and_payload_exact':True,'r01_historical_saved_geometry_semantics_exact':True,'source_categories':13,'targets':2,'triangles':1216,'r06_saved_geometry_and_materials_exact':True,'full_forest_budget_established':False,'rendered':False,'immutable_inputs':True})
 print('R06 PORTABLE SOURCE REPRODUCTION PASS')
if __name__=='__main__':main()
