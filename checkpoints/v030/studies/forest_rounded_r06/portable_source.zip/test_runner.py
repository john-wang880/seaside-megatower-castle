"""Pure portable-controller tests; explicit source/study inputs, never Blender."""
import argparse,importlib.util,json,shutil,subprocess,sys,tempfile
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('controller',ROOT/'run.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',required=True);ap.add_argument('--study-root',required=True);ap.add_argument('--report',required=True);a=ap.parse_args()
 src=r.clean(a.source);study=r.clean(a.study_root);report=r.clean(a.report);r.need(not report.exists(),'Refuse report overwrite')
 checks=[]
 def rejects(name,fn):
  try:fn()
  except (RuntimeError,ValueError,AssertionError):checks.append({'name':name,'pass':True})
  else:raise AssertionError('Expected rejection '+name)
 with tempfile.TemporaryDirectory(prefix='r06-portable-pure-')as temp:
  t=Path(temp);(t/'bin').mkdir();fake=t/'bin/no_blender';fake.write_text('#!/bin/sh\nexit 91\n');fake.chmod(0o700)
  r.preflight(fake,src,study,t/'fresh');checks.append({'name':'actual_external_source_study_preflight','pass':True})
  rejects('parent_traversal',lambda:r.clean(t/'x/../bad'))
  alias=t/'alias';alias.symlink_to(src);rejects('source_symlink',lambda:r.clean(alias))
  rejects('unsafe_manifest',lambda:r.safe_manifest({'../escape':'0'*64}))
  occupied=t/'occupied';occupied.mkdir();rejects('occupied_output',lambda:r.preflight(fake,src,study,occupied))
  rejects('output_inside_bundle',lambda:r.preflight(fake,src,study,ROOT/'forbidden_output'))
  wrong=t/'wrong.blend';wrong.write_bytes(b'not v030');rejects('wrong_source',lambda:r.preflight(fake,wrong,study,t/'wrong-output'))
  bad=ROOT/'SPEC.json';saved=r.load(bad);saved['historical_baseline_sha256']='0'*64;target=t/'bad-binding';target.mkdir();rejects('binding_template_pin',lambda:r.bind_runtime(target,saved,'1'*64))
  # Relocate the complete bundle, preserve exact manifest, then replay from source numerics.
  relocated=t/'relocated_bundle';shutil.copytree(ROOT,relocated);dest=t/'cpu_result'
  cmd=[sys.executable,'-B',str(relocated/'run.py'),'--blender',str(fake),'--source',str(src),'--study-root',str(study),'--output-dir',str(dest),'--cpu-only']
  process=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);r.need(process.returncode==0,process.stdout)
  result=r.load(dest/'SUMMARY.json');r.need(result['pass']and result['no_native_calls'],'CPU replay summary')
  checks.append({'name':'relocated_source_recipe_exact_numeric_and_payload_no_native','pass':True})
  immutable=r.inventory(relocated);manifest=r.load(relocated/'FILES.json');r.need({k:v for k,v in immutable.items()if k!='FILES.json'}==manifest,'Relocation mutated bundle')
  checks.append({'name':'relocated_bundle_immutable','pass':True})
  (relocated/'README.md').write_text((relocated/'README.md').read_text()+'tampered\n')
  spec2=importlib.util.spec_from_file_location('tamper_controller',relocated/'run.py');rr=importlib.util.module_from_spec(spec2);spec2.loader.exec_module(rr)
  rejects('mutated_bundle_inventory',lambda:rr.preflight(fake,src,study,t/'tamper-output'))
 r.write_new(report,{'pass':True,'checks':checks,'native_executed':False,'scope':'Pure controller and source-numeric replay only; full native portable replay remains required'})
 print('PURE PORTABLE TESTS PASS',len(checks))
if __name__=='__main__':main()
