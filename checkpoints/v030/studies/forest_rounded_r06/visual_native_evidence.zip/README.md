# r06 two-tree research evidence, 2026-11-05

This exterior status supersedes the pending-art wording preserved in the immutable source package. The frozen source bytes are unchanged.

Visual outcome: READY FOR A BOUNDED MID-DISTANCE WOODLAND TEST, NOT PRODUCTION. Same-camera original-light close views show substantially reduced planar bell/shelf faces and a shortened, connected narrow crown. Remaining caveats are rounded/topiary character and a conspicuous pale right-center patch on the low tree. The complete authoritative review is visual/REVIEW.json. Full-forest approval and budget remain unestablished; canonical v030 is unchanged, and rejected r01 coast is not adopted.

The recovered local native candidate passed save/reopen 13-category protection, independent exact geometry/material/attachment/envelope checks, and per-face smooth/sharp-face checks. Original candidate SHA256: 1d5a184c1a693818fd44fa604f5e013b7c853caee388ba1d00db294d92f5c54d. The binary is not duplicated in this evidence ZIP; exact saved arrays, build proof, logs and QA are included. The portable source ZIP independently reconstructs from explicitly pinned external v030 and r01 inputs.

Migrated source-only CPU replay and 11 controller checks passed; deterministic/reversed-order geometry reconstruction and 14 negative controls passed. Full portable native source replay was still running when this archive was sealed. This archive does not claim that replay passed; its eventual receipt must be separately sealed.

RUNTIME_RECOVERY.json records official Blender 5.2.3 LTS archive SHA verification and build e13b728c6880 following the missing-runtime exit127. The initial failed log and initial incomplete cap palette rejection remain as provenance. Rendering wall-time differences are not a controlled speed comparison.

Each ZIP has an internal FILES.json, checked against every member SHA256 and size, and ZIP CRC has been verified. No Blender or Git operation was run while assembling these archives.
