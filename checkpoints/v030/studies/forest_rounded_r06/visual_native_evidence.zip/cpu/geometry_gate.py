"""Independent saved-array checks. No bpy, builder imports, mutation or rendering.
Triangle containment uses exact rational clipping against each original Z slab,
then its actual triangulated side planes. This is deliberately conservative.
Attachment requires a strict, exactly checked common interior point, never touch.
"""
from collections import Counter, defaultdict, deque
from fractions import Fraction as F
from pathlib import Path
import argparse, hashlib, json, math, struct

class GateError(ValueError): pass

def need(ok, message):
    if not ok: raise GateError(message)

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def plane(a,b,c):
    n=cross(sub(b,a),sub(c,a)); return n,-dot(n,a)
def value(p,x): return dot(p[0],x)+p[1]
def exact(v): return tuple(F(x) for x in v)
def area(vs,t):
    n=cross(sub(vs[t[1]],vs[t[0]]),sub(vs[t[2]],vs[t[0]])); return math.sqrt(float(dot(n,n)))/2

def clip_z(poly,z,keep_above):
    if not poly: return []
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        da=(a[2]-z)*(1 if keep_above else -1); db=(b[2]-z)*(1 if keep_above else -1)
        if da>=0: out.append(a)
        if (da<0<db) or (db<0<da):
            u=da/(da-db); out.append(tuple(a[i]+u*(b[i]-a[i]) for i in range(3)))
    return list(dict.fromkeys(out))

def old_slabs(old):
    vs=list(map(exact,old['vertices'])); crown=old['crown_vertex_count']; levels=sorted({v[2] for v in vs[:crown]})
    result=[]
    for lo,hi in zip(levels,levels[1:]):
        planes=[]
        for t in old['triangles'][:old['crown_triangles']]:
            zs=[vs[i][2] for i in t]
            if min(zs)==lo and max(zs)==hi:
                planes.append(plane(*(vs[i] for i in t)))
        need(len(planes)>=4,'Frozen proxy slab has insufficient side planes')
        # The old rings are ordered cardinal convex polygons; every face is outward.
        ring=[v for v in vs[:crown] if lo<=v[2]<=hi]
        mid=tuple(sum(v[i] for v in ring)/len(ring) for i in range(3))
        need(all(value(p,mid)<0 for p in planes),'Frozen old side orientation/kernel invalid')
        result.append((lo,hi,planes))
    return result

def prove_contained(old,verts,triangles,face_ids):
    vs=list(map(exact,verts)); slabs=old_slabs(old); zmin,zmax=slabs[0][0],slabs[-1][1]; pieces=0
    for fi in face_ids:
        tri=[vs[i] for i in triangles[fi]]
        need(all(zmin<=p[2]<=zmax for p in tri),f'Crown Z outside actual proxy: face {fi}')
        for lo,hi,planes in slabs:
            poly=clip_z(clip_z(tri,lo,True),hi,False)
            if not poly: continue
            for p in poly:
                for boundary in planes:
                    need(value(boundary,p)<=0,f'Triangle leaves actual piecewise proxy: face {fi}, slab {float(lo)}..{float(hi)}')
            pieces+=1
    return {'method':'Exact rational Z-slab triangle clipping and original outward side-triangle halfspaces; conservative subset of actual piecewise proxy','clipped_polygon_count':pieces,'slab_count':len(slabs),'tolerance':0}

def components(vs,ts):
    by_vertex=defaultdict(list)
    for i,t in enumerate(ts):
        for v in t: by_vertex[v].append(i)
    seen=set(); result=[]
    for start in range(len(ts)):
        if start in seen: continue
        faces=[]; todo=[start]; seen.add(start)
        while todo:
            fi=todo.pop(); faces.append(fi)
            for v in ts[fi]:
                for other in by_vertex[v]:
                    if other not in seen: seen.add(other);todo.append(other)
        result.append(sorted(faces))
    return result

def component_contract(vs,ts,faces):
    counts=Counter(); directed=Counter(); vertices=set(); volume=F(0)
    for fi in faces:
        a,b,c=(vs[i] for i in ts[fi]); n=cross(sub(b,a),sub(c,a)); need(dot(n,n)>0,f'Degenerate triangle {fi}')
        volume+=dot(a,cross(b,c))/6
        for x,y in zip(ts[fi],ts[fi][1:]+ts[fi][:1]): counts[tuple(sorted((x,y)))]+=1;directed[(x,y)]+=1
        vertices.update(ts[fi])
    need(all(n==2 for n in counts.values()),'Open or nonmanifold component edge')
    need(all(directed[(a,b)]==1 and directed[(b,a)]==1 for a,b in counts),'Component inconsistent face orientation')
    need(volume>0,'Component nonpositive signed volume')
    need(len(vertices)-len(counts)+len(faces)==2,'Component not topological sphere')
    ps=[plane(*(vs[i] for i in ts[fi])) for fi in faces]
    return {'faces':faces,'vertices':sorted(vertices),'planes':ps,'volume':volume}

def witness_for(planes):
    """LP only proposes witness; exact rational strict inequalities certify it."""
    import numpy as np
    from scipy.optimize import linprog
    a=[];b=[]
    for n,d in planes:
        norm=math.sqrt(float(dot(n,n))); need(norm>0,'Zero plane')
        a.append([float(x)/norm for x in n]+[1.]);b.append(-float(d)/norm)
    sol=linprog([0,0,0,-1],A_ub=np.array(a),b_ub=np.array(b),bounds=[(None,None)]*3+[(0,None)],method='highs')
    if not sol.success or sol.x[3]<=0: return None
    p=exact(sol.x[:3].tolist())
    if not all(value(q,p)<0 for q in planes): return None
    radius=F(min(-float(value(q,p))/math.sqrt(float(dot(q[0],q[0]))) for q in planes)/2)
    while radius>0 and not all(value(q,p)**2>radius**2*dot(q[0],q[0]) for q in planes): radius/=2
    need(radius>0,'Unable to certify positive attachment radius')
    return {'point':[float(x) for x in p],'radius_lower_bound':float(radius)}

def prove_attachments(comps,stem_index):
    # A graph of positive-volume intersections must connect every mass to the old stem.
    for i,c in enumerate(comps):
        c['kernel']=witness_for(c['planes']);need(c['kernel'] is not None,f'Component {i} has no strict interior kernel')
    connected={stem_index};remaining=set(range(len(comps)))-connected;links=[]
    while remaining:
        found=None
        for i in sorted(remaining):
            for j in sorted(connected):
                p=witness_for(comps[i]['planes']+comps[j]['planes'])
                if p is not None: found=(i,j,p);break
            if found: break
        need(found is not None,'Detached mass: no positive-volume attachment path to preserved root/stem')
        i,j,p=found;connected.add(i);remaining.remove(i);links.append({'component':i,'attached_to':j,**p})
    return links

def stem_faces(old,vs,ts):
    oldvs=old['vertices'][old['crown_vertex_count']:]; found=[]
    for v in oldvs:
        inds=[i for i,w in enumerate(vs) if w==v];need(len(inds)==1,'Original exact stem coordinate missing or duplicated');found.append(inds[0])
    expected=[[found[i-old['crown_vertex_count']] for i in t] for t in old['triangles'][old['crown_triangles']:]]
    result=[]
    for t in expected:
        hits=[i for i,q in enumerate(ts) if q==t];need(len(hits)==1,'Original exact stem face missing, reordered or duplicated');result.append(hits[0])
    need(len(result)==8,'Original stem must retain 8 triangles')
    return result

def validate_row(row,old,palette,attachments=True):
    ident=old['id'];need(row['id']==ident,'Row identity mismatch');vs=row['vertices'];ts=row['triangles']
    need(vs and all(len(v)==3 and all(type(x) in (int,float) and math.isfinite(x) and struct.unpack('<f',struct.pack('<f',x))[0]==x for x in v) for v in vs),'Vertices must be finite saved float32')
    need(ts and all(len(t)==3 and len(set(t))==3 and all(type(i) is int and 0<=i<len(vs) for i in t) for t in ts),'Invalid triangle indices')
    need({i for t in ts for i in t}==set(range(len(vs))),'Loose or unused vertices')
    need(len(ts)==palette['budget_triangles'],'Per-ID triangle budget drift')
    stem=stem_faces(old,vs,ts);crown=sorted(set(range(len(ts)))-set(stem));ex=list(map(exact,vs))
    cv=old['crown_vertex_count'];need(vs[cv:cv+6]==old['vertices'][cv:] and [ts[i] for i in stem]==old['triangles'][old['crown_triangles']:],'Original stem index slots/triples changed')
    groups=components(vs,ts);contracts=[component_contract(ex,ts,g) for g in groups]
    stem_idx=next((i for i,g in enumerate(groups) if set(g)==set(stem)),None);need(stem_idx is not None,'Stem merged or altered')
    containment=prove_contained(old,vs,ts,crown)
    links=prove_attachments(contracts,stem_idx) if attachments else []
    need(isinstance(row.get('face_smooth'),list) and all(type(v)is bool for v in row['face_smooth']) and row.get('face_smooth')==[role>=3 for role in row['face_role_indices']],'Explicit foliage-only smooth payload mismatch')
    roles=row['face_role_indices'];need(len(roles)==len(ts) and all(type(k) is int and 0<=k<=5 for k in roles),'Face semantic role array invalid')
    declarations=row['components'];need(len(declarations)==len(groups),'Component declaration count mismatch')
    named={d['name']:d for d in declarations};need(len(named)==len(declarations) and {'root_stem','woody_continuation','slender_leader'}<=set(named),'Component semantic names invalid')
    actualsets={tuple(g) for g in groups};covered=[]
    for d in declarations:
        lo,hi=d['face_range'];fs=list(range(lo,hi));need(tuple(fs) in actualsets,'Declared component does not match actual connectivity')
        need(set(d['vertex_indices'])=={i for f in fs for i in ts[f]},'Declared component vertex membership false')
        covered.extend(fs)
        name=d['name']
        if name=='root_stem': expectedroles=[0]*8;need(set(fs)==set(stem),'Wrong declared root stem')
        elif name=='woody_continuation': expectedroles=[1]*12
        elif name=='slender_leader': expectedroles=[2]*12
        else: need(name.startswith('bough_'),'Unknown component semantic name');expectedroles=[3]*6+[4]*24+[5]*6
        need(roles[lo:hi]==expectedroles,'Actual semantic component roles changed: '+name)
        if name.startswith('bough_'):
            need(len(d['vertex_indices'])==20 and hi-lo==36,'Rounded explicit topology mismatch')
            for fi in fs:
                boundary=plane(*(ex[i] for i in ts[fi]))
                need(all(value(boundary,ex[j])<=0 for j in d['vertex_indices']),'Rounded cluster not exactly convex')
    need(sorted(covered)==list(range(len(ts))),'Semantic component coverage invalid')
    comp_by_faces={tuple(c['faces']):c for c in contracts}
    for d in declarations:
        if d['name']=='root_stem': need(d['parent'] is None,'Root parent changed');continue
        need(d['parent'] in named,'Unknown intended attachment parent')
        parent=named[d['parent']];own=comp_by_faces[tuple(range(*d['face_range']))];other=comp_by_faces[tuple(range(*parent['face_range']))]
        witness=exact(d['attachment_witness']);radius=F(d['attachment_ball_radius']);need(radius>0,'Declared attachment ball is not positive')
        for boundary in own['planes']+other['planes']:
            distance=value(boundary,witness)
            need(distance<0 and distance*distance>radius*radius*dot(boundary[0],boundary[0]),'Declared positive-volume attachment ball invalid for actual saved faces')
    materials=palette['_materials']+['Pine bark'];mi=row['face_material_indices'];need(len(mi)==len(ts),'Face material array length')
    need(len(materials)==len(set(materials)) and set(materials)<=set(palette['_materials']+['Pine bark']),'Unknown/duplicate material slots')
    need(all(type(i) is int and 0<=i<len(materials) for i in mi),'Invalid material slot index')
    role=[materials[i] for i in mi];wood=[i for i,r in enumerate(roles) if r in (0,1)];foliage=[i for i,r in enumerate(roles) if r>=2];need(all(role[i]=='Pine bark' for i in wood),'Preserved stem/woody continuation bark changed');need(all(role[i]!='Pine bark' for i in foliage),'Foliage assigned bark')
    area_by=defaultdict(float)
    for i in foliage: area_by[role[i]]+=area(vs,ts[i])
    total=sum(area_by.values());need(total>0,'Zero foliage area')
    base=palette['base_material'];sec=None if palette['secondary_slot'] is None else palette['_materials'][palette['secondary_slot']];tip=palette['_materials'][2]
    need(set(area_by)<={base,sec,tip},'Material assignment not allowed by per-ID palette')
    need(area_by[base]/total>=1-palette['secondary_target_foliage_area_fraction']-palette['tip_target_foliage_area_fraction']-1e-12,'Base area below approved minimum')
    need(area_by[tip]/total<=palette['tip_target_foliage_area_fraction']+1e-12,'Tip surface fraction exceeds source/palette cap')
    if sec: need(area_by[sec]/total<=palette['secondary_target_foliage_area_fraction']+1e-12,'Secondary surface fraction exceeds source/palette cap')
    for g in groups:
        if set(g)==set(stem): continue
        need(not all(role[i]==tip for i in g),'Whole component assigned Sunlit tips')
        for fi in g:
            if role[fi]==tip:
                need(roles[fi]==5,'Sunlit face is not a distal bough cap');p,q,r=[vs[i] for i in ts[fi]];need(cross(sub(q,p),sub(r,p))[2]>0,'Sunlit face is not an upper surface')
    tip_boughs=[]
    for d in declarations:
        lo,hi=d['face_range'];patch=[i for i in range(lo,hi) if role[i]==tip]
        if not patch: continue
        need(d['name'].startswith('bough_'),'Sunlit outside distal boughs');tip_boughs.append(d['name'])
        upper=[]
        for fi in range(lo,hi):
            if roles[fi]!=5: continue
            a,b,c=[vs[k] for k in ts[fi]]
            if cross(sub(b,a),sub(c,a))[2]>0: upper.append(fi)
        clusters=[];remaining=set(upper)
        while remaining:
            seed=min(remaining);cluster={seed};todo=[seed];remaining.remove(seed)
            while todo:
                a=todo.pop()
                for b in list(remaining):
                    if len(set(ts[a])&set(ts[b]))==2:cluster.add(b);todo.append(b);remaining.remove(b)
            clusters.append(cluster)
        need(any(set(patch)==cluster for cluster in clusters),'Sunlit patch is not a complete connected upper distal group')
        need(not sec or not any(role[i]==sec for i in range(lo,hi)),'Same bough has secondary and Sunlit patch')
    need(len(tip_boughs)<=2,'Sunlit patch uses more than two boughs')
    secondary_boughs=[]
    if sec:
        for d in declarations:
            lo,hi=d['face_range'];patch=[i for i in range(lo,hi) if role[i]==sec]
            if not patch: continue
            need(d['name'].startswith('bough_'),'Secondary color outside localized boughs');need(len(patch)==hi-lo,'Secondary patch must be one coherent whole bough');secondary_boughs.append(int(d['name'].split('_')[1]))
            reached={patch[0]};todo=[patch[0]]
            while todo:
                a=todo.pop()
                for b in patch:
                    if b not in reached and len(set(ts[a])&set(ts[b]))==2: reached.add(b);todo.append(b)
            need(len(reached)==len(patch),'Secondary patch is not edge-connected')
        need(len(secondary_boughs)<=1,'Secondary patch exceeds one bough')
    return {'id':ident,'triangles':len(ts),'components':len(groups),'stem_exact':True,'closure_orientation_nondegenerate':True,'component_volumes':[float(c['volume']) for c in contracts],'piecewise_containment':containment,'positive_volume_attachment_links':links,'material_area_fractions':{k:v/total for k,v in sorted(area_by.items())}}

def validate_frozen_and_palette(frozen,palette):
    known={'arrays.json':'bffe5fedcbebd6a22cd1520c64e58e90a856329bf8db39e6f344befca6f9d34b','plan.json':'94cdd1c541d38870c662adc6ba98e18f3a8b57b49d3eb7ee2e49c03ee8f7bcd6','material_map.json':'4dffc504ec48489f5fd3330a55184e6b8ee91d2bbd957f129c7fb3de4ac78d15','foliage_graphs.json':'9f3a4199050f31828549deec1e92f752a34e7a3019dfe9c436b04c5bb69b3d78'}
    loaded={}
    for name,h in known.items():
        matches=[(p,v) for p,v in frozen['origin_sha256'].items() if Path(p).name==name]
        need(len(matches)==1,'Frozen origin missing or ambiguous '+name);p,v=matches[0];need(v==h==sha(p),'Frozen source origin hash drift '+name);loaded[name]=json.loads(Path(p).read_text())
    canonical='9f020b7ec6eda309d674653598b169f65ba5dc1d1f194ffa31323f6393feda35'
    need(frozen['source_sha256']==palette['source_sha256']==canonical and frozen['baseline_sha256']=='b9b71ca13b2ba3f8cdb32e16b326a3baaa904f0cc1c2d3f558979fb33a0923a1','Source identities changed')
    arrays={r['id']:r for r in loaded['arrays.json']['candidates']};plan={r['id']:r for r in loaded['plan.json']['candidates']};mat={r['id']:r for r in loaded['material_map.json']['rows']}
    need(palette['materials']==loaded['material_map.json']['materials'],'Source material list changed')
    for row in frozen['rows']:
        ident=row['id'];need(row==dict(arrays[ident],role=plan[ident]['role'],crown_triangles=plan[ident]['crown_triangles']),'Frozen proxy snapshot differs from pinned source '+ident)
    for row in palette['rows']:
        ident=row['id'];areas=mat[ident]['assigned_source_triangle_area_by_slot'];base=max((0,1),key=lambda i:(areas[i],-i));need(areas[base]>0 and not row['authored_fallback'],'Trial base lacks dark source evidence')
        sec=max((i for i in (0,1,3) if i!=base),key=lambda i:(areas[i],-i));sec=sec if areas[sec]>0 else None
        secondary=0. if sec is None else min(.16,areas[sec]/sum(areas[i] for i in (0,1,3)));tips=min(.06,areas[2]/sum(areas))
        need(row['base_slot']==base and row['base_material']==palette['materials'][base] and row['secondary_slot']==sec,'Per-ID palette source-evidence mapping changed '+ident)
        need(row['source_associated_triangle_area_by_slot']==areas and row['secondary_target_foliage_area_fraction']==secondary and row['tip_target_foliage_area_fraction']==tips,'Per-ID source area cap changed '+ident)
    return True

def run(payload,frozen,palette,attachments=True):
    validate_frozen_and_palette(frozen,palette)
    rows=payload.get('rows',payload.get('candidates'));need(isinstance(rows,list),'Geometry rows missing')
    need(payload['materials']==palette['materials']+['Pine bark'],'Exact reused material slot order')
    expect=frozen['selected_ids'];need(set(expect)=={'source_axis_27970','source_axis_17660'} and len(expect)==2,'Exact r06 two-tree identities');need(len(rows)==2 and {r['id'] for r in rows}==set(expect),'Exact two target IDs required')
    old={r['id']:r for r in frozen['rows']};pal={r['id']:dict(r,_materials=palette['materials']) for r in palette['rows']};by={r['id']:r for r in rows}
    reports=[validate_row(by[i],old[i],pal[i],attachments) for i in expect]
    need(sum(r['triangles'] for r in reports)==1216,'Exact trial 1216 triangle budget')
    need(palette['triangle_budget']=={'trial':1216,'cap_two_tree':1216,'full_forest_planned':False},'Exact two-tree budget scope changed')
    return {'pass':True,'scope':'Independent exact saved-array validation, not visual acceptance','targets':2,'triangles':1216,'reports':reports}

def verify_geometry_lineage(payload,numeric):
    actual=payload.get('rows',payload.get('candidates'));original=numeric['candidates']
    need(len(actual)==len(original)==2,'Geometry lineage count')
    by={r['id']:r for r in original};need({r['id'] for r in actual}==set(by),'Geometry lineage IDs')
    for row in actual:
        need({k:v for k,v in row.items() if k!='face_material_indices'}=={k:v for k,v in by[row['id']].items() if k!='face_material_indices'},'Palette or saved export changed numeric geometry/roles/metadata '+row['id'])
    return True

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--geometry',required=True);ap.add_argument('--frozen',required=True);ap.add_argument('--palette',required=True);ap.add_argument('--report',required=True);ap.add_argument('--numeric-geometry',required=True);a=ap.parse_args()
    paths=[Path(p).resolve() for p in [a.geometry,a.frozen,a.palette,a.numeric_geometry]];pins={str(p):sha(p) for p in [*paths,Path(__file__).resolve()]};data=[json.loads(p.read_text()) for p in paths]
    for path,h in data[1]['origin_sha256'].items(): need(sha(path)==h,'Frozen origin drift');pins[path]=h
    verify_geometry_lineage(data[0],data[3]);report=run(*data[:3]);report['numeric_geometry_lineage_exact']=True;need(all(sha(p)==h for p,h in pins.items()),'Input changed while checking');report['input_sha256']=pins
    p=Path(a.report);need(not p.exists(),'Refuse occupied report');p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'pass':True,'targets':2,'triangles':1216,'report':str(p)}))
if __name__=='__main__': main()
