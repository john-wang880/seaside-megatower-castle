"""Pure policy checks for reopened snapshots. No blanket target field exceptions."""
class PreservationError(ValueError): pass

def need(v,m):
    if not v: raise PreservationError(m)

def compare(base,candidate,targets):
    targets=set(targets)
    need(set(base)==set(candidate) and len(base)==13,'Expected exact 13 snapshot categories')
    need(set(candidate['objects'])==set(base['objects']),'Object additions/deletions refused')
    added=set(candidate['meshes'])-set(base['meshes']);need(len(added)==2 and set(base['meshes'])<=set(candidate['meshes']),'Exactly two new meshes and all old meshes retained')
    changes={n for n in base['objects'] if candidate['objects'][n]!=base['objects'][n]};need(changes==targets,'Changed objects must be exactly two targets')
    for cat in base:
        if cat in ['objects','visible_evaluated','meshes']: continue
        need(candidate[cat]==base[cat],'Unchanged category drift: '+cat)
    for cat in ['objects','visible_evaluated']:
        need(set(candidate[cat])==set(base[cat]),'Category names changed: '+cat)
        need(all(candidate[cat][n]==v for n,v in base[cat].items() if n not in targets),'Non-target drift: '+cat)
    need(all(candidate['meshes'][n]==v for n,v in base['meshes'].items()),'An original/study mesh changed')
    return sorted(added)

def check_rollback(base,rollback,added):
    trimmed=dict(rollback);trimmed['meshes']={n:v for n,v in rollback['meshes'].items() if n not in added}
    need(trimmed==base,'Full rollback 13-category identity failed')
    return True
