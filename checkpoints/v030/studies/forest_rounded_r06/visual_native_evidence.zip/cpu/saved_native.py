"""Read-only reopened two-tree r06 trial native gate. Never saves, renders or deletes.
Only temporary in-memory reassignment of the two old mesh pointers is performed,
to prove the complete baseline state by rollback across all 13 snapshot categories.
"""
import argparse,copy,hashlib,importlib.util,json,sys
from collections import Counter
from pathlib import Path
sys.dont_write_bytecode=True
BASE_SHA='b9b71ca13b2ba3f8cdb32e16b326a3baaa904f0cc1c2d3f558979fb33a0923a1'
SOURCE_SHA='9f020b7ec6eda309d674653598b169f65ba5dc1d1f194ffa31323f6393feda35'
PREFIX='UNACCEPTED r01 | woodland '

def need(v,msg):
    if not v: raise RuntimeError(msg)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def safe(p,exists=True):
    p=Path(p).absolute();need(p.resolve()==p and '..' not in p.parts and not any(q.is_symlink() for q in [p,*p.parents]),'Unsafe aliased path')
    need(p.is_file() if exists else not p.exists() and p.parent.is_dir(),'Path availability: '+str(p));return p

def main():
    need(not sys.flags.optimize,'Optimized Python refused')
    ap=argparse.ArgumentParser()
    for n in ['baseline','canonical','candidate','candidate-sha','geometry','frozen','palette','native-common','report','export']: ap.add_argument('--'+n,required=True)
    a=ap.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else sys.argv[1:])
    paths={k:safe(getattr(a,k)) for k in ['baseline','canonical','candidate','geometry','frozen','palette','native_common']};rp=safe(a.report,False);ep=safe(a.export,False)
    need(len({*paths.values(),rp,ep})==len(paths)+2,'Input/output alias')
    need(sha(paths['baseline'])==BASE_SHA and sha(paths['canonical'])==SOURCE_SHA and sha(paths['candidate'])==a.candidate_sha,'Exact source/candidate identities')
    frozen=load(paths['frozen']);payload=load(paths['geometry']);palette=load(paths['palette']);rows=payload.get('rows',payload.get('candidates'));ids=frozen['selected_ids'];old={r['id']:r for r in frozen['rows']};expected={r['id']:r for r in rows};targets={PREFIX+i for i in ids}
    need(set(ids)=={'source_axis_27970','source_axis_17660'} and len(ids)==2 and len(rows)==2 and set(expected)==set(ids),'Exact target set')
    need(frozen['baseline_sha256']==BASE_SHA and frozen['source_sha256']==SOURCE_SHA,'Frozen source identity')
    support=paths['native_common'].parent/'snapshot_support.py';need(support.is_file(),'Native support missing')
    pins={str(p):sha(p) for p in [*paths.values(),support,Path(__file__),Path(__file__).parent/'preservation_gate.py']}
    for p,h in frozen['origin_sha256'].items(): need(sha(p)==h,'Frozen original input changed');pins[p]=h
    import bpy
    need(bpy.app.version==(5,2,3),'Reviewed Blender 5.2.3 required')
    need(not bpy.data.filepath,'Factory-empty Blender required')
    sys.path.insert(0,str(paths['native_common'].parent));spec=importlib.util.spec_from_file_location('trial_native_common',paths['native_common']);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
    def snap(): return c.normalized(c.snap())
    def meshflags():
        result={}
        skip={'rna_type','users','session_uid','is_updated','is_updated_data','is_evaluated','is_runtime_data','original','tag','is_embedded_data','is_missing','is_library_indirect','is_editable','is_editmode'}
        for m in bpy.data.meshes:
            state={}
            for prop in m.bl_rna.properties:
                if prop.identifier in skip: continue
                if prop.type in {'BOOLEAN','INT','FLOAT','STRING','ENUM'}:
                    state[prop.identifier]=c.ss.val(getattr(m,prop.identifier))
            state['animation_data']=c.ss.primitive(m.animation_data) if m.animation_data else None
            result[m.name]=state
        return result
    print('BASELINE_OPEN',flush=True);bpy.ops.wm.open_mainfile(filepath=str(paths['baseline']),load_ui=False,use_scripts=False);base,baseui=snap();baseflags=meshflags();oldnames={n:bpy.data.objects[n].data.name for n in targets}
    need(len(set(oldnames.values()))==2,'Targets must have distinct meshes')
    for ident in ids:
        o=bpy.data.objects[PREFIX+ident];r=old[ident];need([list(v.co) for v in o.data.vertices]==r['vertices'] and [list(p.vertices) for p in o.data.polygons]==r['triangles'],'Reopened baseline does not match frozen actual proxy '+ident)
    print('CANDIDATE_OPEN',flush=True);bpy.ops.wm.open_mainfile(filepath=str(paths['candidate']),load_ui=False,use_scripts=False);candidate,candui=snap();candflags=meshflags()
    sys.path.insert(0,str(Path(__file__).parent));import preservation_gate as pg
    added=set(pg.compare(base,candidate,targets))
    for n,v in baseflags.items():
        actual=copy.deepcopy(candflags[n]);allowed=n in oldnames.values()
        if allowed:
            need(actual['use_fake_user'] is True,'Detached old proxy not retained with fake user: '+n);actual['use_fake_user']=v['use_fake_user']
        need(actual==v,'Mesh state changed outside allowed old-proxy fake user: '+n)
    exports=[];newnames={};saved_counts={};meta={}
    for ident in ids:
        name=PREFIX+ident;o=bpy.data.objects[name];m=o.data;r=expected[ident];newnames[name]=m.name
        need(m.name in added and m.users==1 and not m.use_fake_user,'New owned mesh ownership mismatch '+name)
        need(not o.modifiers and not o.constraints and not o.vertex_groups and not o.animation_data and not m.animation_data,'New dependencies refused '+name)
        need(not m.shape_keys and not m.uv_layers and not m.color_attributes and not m.has_custom_normals,'Unexpected new mesh layers '+name)
        need([list(v.co) for v in m.vertices]==r['vertices'] and [list(p.vertices) for p in m.polygons]==r['triangles'],'Exact saved arrays mismatch '+name)
        materials=[s.material.name if s.material else None for s in o.material_slots];need(materials==payload['materials'],'Saved material names mismatch '+name)
        need(all(s.link=='DATA' and s.material.as_pointer()==bpy.data.materials[s.material.name].as_pointer() for s in o.material_slots),'Material pointer/link mismatch '+name)
        need([p.material_index for p in m.polygons]==r['face_material_indices'],'Saved polygon material roles mismatch '+name)
        need([p.use_smooth for p in m.polygons]==r['face_smooth'] and all(not p.hide for p in m.polygons),'Saved per-face smooth/hidden contract '+name)
        need(not any(v.hide for v in m.vertices) and not any(e.hide or e.use_seam or e.use_edge_sharp for e in m.edges),'Unexpected hidden/sharp/seam state '+name)
        need(not list(m.items()),'Unexpected new mesh custom properties '+name)
        schemas={'position':('POINT','FLOAT_VECTOR',len(m.vertices)),'.edge_verts':('EDGE','INT32_2D',len(m.edges)),'.corner_vert':('CORNER','INT',len(m.loops)),'.corner_edge':('CORNER','INT',len(m.loops)),'.select_vert':('POINT','BOOLEAN',len(m.vertices)),'.select_edge':('EDGE','BOOLEAN',len(m.edges)),'.select_poly':('FACE','BOOLEAN',len(m.polygons)),'sharp_face':('FACE','BOOLEAN',len(m.polygons)),'material_index':('FACE','INT',len(m.polygons))}
        need({at.name:(at.domain,at.data_type,len(at.data)) for at in m.attributes}==schemas,'Exact generated builtin attribute schema mismatch '+name)
        for attr in ['.select_vert','.select_edge','.select_poly']: need(all(d.value is True for d in m.attributes[attr].data),'Unexpected builtin selection/flat-shading data '+name)
        need([d.value for d in m.attributes['sharp_face'].data]==[not v for v in r['face_smooth']],'Exact saved sharp_face inverse of smooth payload '+name)
        need([list(d.vector) for d in m.attributes['position'].data]==r['vertices'],'Position attribute data mismatch '+name)
        need([d.value for d in m.attributes['material_index'].data]==r['face_material_indices'],'Material attribute data mismatch '+name)
        need([d.value for d in m.attributes['.corner_vert'].data]==[i for face in r['triangles'] for i in face],'Corner vertex attribute mismatch '+name)
        need([d.value for d in m.attributes['.corner_edge'].data]==[l.edge_index for l in m.loops],'Corner edge attribute mismatch '+name)
        need([list(d.value) for d in m.attributes['.edge_verts'].data]==[list(e.vertices) for e in m.edges],'Edge vertex attribute mismatch '+name)
        expected_edges={tuple(sorted((face[j],face[(j+1)%3]))) for face in r['triangles'] for j in range(3)}
        need(Counter(tuple(sorted(e.vertices)) for e in m.edges)==Counter(expected_edges),'Saved undirected edge topology changed '+name)
        for face in m.polygons:
            for j,loop in enumerate(face.loop_indices): need(set(m.edges[m.loops[loop].edge_index].vertices)=={face.vertices[j],face.vertices[(j+1)%3]},'Saved face-corner edge correspondence changed '+name)
        meta[ident]=schemas
        need([list(v) for v in o.matrix_world]==[[float(i==j) for j in range(4)] for i in range(4)],'World-coordinate transform changed '+name)
        need(not o.hide_render and not o.hide_viewport and all(o.visible_get(view_layer=v) and not o.hide_get(view_layer=v) for v in bpy.context.scene.view_layers),'Target visibility changed '+name)
        exported=copy.deepcopy(r);exported.update(vertices=[list(v.co) for v in m.vertices],triangles=[list(p.vertices) for p in m.polygons],face_material_indices=[p.material_index for p in m.polygons],face_smooth=[p.use_smooth for p in m.polygons]);exports.append(exported);saved_counts[ident]=len(m.polygons)
    need(set(newnames.values())==added,'Every new mesh used only by intended target')
    need(sum(saved_counts.values())==1216,'Saved triangle budget mismatch')
    for n in targets: bpy.data.objects[n].data=bpy.data.meshes[oldnames[n]]
    rollback,rbui=snap();pg.check_rollback(base,rollback,added)
    need(all(sha(p)==h for p,h in pins.items()),'A source/candidate/input/runtime file changed during QA')
    out={'pass':True,'baseline_sha256':BASE_SHA,'canonical_sha256':SOURCE_SHA,'candidate_sha256':a.candidate_sha,'source_categories':list(base),'full_rollback_13categories':True,'non_target_objects_exact':True,'all_old_meshes_exact':True,'all_materials_lights_world_cameras_collections_exact':True,'old_proxy_fake_user_only_exception':sorted(oldnames.values()),'added_meshes':sorted(added),'changed_objects':sorted(targets),'target_triangles':saved_counts,'total_trial_triangles':1216,'exact_generated_attribute_schemas':meta,'input_sha256':pins,'no_save_render':True,'UI_normalization':{'baseline':baseui,'candidate':candui,'rollback':rbui},'geometry_validation_pending':True}
    ep.write_text(json.dumps({'schema':'reopened_trial_geometry_v1','candidate_sha256':a.candidate_sha,'materials':payload['materials'],'rows':exports},separators=(',',':'))+'\n');out['export_sha256']=sha(ep);rp.write_text(json.dumps(out,indent=2)+'\n');print('SAVED TRIAL NATIVE PRESERVATION PASS',flush=True)
if __name__=='__main__':main()
