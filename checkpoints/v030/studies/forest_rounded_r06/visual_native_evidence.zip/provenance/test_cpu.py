"""Independent controls and deterministic reconstruction for the bounded r06 study."""
from pathlib import Path
import copy,importlib.util,json,sys,hashlib
sys.dont_write_bytecode=True
H=Path(__file__).resolve().parent

def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
G=module('r06_gen',H/'geometry/generate_forest.py');Q=module('r06_gate',H/'qa/geometry_gate.py')
a=json.loads((H/'geometry/arrays.json').read_text());b=json.loads((H/'payload.json').read_text());f=json.loads((H/'qa/FROZEN_OLD_INPUTS.json').read_text());p=json.loads((H/'PALETTE_2.json').read_text())
inputs=H.parents[1]/'recovery_20261102/r01/reproduce/forest/inputs'
ids=['source_axis_27970','source_axis_17660'];rebuild=G.generate(inputs,ids=ids);assert json.loads(json.dumps(rebuild))==a
reverse=G.generate(inputs,ids=list(reversed(ids)));assert {r['id']:r for r in json.loads(json.dumps(reverse))['candidates']}=={r['id']:r for r in a['candidates']}
old={r['id']:r for r in f['rows']};pal={r['id']:dict(r,_materials=p['materials']) for r in p['rows']}
controls=[]
def reject(name,change):
 row=copy.deepcopy(b['candidates'][0]);change(row)
 try:Q.validate_row(row,old[row['id']],pal[row['id']],attachments=True)
 except (Q.GateError,ValueError,IndexError) as e:controls.append({'name':name,'rejected':True,'reason':str(e)})
 else:raise AssertionError('Control accepted: '+name)
reject('out_of_envelope',lambda r:r['vertices'][0].__setitem__(0,r['vertices'][0][0]+64.0))
reject('reverse_closed_component_orientation',lambda r:[r['triangles'].__setitem__(i,list(reversed(r['triangles'][i]))) for i in range(*r['components'][3]['face_range'])])
reject('missing_triangle',lambda r:r['triangles'].pop())
reject('stem_coordinate_change',lambda r:r['vertices'][r['source_crown_vertex_count']].__setitem__(0,r['vertices'][r['source_crown_vertex_count']][0]+0.25))
reject('declared_attachment_outside',lambda r:r['components'][3].__setitem__('attachment_witness',[0.,0.,0.]))
reject('bark_on_foliage',lambda r:r['face_material_indices'].__setitem__(40,4))
reject('whole_sunlit_bough',lambda r:[r['face_material_indices'].__setitem__(i,2) for i in range(*r['components'][3]['face_range'])])
reject('non_float32_coordinate',lambda r:r['vertices'][0].__setitem__(0,r['vertices'][0][0]+0.00000001))
reject('foliage_smooth_flag_changed',lambda r:r['face_smooth'].__setitem__(r['components'][3]['face_range'][0],False))
reject('root_smooth_flag_changed',lambda r:r['face_smooth'].__setitem__(0,True))
reject('integer_smooth_flag_refused',lambda r:r['face_smooth'].__setitem__(0,0))
def indent_cluster(r):
    import struct
    c=r['components'][3];v=c['vertex_indices'][7];anchor=c['attachment_witness']
    r['vertices'][v]=[struct.unpack('<f',struct.pack('<f',(x+y)/2))[0]for x,y in zip(r['vertices'][v],anchor)]
reject('indented_nonconvex_cluster',indent_cluster)
def shift_cluster(r):
    import struct
    for i in r['components'][3]['vertex_indices']:
        r['vertices'][i][0]=struct.unpack('<f',struct.pack('<f',r['vertices'][i][0]+64.0))[0]
reject('whole_cluster_outside_source_envelope',shift_cluster)
# Detach entire branch while keeping its topology: use a deliberately false contact witness as a separate control above.
# Here certify geometric attachment directly on two disjoint copies of a valid component.
row=b['candidates'][0];c=row['components'][3];faces=list(range(*c['face_range']));vs=list(map(Q.exact,row['vertices']));first=Q.component_contract(vs,row['triangles'],faces)
shifted=[tuple(x+(64 if j==0 else 0) for j,x in enumerate(v)) for v in vs];second=Q.component_contract(shifted,row['triangles'],faces)
assert Q.witness_for(first['planes']+second['planes']) is None
controls.append({'name':'detached_mass_no_positive_volume_contact','rejected':True})
report={'pass':True,'exact_source_only_rebuild_equal':True,'selection_order_invariant':True,'controls':controls,'source_model_not_opened':True,'native_tests_not_run':True,'full_forest_budget_not_established':True}
(H/'qa/CPU_TESTS.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
