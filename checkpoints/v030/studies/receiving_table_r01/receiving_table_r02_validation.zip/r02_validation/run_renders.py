import fcntl,json,subprocess,time,hashlib,os
from pathlib import Path
D=Path(__file__).resolve().parent;R=D.parents[2];B=R.parent/'blender/blender-5.2.3-linux-x64/blender';old=D.parent/'r01_workbench';src=R/'checkpoints/v030/restored/castle_v030.blend';cand=old/'candidate.blend'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
lock=open(R/'work/.castle-heavy.lock','a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
active={'task':'receiving r02 supplemental validation','directory':str(D.relative_to(R)),'status':'RUNNING','pid':os.getpid(),'heavy_lock_acquired':True,'jobs_completed':[],'model_changes':False,'git_or_upload':False}
def update():
 (D/'ACTIVE.json').write_text(json.dumps(active,indent=2)+'\n');(D.parent/'ACTIVE.json').write_text(json.dumps(active,indent=2)+'\n')
try:
 update()
 for name,view,source,manifest,script in [('stores_return_candidate','stores_return',cand,'stores_return_candidate_views.json','render_one.py'),('reverse_source','reverse_connection',src,'reverse_source_views.json','render_source.py'),('reverse_candidate','reverse_connection',cand,'reverse_candidate_views.json','render_one.py')]:
  active['current']=name;update();t=time.monotonic()
  with open(D/(name+'.log'),'w') as log:
   r=subprocess.run([str(B),'-b','-t','8','--python-exit-code','1','--python',str(D/script),'--','--source',str(source),'--source-sha',sha(source),'--manifest',str(D/manifest),'--output-dir',str(D/name),'--view',view],stdout=log,stderr=subprocess.STDOUT)
  assert r.returncode==0,(name,r.returncode)
  active['jobs_completed'].append({'name':name,'wall_seconds':time.monotonic()-t});update()
 active['status']='RENDERS_DONE_VALIDATION_PENDING'
except BaseException as ex:
 active['status']='FAILED';active['error']=repr(ex);raise
finally:
 active['heavy_lock_acquired']=False;active.pop('current',None);update();fcntl.flock(lock,fcntl.LOCK_UN)
