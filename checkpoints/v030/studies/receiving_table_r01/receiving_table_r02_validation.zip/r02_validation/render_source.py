import runpy,sys,json,hashlib
from pathlib import Path
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent
runpy.run_path(str(D/"render_one.py"),run_name="__main__")
import export_support as e
assert e.sha(e.S)==e.PIN
components=e.source_export()
(D/"source_operation_actual.json").write_text(json.dumps({"source_sha256":e.PIN,"broadphase_envelope":[[12,34.8,28.9],[14.5,37,31.2]],"components":components,"source_saved":False,"source_sha256_after":e.sha(e.S)},indent=2)+"\n")
assert e.sha(e.S)==e.PIN
