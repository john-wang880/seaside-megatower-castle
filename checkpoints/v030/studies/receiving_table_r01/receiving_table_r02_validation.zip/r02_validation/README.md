# R02: fixed return views and bounded operation validation

This round does not change or rebuild the accepted local study. Formal source remains v030, SHA256 9f020b7ec6eda309d674653598b169f65ba5dc1d1f194ffa31323f6393feda35. The sole table candidate remains ../r01_workbench/candidate.blend, SHA256 c53e1e7c396322f7c051255fc6b5e77defb79a3fbffbb27815054435727b315b. No new blend, model/material/light/exposure edits, save, Git writes, upload or publication.

## Earlier evidence, not newly repeated

R01 proved the 108-triangle, nine-cuboid table, four whole supported feet, positive joints, exact source geometry clearance, nine protected route bodies, saved/reopened 13-category preservation and rollback. Its original doorway image received independent bounded local visual acceptance. Those results belong to r01, not this round. PRIOR_FILES_BEFORE.json pins every prior r01 file and finalization checks every hash unchanged. Remote backup/upload remains pending. Any separately prepared local complete backup and its independent extraction audit are outside this validation directory; see the parallel completion audit.

## This round's three necessary actual renders

The plan was declared before rendering. Exactly one Blender process at a time runs under work/.castle-heavy.lock, updating this directory and ../ACTIVE.json; old trial records are untouched.

1. stores_return_candidate/image.png uses the unchanged stores_return camera (22.7,36.2,30.65), target (15,36.2,30.65), 26mm. Its actual baseline is checkpoints/v030/previews/stores_return.png, whose bytes are checked against the v030 receipt.
2. reverse_source/image.png is a new actual v030 baseline at the unchanged reverse_connection camera (13.8,36.8,30.65), target (5.7,37.5,30.65), 26mm. No actual v030 image existed here previously. The v028 camera definition is inherited, but a v028 image is NOT a comparator.
3. reverse_candidate/image.png uses that same reverse camera and exact source baseline settings.

All use unchanged actual light/world/quality/exposure, 960×694 and 80 samples. Render receipts pin source hashes before/after and require settings equality except output filepath. There is no camera/light rescue or selected alternative hero angle. Render processes never save. Source-operation extraction occurs after the reverse-source render within that same unsaved process.

The parent independently reviewed the original-size image pairs and accepted both as bounded regression (VISUAL_REVIEW.json). A return view can pass regression while showing only part of the table; these images are not a claim that the working task is fully visible or identifiable.

## Static operation and finite connection

PLAN.json freezes one standing body X13.2–13.8 / Y34.95–35.45 / Z29–30.8, facing west. The entire 0.6×0.5 foot domain is checked at Z29 against exact upward source floor triangles, with missing and overlapping positive area rejected.

OPERATION_PLAN_SUPPLEMENT.json adds a conservative continuous straight-translation body from the original east-aisle center (13.8,36.2) to station center (13.5,35.2): X13.2–14.1 / Y34.95–36.45 / Z29–30.8. The full bottom band is included, not just the older Z29.025 clearance convention. Its complete conservative floor domain also receives exact coverage testing. Only genuine Z29 floor contact is allowed, with no source-solid containment. The box remains inside the prior east aisle and starts on the previously protected receiving-to-stores lane.

The declared accessible patch is X12.65–12.95 / Y35–35.4 on the top, area 0.12 scene-unit². A continuous volume X12.65–13.2 / Y35–35.4 / Z29.90001–30.2 must be collision-free against every retained actual source component and all nine actual table components. This supports geometrical access from the west-facing side of the body, with at most 0.55 horizontal scene units. It is not an anatomical reach, hand pose or medical ergonomics test.

The read-only source exporter considers all render-visible meshes after enabling hidden viewport evaluation, rejects unexpected instances, broad-filters the declared neighborhood conservatively, then retains whole actual connected components. Collision uses actual triangle/box SAT plus closed-solid winding; a source object's bounds are not an occupied-solid substitute. Old actual candidate arrays remain bound to c53e through inherited reopened evidence.

Both return-camera near planes are protected against the real added convex parts. The reverse near plane is also tested against current actual source components. A conservative envelope between the two original return-camera centers, expanded by the maximum eye-to-near-corner radius, additionally protects the near plane against the new table for any interpolated orientation. This is not a new whole-source navigation certification. Two new reverse-view finite segments are checked against the table; prior stores light/door rays are inherited, not falsely counted as new.

## Limitations and review ownership

The table does not permanently intrude into the original protected routes. A person using it temporarily occupies the existing east aisle; the approximate 0.6 remaining width is not certified for passing. Do not claim operation and two-way traffic are simultaneously supported. No physical scale, gait, turn, anatomy, ergonomics, structural capacity, tipping, fire safety or full-scene navigation certification.

VERIFIED.json distinguishes new results from inherited r01 evidence. FILES.json inventories this round. Parent visual review accepted both regressions, and the independent completion CPU audit passed (AUDIT_REFERENCES.json). These remain distinct from the producer's numerical checks. Final local usefulness acceptance and any later publication are separate decisions.

## Final supplemental evidence package

The three actual renders, operation checks, parent visual review and independent CPU audit are complete. The unchanged local core archive is ../complete_backup/receiving_table_r01_complete.zip, 95,297,930 bytes, SHA256 a75599d1e679f9627beb4cfc80edbbc4cb4137d8408c6bd0228e3fded322f780. This round is packaged separately under ../r02_evidence_package/, with fresh extraction and entry SHA verification recorded there. It does not revise that frozen core archive. The supplemental ZIP contains r02 evidence and the two independent completion result reports plus operation replay; it is an evidence supplement, not a standalone model/rebuild package. Existing scripts retain repository-relative dependencies, with the exact model/source/QA core supplied separately. No additional Blender replay is claimed for ZIP verification.
