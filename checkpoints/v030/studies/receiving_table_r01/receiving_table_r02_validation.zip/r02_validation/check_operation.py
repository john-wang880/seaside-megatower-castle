"""Supplemental actual-geometry static work/approach proof; no Blender/save."""
import json,sys,hashlib,itertools
from pathlib import Path
from fractions import Fraction as F
import numpy as np
sys.dont_write_bytecode=True
D=Path(__file__).resolve().parent;R=D.parents[2];old=D.parent/'r01_workbench';sys.path.insert(0,str(R/'checkpoints/v030/qa'))
import exact_axis_boundary as e
from body_support import analyze
from continuous_box_cover import solid_winding
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=load(D/'PLAN.json');source=load(D/'source_operation_actual.json');geo=load(old/'reopen_geometry.json');recipe=load(old/'PLAN.json')
assert source['source_sha256']==source['source_sha256_after']==plan['source_sha256']
parts=[]
for p in recipe['parts']:
 a,b=p['vertex_range'];c,d=p['face_range'];parts.append({'object':p['name'],'seed':0,'vertices':geo['vertices'][a:b],'local_faces':[[i-a for i in f]for f in geo['local_faces'][c:d]],'local_triangles':[[i-a for i in t]for t in geo['local_triangles']if all(a<=i<b for i in t)]})
body=plan['operation_body'];approach=[[13.2,34.95,29],[14.1,36.45,30.8]];reach=plan['reach_clearance_volume']
# Conservative box contains straight translation of .6 x .5 body from center(13.8,36.2) to(13.5,35.2).
checks={};fail=[]
for label,box in [('station',body),('approach',approach),('reach',reach)]:
 checks[label]=[]
 for c in source['components']+parts:
  h=analyze(c,box);allowed=False
  if not h['disjoint'] and label in ('station','approach') and c in source['components']:
   allowed=bool(h['actual_boundary_triangles']) and all(all(c['vertices'][i][2]==29 for i in c['local_triangles'][ti]) for ti in h['actual_boundary_triangles']) and abs(solid_winding(c['vertices'],c['local_triangles'],(np.array(box[0])+box[1])/2))<1e-8
  h['allowed_floor_contact']=allowed;checks[label].append(h)
  if not h['disjoint'] and not allowed:fail.append([label,c['object'],c['seed']])
# Exact rational full support for standing footprint and entire conservative swept foot domain.
floor=[]
for c in source['components']:
 for t in c['local_triangles']:
  v=[list(map(F,c['vertices'][i]))for i in t]
  if all(p[2]==29 for p in v)and e.cross(tuple(v[1][i]-v[0][i]for i in range(3)),tuple(v[2][i]-v[0][i]for i in range(3)))[2]>0:floor.append([(p[0],p[1])for p in v])
foot=[]
for label,box in [('station',body),('approach_conservative',approach)]:
 lo,hi=box;poly=[tuple(map(F,p))for p in [[lo[0],lo[1]],[hi[0],lo[1]],[hi[0],hi[1]],[lo[0],hi[1]]]];pieces=[e.clip_convex(poly,r)for r in floor];pieces=[p for p in pieces if e.area(p)>0];area=e.area(poly);covered=sum(map(e.area,pieces),F(0));double=sum((e.area(e.clip_convex(a,b))for a,b in itertools.combinations(pieces,2)),F(0));ok=area==covered and double==0
 foot.append({'domain':label,'area':float(area),'covered_area':float(covered),'pair_overlap_area':float(double),'pass':ok})
 if not ok:fail.append(['support',label])
# Reach is a whole collision-free volume over the declared patch. This is not a biological reach claim.
top=parts[-1];v=np.array(top['vertices']);target=plan['reachable_top_patch'];assert all(v.min(0)[i]<=target[0][i]<=target[1][i]<=v.max(0)[i] for i in [0,1]);assert abs(target[0][2]-v.max(0)[2])<1e-6
near=[]
for name in ['reverse_candidate','stores_return_candidate']:
 rec=load(D/name/'receipt.json')['settings'];cam=rec['camera'];M=np.array(cam['matrix_world']);data=cam['data'];z=data['clip_start'];w=z*data['sensor_width']/(2*data['lens']);h=w*rec['render']['resolution_y']/rec['render']['resolution_x'];points=np.array([(M@np.array([x,y,-z,1]))[:3]for x in [-w,w]for y in [-h,h]]);box=[points.min(0),points.max(0)];rows=[analyze(c,box)for c in parts]
 # reverse source neighborhood includes this near envelope; stores return original source near is inherited, not re-certified here.
 if name=='reverse_candidate':rows += [analyze(c,box)for c in source['components']]
 near.append({'view':name,'envelope':[x.tolist()for x in box],'checks':rows})
 if not all(x['disjoint']for x in rows):fail.append(['near',name])
# Conservative near-plane swept protection between the two inherited return centers.
centers=[];radii=[]
for name in ['stores_return_candidate','reverse_candidate']:
 rec=load(D/name/'receipt.json')['settings'];c=rec['camera'];centers.append(np.array(c['matrix_world'])[:3,3]);z=c['data']['clip_start'];w=z*c['data']['sensor_width']/(2*c['data']['lens']);h=w*rec['render']['resolution_y']/rec['render']['resolution_x'];radii.append(float(np.sqrt(z*z+w*w+h*h)))
radius=max(radii);sweep=[np.min(centers,axis=0)-radius,np.max(centers,axis=0)+radius];rows=[analyze(c,sweep)for c in parts];near.append({'view':'return_center_segment_any_orientation_near_plane','conservative_radius':radius,'centers':[p.tolist()for p in centers],'envelope':[x.tolist()for x in sweep],'checks':rows,'scope':'Only added table versus conservative swept near planes; existing-source route not re-certified.'})
if not all(x['disjoint']for x in rows):fail.append(['near','return_sweep'])
# New return camera's 2-unit forward segment and entry center are protected against the added real convex components.
def segment_box(o,end,lo,hi):
 o=np.array(o);v=np.array(end)-o;near=0.;far=1.
 for k in range(3):
  if abs(v[k])<1e-12:
   if o[k]<lo[k]or o[k]>hi[k]:return False
  else:
   a,b=sorted([(lo[k]-o[k])/v[k],(hi[k]-o[k])/v[k]]);near=max(near,a);far=min(far,b)
 return near<=far
M=np.array(load(D/'reverse_candidate/receipt.json')['settings']['camera']['matrix_world']);o=M[:3,3];rays=[]
for target in [o-M[:3,2]*2,np.array([5.7,37.5,30.65])]:
 hits=[c['object']for c in parts if segment_box(o,target,np.min(c['vertices'],axis=0),np.max(c['vertices'],axis=0))];rays.append({'from':o.tolist(),'to':target.tolist(),'table_hits':hits})
 if hits:fail.append(['ray',hits])
report={'pass':not fail,'failures':fail,'source_component_count':len(source['components']),'source_export_sha256':sha(D/'source_operation_actual.json'),'candidate_geometry_sha256':sha(old/'reopen_geometry.json'),'operation_body':body,'approach_conservative_sweep':approach,'approach_centers':[[13.8,36.2],[13.5,35.2]],'approach_contained_in_original_east_aisle':True,'source_and_table_checks':checks,'whole_foot_support':foot,'reachable_patch':plan['reachable_top_patch'],'reachable_patch_area':.12,'max_declared_horizontal_reach':.55,'reach_clear_volume':reach,'near_planes':near,'new_reverse_finite_rays':rays,'inherited_routes':'All nine preserved table-body routes already proved in r01; same c53e and exact exported geometry, not rerun. Operator temporarily occupies east aisle; remainder about .6 is not passing certification.','limits':'Geometric static fit and conservative straight translation only; not articulated human anatomy, medical ergonomics, load capacity, simultaneous passage, full navigability or safety certification.'}
(D/'OPERATION_QA.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS' if not fail else 'FAIL',fail)
