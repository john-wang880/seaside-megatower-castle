"""Hash-bound supplemental validation receipt; no old-file writes."""
from pathlib import Path
import json,hashlib
D=Path(__file__).resolve().parent;R=D.parents[2];load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();plan=load(D/'PLAN.json');inputs=load(D/'INPUTS.json')
assert sha(Path(inputs['source']))==plan['source_sha256'] and sha(Path(inputs['candidate']))==plan['candidate_sha256']
prior=load(D/'PRIOR_FILES_BEFORE.json');assert all(sha(R/p)==h for p,h in prior.items())
receipts={n:load(D/n/'receipt.json')for n in ['stores_return_candidate','reverse_source','reverse_candidate']}
base=load(R/'checkpoints/v030/reports/visual/stores_return_receipt.json');assert sha(R/'checkpoints/v030/previews/stores_return.png')==base['image_sha256']
def settings(r):
 s=json.loads(json.dumps(r['settings']));s['render'].pop('filepath');return s
assert settings(receipts['stores_return_candidate'])==settings(base)
assert settings(receipts['reverse_candidate'])==settings(receipts['reverse_source'])
for n,r in receipts.items():
 assert sha(D/n/'image.png')==r['image_sha256'] and r['source_sha256_before']==r['source_sha256_after'] and not r['source_saved']
 assert r['source_sha256_before']==(plan['source_sha256']if n=='reverse_source'else plan['candidate_sha256'])
qa=load(D/'OPERATION_QA.json');assert qa['pass']
result={'status':'BOUNDED_SUPPLEMENTAL_VALIDATION_ACCEPTED','visual_review':load(D/'VISUAL_REVIEW.json'),'technical_pass':True,'source_sha256':plan['source_sha256'],'candidate_sha256':plan['candidate_sha256'],'model_changes':False,'source_or_candidate_saved':False,'prior_trial_files_unchanged':len(prior),'this_round':{'candidate_renders':2,'v030_baseline_renders':1,'native_processes':3,'operation_geometry_pass':True,'settings_equal_except_filepath':True,'return_near_plane_sweep':True},'inherited_evidence':{'doorway_visual_acceptance':'r01 independent local review only','table_route_preservation':'nine protected bodies proved in r01 on same candidate','source_original_13_categories':'r01 saved/reopened preservation on same pinned candidate','global_model':'v030 unchanged'},'images':{n:{'sha256':r['image_sha256'],'seconds':r['render_wall_seconds'],'peak_rss_kib':r['peak_rss_linux_kib']}for n,r in receipts.items()},'operations_limit':'Operator temporarily occupies original east aisle. About .6 remainder is not a passing route certification. Static rectangular space and collision-free reach volume do not establish anatomy, ergonomics, safety, capacity or simultaneous passage.','old_v028_image_used_as_baseline':False,'git_writes':False,'backup_upload':False,'publication':False,'backup_status':'REMOTE_UPLOAD_PENDING_LOCAL_COMPLETE_BACKUP_AUDITED_SEPARATELY','independent_audit':load(D/'AUDIT_REFERENCES.json'),'limits':'Prior doorway image establishes local visual usefulness. These return views are regression/connection evidence; no alternate hero angle or relighting. Independent parent art verdict and sibling technical audit are separate.'}
(D/'VERIFIED.json').write_text(json.dumps(result,indent=2)+'\n')
active=load(D/'ACTIVE.json');active.update(status=result['status'],heavy_lock_acquired=False,operation_qa='PASS');(D/'ACTIVE.json').write_text(json.dumps(active,indent=2)+'\n');(D.parent/'ACTIVE.json').write_text(json.dumps(active,indent=2)+'\n')
files={str(p.relative_to(D)):sha(p)for p in sorted(D.rglob('*'))if p.is_file()and p.name!='FILES.json'and '__pycache__'not in p.parts};(D/'FILES.json').write_text(json.dumps({'scope':'r02 files only; prior immutable files in PRIOR_FILES_BEFORE.json; mutable ACTIVE and review additions require refreshed inventory','files':files},indent=2)+'\n');print('PASS',len(files),'files;',len(prior),'prior files unchanged')
