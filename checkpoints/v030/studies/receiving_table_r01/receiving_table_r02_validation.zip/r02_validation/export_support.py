"""Bounded receiving-table source probe/build/reopen. Never overwrites source."""
import sys,json,hashlib,copy
from pathlib import Path
sys.dont_write_bytecode=True
import bpy
from mathutils import Vector
D=Path(__file__).resolve().parent;R=D.parents[2];sys.path.insert(0,str(R/'checkpoints/v030/qa'))
import validate_saved as v
S=R/'checkpoints/v030/restored/castle_v030.blend';PIN='9f020b7ec6eda309d674653598b169f65ba5dc1d1f194ffa31323f6393feda35';NAME='TRIAL R01 | shallow receiving check table';COL='TRIAL R01 | receiving table';MAT='V030 | subdued stores timber'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(n,d):p=D/n;assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n')
def normalize(s):return v.normalized(s)[0]
def extract(o,deps):
 eo=o.evaluated_get(deps);m=eo.to_mesh(preserve_all_data_layers=True,depsgraph=deps);m.calc_loop_triangles();vv=[list(eo.matrix_world@p.co)for p in m.vertices];faces=[list(p.vertices)for p in m.polygons];tri=[list(t.vertices)for t in m.loop_triangles];eo.to_mesh_clear();return {'object':o.name,'seed':0,'vertices':vv,'local_faces':faces,'local_triangles':tri}
def source_export():
 # All objects, even hidden in viewport. Collection/eye overrides restored before snap.
 flags=[(o,o.hide_viewport,o.hide_get())for o in bpy.data.objects];cols=[(c,c.hide_viewport)for c in bpy.data.collections];layers=[]
 def enable(l):
  layers.append((l,l.exclude,l.hide_viewport));l.exclude=False;l.hide_viewport=False
  for c in l.children:enable(c)
 for vl in bpy.context.scene.view_layers:enable(vl.layer_collection)
 for c,_ in cols:c.hide_viewport=False
 for o,_,_ in flags:o.hide_viewport=False;o.hide_set(False)
 bpy.context.view_layer.update();deps=bpy.context.evaluated_depsgraph_get();assert not any(i.is_instance for i in deps.object_instances),'Unexpected instance needs explicit inventory'
 out=[]
 for o in bpy.data.objects:
  if o.type!='MESH' or o.hide_render:continue
  eo=o.evaluated_get(deps);pts=[eo.matrix_world@Vector(x)for x in eo.bound_box]
  if any(max(p[k]for p in pts)<[12,34.8,28.9][k] or min(p[k]for p in pts)>[14.5,37,31.2][k]for k in range(3)):continue
  c=extract(o,deps)
  # Split actual connected components, not full host-box tests.
  adj=[[]for _ in c['vertices']]
  for f in c['local_faces']:
   for a,b in zip(f,f[1:]+f[:1]):adj[a].append(b);adj[b].append(a)
  seen=set()
  for seed in range(len(adj)):
   if seed in seen:continue
   group={seed};todo=[seed];seen.add(seed)
   while todo:
    for b in adj[todo.pop()]:
     if b not in seen:seen.add(b);group.add(b);todo.append(b)
   ids=sorted(group);verts=[c['vertices'][i]for i in ids]
   if any(max(p[k]for p in verts)<[12,34.8,28.9][k]or min(p[k]for p in verts)>[14.5,37,31.2][k]for k in range(3)):continue
   idx={i:j for j,i in enumerate(ids)};out.append({'object':o.name,'seed':seed,'vertices':verts,'local_faces':[[idx[i]for i in f]for f in c['local_faces']if f[0]in group],'local_triangles':[[idx[i]for i in t]for t in c['local_triangles']if t[0]in group]})
 for o,h,e in flags:o.hide_viewport=h;o.hide_set(e)
 for c,h in cols:c.hide_viewport=h
 for l,e,h in layers:l.exclude=e;l.hide_viewport=h
 bpy.context.view_layer.update();return out
