import bpy,sys,json,pathlib,hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'s99_candidate/validation_design/history'))
from geometry_core import SceneGeometry
from stair_tools import validate_level_route
src=P.parent/'s100_candidate/candidate.blend'
h=hashlib.sha256(src.read_bytes()).hexdigest()
assert h=='e83414f23e0a5442c3b275762918e7a012af3be598749f1bd7d59ed38254ca97'
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
base=json.loads((P.parent/'s99_candidate/validation_design/history/baseline_s94_build.json').read_text())
G=SceneGeometry(lo=(19.0,37.0,28.5),hi=(32.2,54,32.25))
def bounds(g): return [g['vertices'].min(0).tolist(),g['vertices'].max(0).tolist()]
obj={n:bounds(g) for n,g in G.objects.items() if n.startswith(('S89 |','S94 |','S95 |'))}
routes=[v for r in base['routes'] for v in validate_level_route(G,r)]
# Signed multi-hit on actual evaluated meshes for proposed range exhaust route.
dg=bpy.context.evaluated_depsgraph_get(); trees=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or o.hide_render or o.hide_viewport:continue
 e=o.evaluated_get(dg);M=e.matrix_world
 v=[M@Vector(q) for q in e.bound_box]
 a,b=tuple(min(q[k]for q in v)for k in range(3)),tuple(max(q[k]for q in v)for k in range(3))
 if b[0]<22.7 or a[0]>25.4 or b[1]<40.6 or a[1]>46.0 or b[2]<30.6:continue
 try:trees.append((o.name,a,b,BVHTree.FromObject(o,dg),M,M.inverted()))
 except ValueError:continue
def vertical(x,y):
 out=[]
 for n,a,b,t,M,I in trees:
  if not (a[0]<x<b[0]and a[1]<y<b[1]):continue
  z=30.6
  for i in range(40):
   q,N,_,_=t.ray_cast(I@Vector((x,y,z)),I.to_3x3()@Vector((0,0,1)))
   if q is None:break
   q=M@q;z=q.z
   if z>52:break
   out.append([round(z,5),n,round((I.to_3x3().transposed()@N).normalized().z,3)])
   z+=.001
 return sorted(out)
pi=[(x,y)for x in [23.4,24.07,24.7]for y in [42.55,42.85,43.15,43.45,44.8]]
# Exact finite retirement candidates only original S94 fixture objects, not shell, doors/portals or lamps.
retire=[n for n in base['new_objects'] if n.startswith(tuple('S94 | '+a for a in ['range ','cold cooking','cabinet ','prep counter','draining counter','basin ','tap ','wash','drain'] )) and n in obj and bpy.data.objects[n].type=='MESH']
out=dict(model_sha256=h,object_bounds=obj,baseline_routes=routes,proposed_hide_core_exact=retire,vertical_grid=[dict(x=x,y=y,hits=vertical(x,y))for x,y in pi])
(P/'KITCHEN_AUDIT.json').write_text(json.dumps(out,indent=2,default=lambda x:x.item()))
print('routes',len(routes),[(q['id'],q['passed']) for q in routes], 'hide fixtures',len(retire))
