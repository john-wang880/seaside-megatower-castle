from pathlib import Path
import bpy, math, hashlib, json
from mathutils import Vector
from math import sin,cos,pi
P=Path(__file__).resolve().parent
S=json.loads((P/'S101_BUILD_SCOPE.json').read_text())
src=P.parent/'s100_candidate/candidate.blend'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(src)==S['source_sha256']
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
sc=bpy.context.scene
C=bpy.data.collections.new('S101 | Ash-and-tide household kitchen');sc.collection.children.link(C)
new=[];hidden=[]
for n in S['approved_hide_exact']:
 o=bpy.data.objects[n]; assert not o.hide_render
 o.hide_render=True;o.hide_viewport=True;hidden.append(n)
def material(name,c,rough=.7,met=0,emit=0,tex=None):
 m=bpy.data.materials.new('S101 | '+name);m.diffuse_color=(*c,1);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=met
 if emit:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emit
 if tex:
  k=n.new('ShaderNodeTexCoord');a=n.new('ShaderNodeTexNoise');a.inputs['Scale'].default_value=2.7;a.inputs['Detail'].default_value=4;l.new(k.outputs['Object'],a.inputs['Vector'])
  r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.21;r.color_ramp.elements[0].color=(*(v*.66 for v in c),1);r.color_ramp.elements[1].position=.83;r.color_ramp.elements[1].color=(*(v*1.34 for v in c),1);l.new(a.outputs['Fac'],r.inputs[0]);l.new(r.outputs['Color'],p.inputs['Base Color'])
  f=n.new('ShaderNodeTexNoise');f.inputs['Scale'].default_value=27;f.inputs['Detail'].default_value=3;l.new(k.outputs['Object'],f.inputs['Vector']);b=n.new('ShaderNodeBump');b.inputs['Distance'].default_value=.035;b.inputs['Strength'].default_value=.29;l.new(f.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],p.inputs['Normal'])
 return m
def mesh(n,v,f,m,mi=None):
 d=bpy.data.meshes.new('S101 | '+n);d.from_pydata(v,[],f);d.update()
 for a in (m if isinstance(m,list) else [m]):d.materials.append(a)
 if mi:
  for a,i in zip(d.polygons,mi):a.material_index=i
 o=bpy.data.objects.new(d.name,d);C.objects.link(o);new.append(o.name);return o
faces=[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
def box(n,lo,hi,m):
 x,y,z=lo;a,b,c=hi
 return mesh(n,[(x,y,z),(a,y,z),(a,b,z),(x,b,z),(x,y,c),(a,y,c),(a,b,c),(x,b,c)],faces,m)
def ring(n,x,y,base,levels,m,N=12):
 v=[(x+rx*cos(2*pi*i/N+pi/12),y+ry*sin(2*pi*i/N+pi/12),base+z) for z,rx,ry in levels for i in range(N)]
 f=[tuple(range(N-1,-1,-1))]
 for j in range(len(levels)-1):
  a=j*N;b=a+N
  for i in range(N):q=(i+1)%N;f.append((a+i,a+q,b+q,b+i))
 a=(len(levels)-1)*N;f.append(tuple(range(a,a+N)));return mesh(n,v,f,m)
import random
R=random.Random(101)
warm=[material('honey dressed stone '+str(i),tuple(m*v for v in (.42,.31,.194)),.7,tex=True) for i,m in enumerate((.86,.98,1.02,1.13))]
dark=material('deep riven stone mortar',(.15,.12,.082),.85,tex=True)
jade=material('glazed old sea-green stone',(.067,.24,.205),.38,tex=True)
pale=material('worn pale work stone',(.47,.405,.309),.58,tex=True)
oak=material('oiled dark chestnut',(.16,.086,.046),.59,tex=True)
iron=material('blackened forged iron',(.09,.077,.06),.49,.65)
F=29.008
# One coordinated masonry working elevation. Face stones project 9 mm past the backing.
for i,(a,b) in enumerate(((22.75,25.47),(25.52,28.82),(28.87,31.18))):
 box('bonded rear wall core '+str(i),(a,42.073,F),(b,42.205,31.26),dark)
 for row in range(9):
  z=29.028+row*.247
  for k in range(11):
   x=max(a+.006,a+(k-(.50 if row%2 else 0))*.411)
   X=min(b-.006,a+(k+1-(.50 if row%2 else 0))*.411-.007)
   if X-x>.05:box('staggered dressed rear wall field',(x,42.192,z),(X,42.225,z+.237),R.choice(warm))
 # Cross-zone continuous but separated crown where bays meet.
 box('jade cornice long bed '+str(i),(a,42.108,31.27),(b,42.307,31.34),jade)
 box('stone crown capping '+str(i),(a+.009,42.098,31.34),(b-.009,42.319,31.45),warm[2])
# Deep cold hearth: full support slab, load-bearing cheeks, truly open cavity, wedge voussoir mouth.
box('deep hearth foot course',(22.80,42.229,F),(25.44,43.298,29.170),warm[1])
box('closed hearth firebrick floor',(23.215,42.235,29.17),(25.02,43.283,29.27),iron)
box('hearth left abutment',(22.84,42.228,29.17),(23.215,43.291,30.41),warm[0])
box('hearth right abutment',(25.02,42.228,29.17),(25.395,43.291,30.41),warm[0])
box('hearth inner back solid',(23.215,42.23,29.27),(25.02,42.37,30.92),iron)
def arch(n,c,z,a,b,ya,yb,t0,t1,mat):
 N=max(3,int((t1-t0)*30))
 ts=[t0+(t1-t0)*k/N for k in range(N+1)]
 v=[(c+r*math.cos(t),y,z+(r-(a-.59))*.76*math.sin(t))for r in (a,b)for y in (ya,yb)for t in ts]
 # Consistent solid winding: use reverse on re-evaluation if necessary; material exterior same.
 q=len(ts);f=[]
 for k in range(q-1):
  f.extend([(k,k+1,q+k+1,q+k),(2*q+k,3*q+k,3*q+k+1,2*q+k+1),(k,2*q+k,2*q+k+1,k+1),(q+k,q+k+1,3*q+k+1,3*q+k)])
 f +=[(0,q,3*q,2*q),(q-1,3*q-1,4*q-1,2*q-1)]
 return mesh(n,v,f,mat)
C0=24.1175;r=.9025
arch('hearth continuous arch bed',C0,30.41,r,.998,42.228,43.237,0,pi,dark)
for k in range(15):arch('hearth radial dressed wedge',C0,30.41,.9075,1.108,43.224,43.299,pi*k/15+.005,pi*(k+1)/15-.005,warm[k%4])
box('cold hearth gathering shelf over mouth',(23.01,42.229,30.977),(25.23,43.147,31.212),warm[3])
# Built-in preparation table stone over bearing plinths, with three stocked bays rather than appliance fronts.
for x,X in ((25.52,25.78),(26.54,26.68),(27.61,27.76),(28.60,28.82)):
 box('prep continuous ashlar pier',(x,42.23,F),(X,43.22,29.79),warm[1])
box('prep full stone worktop',(25.52,42.23,29.79),(28.82,43.30,29.929),pale)
box('prep full oak staging shelf',(25.78,42.232,29.32),(28.60,43.17,29.38),oak)
for r,z in enumerate([30.28,30.71]):
 box('prep wall built-in storage shelf',(25.61,42.221,z),(28.733,42.675,z+.072),oak)
 for j,x in enumerate((25.74,27.17,28.66)):
  box('shelf stone wall corbel',(x,42.221,z-.155),(x+.063,42.465,z),warm[1])
 for j,x in enumerate((25.86,26.46,27.15,27.73,28.21)):
  if (r+j)%3!=2:
   ring('grounded wide store jar',x,42.462,z+.072,[(0,.077,.067),(.025,.088,.080),(.157,.105,.099),(.207,.074,.065),(.233,.070,.063)],jade if j%2 else warm[2],12)
# Washing bench with true open cavity. Add end wings and front/back rims as separate solids.
for x,X in ((28.89,29.12),(30.97,31.16)):
 box('wash integral stone bearing pier',(x,42.23,F),(X,43.28,29.78),warm[1])
box('wash stone continuous support bottom',(28.89,42.23,29.78),(31.69,43.30,29.805),pale)
for a,b,y,Y in [(28.89,29.24,42.23,43.30),(30.85,31.69,42.23,43.30),(29.24,30.85,42.23,42.39),(29.24,30.85,43.04,43.30)]:
 box('wash solid stone rim',(a,y,29.805),(b,Y,30.035),jade)
box('wash bottom liner',(29.242,42.392,29.805),(30.848,43.038,29.818),jade)
# Floor-bearing eastern extension is clear of the old pier (starts north of y=42.56).
box('east wash worktop return bearing pier',(31.505,42.58,F),(31.69,43.28,29.78),warm[1])
box('wash inset storage bench',(29.12,42.232,29.30),(30.97,43.18,29.357),oak)
for name,(loc,target,lens) in S['cameras'].items():
 name='S101 | '+name+' camera';d=bpy.data.cameras.new(name);d.lens=lens;d.clip_start=.05;d.clip_end=1000
 o=bpy.data.objects.new(name,d);C.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();new.append(o.name)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(P/'raw.blend'),compress=False)
(P/'BUILD.json').write_text(json.dumps({'source_sha256':H(src),'scope_sha256':H(P/'S101_BUILD_SCOPE.json'),'raw_sha256':H(P/'raw.blend'),'new_objects':new,'hidden_existing':hidden},indent=2))
