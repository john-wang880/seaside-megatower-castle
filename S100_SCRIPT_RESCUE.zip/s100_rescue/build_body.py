from math import sqrt
from mathutils import Vector
import random
rng=random.Random(100)
ivory=material('veined pearl stone',(.43,.32,.235),tex=True)
warm=material('honey limestone',(.33,.237,.168),tex=True)
edge=material('deep sea-green stone edging',(.08,.201,.168),.54,tex=True)
poolstone=material('sea jade basin stone',(.098,.284,.242),.40,tex=True)
grout=material('warm grotto mortar',(.131,.109,.082),tex=True)
brass=material('antique brass inlay',(.39,.22,.06),.32,.73)
wood=material('smoked oak storage',(.13,.068,.029),tex=True)
linen=[material('folded linen '+str(i),c) for i,c in enumerate(((.47,.33,.19),(.53,.44,.27),(.18,.27,.22)))]
glow=material('small amber practical',(.95,.36,.09),.27,emit=3.5)
water=material('static translucent jade water',(.33,.72,.62),.07)
p=water.node_tree.nodes.get('Principled BSDF')
p.inputs['Transmission Weight'].default_value=.92
p.inputs['IOR'].default_value=1.333
p.inputs['Metallic'].default_value=0
p.inputs['Coat Weight'].default_value=.18
nodes=water.node_tree.nodes;links=water.node_tree.links
tc=nodes.new('ShaderNodeTexCoord');noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=19;noise.inputs['Detail'].default_value=2
links.new(tc.outputs['Object'],noise.inputs['Vector']);bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.25;bump.inputs['Distance'].default_value=.002
links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],p.inputs['Normal'])
pal=[material('grotto dressed stone '+str(i),tuple(f*v for v in (.45,.355,.257)),tex=True) for i,f in enumerate((.83,.96,1.00,1.06,1.14))]
F=S['dry_floor'];x0,x1=30.065,31.512
def profiled_extrusion(name,a,b,poly,mat):
 n=len(poly);v=[(x,y,z) for x in (a,b) for y,z in poly]
 f=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 return mesh(name,v,f,mat)
stairs=S['tread_z_y'];top=[(stairs[0][0],stairs[0][2])]
for y,Y,z in stairs:
 if top[-1]!=(y,z):top.append((y,z))
 top.append((Y,z))
poly=[(59.80,F),(62.72,F)]+list(reversed(top))
profiled_extrusion('continuous stepped basin foundation',x0,x1,poly,poolstone)
box('pool west continuous retaining wall',(29.80,59.80,F),(x0,62.92,29.43),warm)
box('pool east continuous retaining wall',(x1,59.80,F),(31.695,62.92,29.43),warm)
box('pool rear retaining wall',(x0,62.72,F),(x1,62.92,29.43),warm)
for a,b,n in [(29.805,x0-.010,'west'),(x1+.010,31.690,'east')]:
 box(n+' jade rim coping',(a,59.835,29.43),(b,62.90,29.485),edge)
box('north jade rim coping',(x0-.010,62.725,29.43),(x1+.010,62.90,29.485),edge)
wx0,wx1=S['water_x'];wy0,wy1=S['water_y'];z=S['water_z']
mesh('water surface static only',[(wx0,wy0,z),(wx1,wy0,z),(wx1,wy1,z),(wx0,wy1,z)],[(0,1,2,3)],water)
for y,Y,z in stairs[:-1]:
 box('non-slip darker stair stripe '+str(y),(30.105,y+.038,z-.008),(31.465,y+.060,z-.0004),edge)
box('east deep wall structural backing',(31.695,59.92,F),(31.745,62.24,31.405),grout)
for zi in range(10):
 z0=F+.018+zi*.236
 for yi in range(6):
  y0=59.925+yi*.384; y1=min(y0+.376,62.235)
  if y1>y0:box('east wall staggered face course',(31.672,y0,z0),(31.698,y1,z0+.227),rng.choice(pal))
for y,n in [(60.05,'entrance'),(61.12,'middle'),(62.105,'far')]:
 ring('west '+n+' carved stone spring pier',29.935,y,F,[(0,.115,.123),(.17,.115,.123),(.23,.083,.102),(2.16,.083,.093),(2.23,.113,.126),(2.37,.114,.125)],warm,8)
 ring('east '+n+' carved stone spring pier',31.629,y,F,[(0,.105,.123),(.17,.105,.123),(.23,.071,.102),(2.16,.071,.093),(2.23,.112,.125),(2.37,.112,.123)],warm,8)
 for x in (29.935,31.629):
  ring('patinated spring fillet',x,y,F,[(2.223,.104,.118),(2.243,.104,.118)],brass,8)
L,R=29.84,31.723
def vault(x):
 u=(2*x-L-R)/(R-L)
 return 31.34+.59*sqrt(max(0,1-u*u))
def roof(name,xs,ya,yb,lift,full,mat):
 n=len(xs);v=[(x,y,vault(x)+d) for d in (lift,lift+full) for y in (ya,yb) for x in xs];f=[]
 for i in range(n-1):
  f.extend([(i,n+i,n+i+1,i+1),(2*n+i,2*n+i+1,3*n+i+1,3*n+i),(i,i+1,2*n+i+1,2*n+i),(n+i,3*n+i,3*n+i+1,n+i+1)])
 f += [(0,2*n,3*n,n),(n-1,2*n-1,4*n-1,3*n-1)]
 return mesh(name,v,f,mat)
xs=[L+(R-L)*i/64 for i in range(65)]
roof('continuous barrel vault stone backing',xs,59.92,62.24,.016,.086,grout)
for j in range(7):
 y=59.922+j*.33;yb=min(y+.319,62.235)
 for i in range(16):
  a=i*4;roof('dressed vaulted stone block',[xs[k] for k in range(a,a+5)],y,yb,-.015,.034,rng.choice(pal))
for y,n in [(60.05,'entrance'),(61.12,'middle'),(62.105,'far')]:
 roof(n+' integral carved arch band',xs,y-.037,y+.037,-.050,.070,ivory)
 roof(n+' dark narrow tracing',xs,y-.006,y+.006,-.056,.008,brass)
box('sea jade east horizontal dado',(31.594,60.21,30.07),(31.674,62,30.164),edge)
for i in range(9):
 y=60.32+.19*i;box('emerald inset wall field',(31.591,y,30.20),(31.672,y+.142,30.38),poolstone)
for y in (60.49,61.71):
 box('grotto lamp stone mounting',(31.584,y-.12,30.62),(31.676,y+.12,30.80),edge)
 ring('stone lamp bowl',31.60,y,30.73,[(0,.067,.080),(.061,.099,.109),(.095,.10,.11)],brass,10)
 ring('small lamp warm glass',31.60,y,30.793,[(0,.039,.043),(.085,.038,.038),(.12,.012,.012)],glow,10)
for z in range(7):
 for x in range(5):
  xa=29.81+x*.38;box('north bath ashlar closure',(xa,62.80,29.493+z*.195),(min(xa+.37,31.735),62.923,29.68+z*.195),rng.choice(pal))
da,db=57.58,58.55
for ya,yb in [(da,da+.14),(db-.14,db)]:
 box('washstand lower ashlar cheek',(30.42,ya,F),(31.72,yb,29.85),warm)
for zi in [29.26,29.49]:
 box('deep washstand linen shelf',(30.48,da+.13,zi),(31.69,db-.13,zi+.048),wood)
 for i in range(3):
  y=da+.16+i*.20;box('folded linen field',(30.55,y,zi+.048),(30.91,y+.15,zi+.105),linen[i])
box('closed-bottom washstone',(30.38,da,29.81),(31.741,db,29.922),ivory)
for ya,yb in [(da,da+.171),(db-.171,db)]:
 box('washstone short raised rim',(30.38,ya,29.922),(31.741,yb,30.02),ivory)
box('washstone thick rear rim',(31.54,da+.171,29.922),(31.741,db-.171,30.02),ivory)
box('washstone thick front rim',(30.38,da+.171,29.922),(30.58,db-.171,30.02),ivory)
box('washstone low wall shield',(31.666,da,30.02),(31.738,db,30.51),edge)
def light(n,pt,target,power,size,col):
 d=bpy.data.lights.new('S100 | '+n,'AREA');d.energy=power;d.color=col;d.size=size
 o=bpy.data.objects.new(d.name,d);C.objects.link(o);o.location=pt;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();new.append(o.name)
light('warm grazing vault source',(31.17,60.52,30.55),(30.78,61.21,31.55),24,.48,(1,.70,.40))
light('warm graze reflected from water',(31.31,61.58,30.39),(30.45,61.70,29.28),33,.44,(1,.81,.57))
light('quiet cool wall bounce',(30.14,61.48,30.66),(31.60,61.44,30.95),13,.63,(.54,.84,1))
for name,k in S['cameras'].items():
 d=bpy.data.cameras.new(name);d.lens=k['lens'];d.clip_start=.05;d.clip_end=1000
 o=bpy.data.objects.new(name,d);C.objects.link(o);o.location=k['location'];o.rotation_euler=(Vector(k['target'])-o.location).to_track_quat('-Z','Y').to_euler();new.append(o.name)
q=S['privacy'];a,b=q['west_screen']
box('west bath opaque screen bonded stone core',tuple(a),tuple(b),grout)
for row in range(7):
 z=29.489+row*.225
 for j in range(11):
  y=max(59.808,59.805+(j-(.5 if row%2 else 0))*.306)
  Y=min(62.788,59.805+(j+1-(.5 if row%2 else 0))*.306-.010)
  if Y-y>.04:box('upper screen alternating ashlar facing',(29.805,y,z),(29.837,Y,z+.213),rng.choice(pal))
box('green coping on western privacy wall',(29.801,59.805,31.067),(30.055,62.79,31.125),edge)
box('short opaque entrance stone return',(30.054,59.805,29.485),(30.160,59.913,31.125),warm)
def gate_pivot(name,pt,angle):
 o=bpy.data.objects.new(name,None);C.objects.link(o);o.empty_display_type='PLAIN_AXES';o.empty_display_size=.07;o.location=pt;o.rotation_euler.z=math.radians(angle)
 o['open_angle_degrees']=angle;o['closed_angle_degrees']=0.;o['pose_instructions']='Default open; close both pivots by setting local Z rotation to zero. No animation or gameplay.'
 new.append(o.name);return o
for k,sg,angle,point in [('west',1,-90,q['hinge_leaf_west']),('east',-1,90,q['hinge_leaf_east'])]:
 pivot=gate_pivot(q[k+'_pivot'],point,angle);m=.656;z=q['top']-point[2]
 def item(suffix,xlo,xhi,ylo,yhi,hlo,hhi,mat):
  xlo,xhi=sorted((sg*xlo,sg*xhi));o=box(k+' privacy gate '+suffix,(xlo,ylo,hlo),(xhi,yhi,hhi),mat);o.parent=pivot;return o
 item('solid opaque oak leaf',0,m,-.025,.025,0,z,wood)
 for h in (.18,.92,z-.26):item('forged internal strap',.016,m-.026,-.035,-.025,h,h+.045,brass)
 for j in range(5):
  x=.035+j*.117;item('deep raised narrow board rib',x,x+.020,-.033,-.025,.06,z-.055,warm)
 item('recessed pull surround',.51,.58,-.042,-.033,.96,1.10,brass)
 if k=='west':item('opaque meeting astragal',m-.018,m+.012,-.041,-.026,0,z,wood)
 for h in (.22,1.04,1.85):
  ring(k+' stationary hinge pin',point[0],point[1],point[2]+h,[(0,.029,.029),(.10,.029,.029)],brass,12)
 ja,jb=(30.071,30.122) if k=='west' else (31.444,31.495)
 box(k+' privacy gate fixed stone jamb',(ja,point[1]-.026,29.428),(jb,point[1]+.061,31.282),edge)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(P/'candidate.blend'))
(P/'BUILD.json').write_text(json.dumps({'source_sha256':H(src),'candidate_sha256':H(P/'candidate.blend'),'scope_sha256':H(P/'S100_BUILD_SCOPE.json'),'new_objects':new,'hidden_existing':hidden,'arch':{'span_x':[L,R],'support_y':[60.05,61.12,62.105],'envelope_max':32.032},'treads':stairs,'water_depth':S['maximum_static_depth_m']},indent=2))
