from pathlib import Path
import bpy,json,hashlib,sys
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'s95_candidate'))
from geometry_core import SceneGeometry
from stair_tools import validate_level_route
D=json.loads((P/'S100_BUILD_SCOPE.json').read_text());B=json.loads((P/'BUILD.json').read_text())
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(P/'candidate.blend')==B['candidate_sha256']
bpy.ops.wm.open_mainfile(filepath=str(P/'candidate.blend'),use_scripts=False)
for n in D['approved_hide_exact']:
 o=bpy.data.objects[n];assert o.hide_render and o.hide_viewport
o=bpy.data.objects['S100 | water surface static only'];o.hide_render=True;o.hide_viewport=True
bpy.context.view_layer.update()
F=D['dry_floor'];G=SceneGeometry(lo=(27.2,55,28.72),hi=(31.82,69.57,32.3));groups={}
def route(n,pts):groups[n]=validate_level_route(G,{'id':n,'points':[(x,y,F)for x,y in pts],'required_clear_width':1.1,'headroom':2.25})
route('legacy corridor and privy vestibule',[(29.2,55.1),(29.2,61),(29,61),(29,65.5)])
route('old north dogleg to private seat',[(29,65.5),(30.45,65.5),(30.45,67.55),(28.30,67.55)])
route('pool dry approach',[(29.2,59.23),(30.75,59.23)])
groups['pool dry turn and apron']=[G.rectangle('dry apron',[30.2,58.68],[31.3,59.80],F,2.25,.006,.006)]
route('washstone standing square',[(29.2,58.15),(29.75,58.15)])
dry_pass=all(q['passed'] for r in groups.values() for q in r)
verts=[];faces=[];names=[]
for n,g in G.objects.items():
 N=len(verts);verts+=list(map(Vector,g['vertices']));fs=[tuple(N+int(j)for j in t)for t in g['indices']]
 faces+=fs;names += [n]*len(fs)
tree=BVHTree.FromPolygons(verts,faces,all_triangles=True);rows=[]
for y,Y,z in D['tread_z_y']:
 for i in range(13):
  x=30.20+1.10*i/12
  for w in (0.03,.25,.5,.75,.97):
   pos=(x,y+(Y-y)*w,z)
   q,_,ind,_=tree.ray_cast(Vector((pos[0],pos[1],z+.002)),Vector((0,0,-1)),.006)
   a,_,j,dist=tree.ray_cast(Vector((pos[0],pos[1],z+.003)),Vector((0,0,1)),4)
   rows.append({'pos':pos,'floor':names[ind]if q is not None else None,'headroom':dist+.003 if a is not None else None,'overhead':names[j]if a is not None else None,'passed':q is not None and names[ind]=='S100 | continuous stepped basin foundation' and (a is None or dist+.003>=2.25)})
stairs_pass=all(r['passed']for r in rows)
report={'candidate_sha256':B['candidate_sha256'],'routes':groups,'wet_footprints':rows,'dry_pass':dry_pass,'stairs_pass':stairs_pass,'pass':dry_pass and stairs_pass,'minimum_sampled_headroom':min(r['headroom']for r in rows if r['headroom']is not None)}
(P/'LOCAL_CHECK.json').write_text(json.dumps(report,indent=2,default=lambda x:x.item()))
assert report['pass'],[(k,[q['id'] for q in v if not q['passed']])for k,v in groups.items()]+[r for r in rows if not r['passed']][:4]
