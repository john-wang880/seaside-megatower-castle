import bpy,pathlib,sys,json,math,hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=pathlib.Path(__file__).resolve().parent
S=json.loads((P/'S100_BUILD_SCOPE.json').read_text())
sys.path.insert(0,str(P.parent/'s95_candidate'))
from geometry_core import SceneGeometry
p=P/'candidate.blend';bpy.ops.wm.open_mainfile(filepath=str(p),use_scripts=False)
q=S['privacy'];pivots=[bpy.data.objects[q[k]] for k in ('west_pivot','east_pivot')]
def opaque(n):
 o=bpy.data.objects[n]
 return all(m is None or (m.diffuse_color[3]>.999 and (not m.use_nodes or all(k.bl_idname not in ('ShaderNodeBsdfTransparent','ShaderNodeBsdfGlass','ShaderNodeBsdfRefraction') and (k.bl_idname!='ShaderNodeBsdfPrincipled' or all(k.inputs[i].default_value>=.999 if i=='Alpha' else k.inputs[i].default_value<=.001 for i in ('Alpha','Transmission Weight') if i in k.inputs)) for k in m.node_tree.nodes))) for m in o.data.materials)
def ocular():
 G=SceneGeometry(lo=(27,53,28.7),hi=(32,70,33))
 vs=[];ts=[];names=[]
 for n,g in G.objects.items():
  if not opaque(n):continue
  k=len(vs);vs.extend(g['vertices']);ts.extend(g['indices']+k);names.extend([n]*len(g['indices']))
 b=BVHTree.FromPolygons(vs,ts,all_triangles=True)
 O={'entry_approach':[(29.2,y,30.63) for y in (55.1,55.25)],'washroom_shared_aisle':[(x,y,30.63) for x in (28.72,29.2,29.60) for y in (56.7,57.2,59.23,60.3,61.4,62.7,64,65.5)],'bath_dedicated_dry_turn':[(x,59.23,30.63) for x in (30.22,30.75,31.27)]}
 T=[(x,y,z) for x,y in ((30.3,61.95),(30.76,61.95),(31.2,62.21)) for z in (29.89,30.67)]
 res={}
 for n,oo in O.items():
  out=[]
  for o in oo:
   for t in T:
    v=Vector(t)-Vector(o);q,_,i,_=b.ray_cast(Vector(o),v.normalized(),v.length-1e-4)
    out.append({'eye':o,'target':t,'block':names[i] if q is not None else None})
  res[n]=out
 return res
open_=ocular()
for o in pivots:o.rotation_euler.z=0.
bpy.context.view_layer.update();closed=ocular()
R={'candidate_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'saved_open':open_,'closed_pose_temporary_in_memory':closed}
(P/'GATE_LOCAL_CHECK.json').write_text(json.dumps(R,indent=2))
for k in open_:print(k,'open',sum(not z['block'] for z in open_[k]),'closed',sum(not z['block'] for z in closed[k]),'total',len(closed[k]),flush=True)
assert all(z['block'] for r in closed.values() for z in r)
