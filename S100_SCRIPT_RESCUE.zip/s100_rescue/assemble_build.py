from pathlib import Path
p=Path(__file__).resolve().parent
s=(p.parent/'s99_candidate/build_s99.py').read_text()
head=s[:s.index('rib=material')].replace('S99','S100').replace('s98_candidate','s99_candidate').replace('Tidehall stone architecture','Sea-grotto family bathing suite')
helper=s[s.index('def mesh('):s.index('def cup')].replace('S99','S100')
(p/'build_s100.py').write_text(head+helper+(p/'build_body.py').read_text())
