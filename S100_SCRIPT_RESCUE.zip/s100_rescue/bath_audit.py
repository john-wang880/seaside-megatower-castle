import bpy, sys, pathlib, json
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'s95_candidate'))
from geometry_core import SceneGeometry
from stair_tools import validate_level_route
src=P.parent/'s99_candidate/candidate.blend'
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
retire=[o.name for o in bpy.context.scene.objects if not o.hide_render and o.type=='MESH' and o.name.startswith(('S96 | vanity','S96 | bathing'))]
assert len(retire)==44
for n in retire:
 o=bpy.data.objects[n];o.hide_render=True;o.hide_viewport=True
bpy.context.view_layer.update()
G=SceneGeometry(lo=(27.25,55,28.72),hi=(31.8,65.5,32.1));F=29.008
rows=[]
for key,pts,z,head in [('existing hallway',[(29.2,55.1),(29.2,61),(29,61),(29,65.5)],F,2.25),('new dry approach',[(29.2,59.23),(30.75,59.23)],F,2.25),('new dry turning square',[(30.75,59.23),(30.75,59.24)],F,2.25)]:
 rows+=validate_level_route(G,{'id':key,'points':[(x,y,z)for x,y in pts],'required_clear_width':1.1,'headroom':head})
d=json.loads((P/'ARCHITECTURE_AUDIT.json').read_text())
d['bath_trial']={'candidate_removed_in_memory_only':retire,'routes':rows,'route_z':F,'new_footprint_limits': [[29.8,59.80,29.008],[31.745,62.94,32.07]],'capacity_note':'No new geometry tested; paths tested in cleared source. Preserve route outside x29.8; upper beams y58.34–58.66 and62.34–62.66 reach z31.55.'}
(P/'ARCHITECTURE_AUDIT.json').write_text(json.dumps(d,indent=2))
for r in rows:print(r['id'],r['passed'],[b['object'] for b in r['blocks']])
