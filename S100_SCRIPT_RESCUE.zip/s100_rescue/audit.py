import bpy, json, pathlib, hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
p=pathlib.Path(__file__).resolve().parent
src=p.parent/'s99_candidate/candidate.blend'
h=hashlib.sha256(src.read_bytes()).hexdigest()
assert h=='47483d39bcb68f3839bfc821b943f7f19a277f56d5804e61f60dbdc76142d0da'
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
dg=bpy.context.evaluated_depsgraph_get()
obs=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or o.hide_render or o.hide_viewport: continue
 e=o.evaluated_get(dg)
 v=[e.matrix_world@Vector(q) for q in e.bound_box]
 lo=tuple(min(q[k] for q in v) for k in range(3));hi=tuple(max(q[k] for q in v) for k in range(3))
 if any(b<lo[k] or a>hi[k] for k,(a,b) in enumerate(((18,44),(41,68),(24,45)))):continue
 obs.append((o,lo,hi,BVHTree.FromObject(o,dg),e.matrix_world.inverted()))
r={'source_sha256':h,'objects':[(o.name,lo,hi,len(o.data.polygons)) for o,lo,hi,*_ in obs],'vertical':{}}
for x in range(22,43):
 for y in range(42,65):
  out=[]
  for o,lo,hi,b,inv in obs:
   if not (lo[0]<x<hi[0] and lo[1]<y<hi[1]):continue
   z=23.
   for k in range(30):
    q,_,_,_=b.ray_cast(inv@Vector((x,y,z)),inv.to_3x3()@Vector((0,0,1)))
    if q is None:break
    z=(inv.inverted()@q).z
    if z>45:break
    if z>=24:out.append((round(z,4),o.name))
    z+=0.001
  r['vertical'][f'{x},{y}']=sorted(out)
(p/'ARCHITECTURE_AUDIT.json').write_text(json.dumps(r,indent=2))
