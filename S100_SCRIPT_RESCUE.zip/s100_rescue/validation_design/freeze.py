import hashlib,json,pathlib
P=pathlib.Path(__file__).resolve().parent.parent
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
B=P/'S100_BUILD_SCOPE.json'; A=P/'ARCHITECTURE_AUDIT.json';s=json.loads(B.read_text())
assert s['source_sha256']=='47483d39bcb68f3839bfc821b943f7f19a277f56d5804e61f60dbdc76142d0da'
assert len(set(s['approved_hide_exact']))==44 and all(n.startswith(('S96 | vanity ','S96 | bathing ')) for n in s['approved_hide_exact'])
assert s['wet_clear_x']==[30.2,31.3] and s['min_headroom']==2.25
assert s['addition_domains']['wet_arch_and_pool']==[[29.8,59.8,29.008],[31.745,62.94,32.07]]
assert s['addition_domains']['dry_stone_washstand']==[[30.38,57.56,29.008],[31.745,58.57,31.32]]
assert s['water_z']==29.258 and s['tread_z_y'][-1]==[61.24,62.72,29.05]
if 'privacy' in s:
 q=s['privacy']
 assert s['addition_domains']['gate_sweep_saved_open_and_closed']==[[29.98,59.78,29.428],[31.57,60.57,31.29]]
 assert q['open_angles_degrees']==[-90,90] and q['closed_angles_degrees']==[0,0]
 assert q['hinge_leaf_west']==[30.126,60.486,29.441] and q['hinge_leaf_east']==[31.44,60.486,29.441]
 assert q['west_screen']==[[29.805,59.805,29.485],[30.054,62.79,31.125]]
 s['gate_exact']={}
 for side in ('west','east'):
  pre=f'S100 | {side} privacy gate '
  mesh=[pre+t for t in ['solid opaque oak leaf','forged internal strap','forged internal strap.001','forged internal strap.002','deep raised narrow board rib','deep raised narrow board rib.001','deep raised narrow board rib.002','deep raised narrow board rib.003','deep raised narrow board rib.004','recessed pull surround']]
  if side=='west':mesh.append(pre+'opaque meeting astragal')
  s['gate_exact'][side]={'moving':mesh,'fixed':[pre+'fixed stone jamb']+[f'S100 | {side} stationary hinge pin'+x for x in ('','.001','.002')],'pivot':q[side+'_pivot']}
s.update(raw_scope_sha256=H(B),source_audit_sha256=H(A) if A.exists() else None,candidate_existed_before_independent_lock=True,authorized_source='Recovered constraints from approved S100 scope, never from BUILD.json',protected_routes=[
 ['privy approach',[[29.2,55.1],[29.2,61],[29,61],[29,65.5]]],['privy dogleg',[[29,65.5],[30.45,65.5],[30.45,67.55],[28.3,67.55]]],['dry east connection',[[29.2,59.23],[30.75,59.23]]],['washstone approach',[[29.2,58.15],[29.75,58.15]]]])
out=P/'validation_design/INDEPENDENT_SCOPE.json';out.write_text(json.dumps(s,indent=2,sort_keys=True)+'\n');print(H(out))
