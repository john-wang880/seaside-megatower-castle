"""Recovered S100 saved-scene core validation. Requires recovered S99 validator helper definitions."""
import pathlib,sys
P=pathlib.Path(__file__).resolve().parent
root=P.parent.parent
# Reuse only the old, independently proven geometry and snapshot definitions, not old scope or verdict.
p=(root/'s99_candidate/validation_design/validate.py').read_text()
p=p[:p.index('def check_shape')]; a0=p.index('scope=read'); b0=p.index('def check(id',a0)
p=p[:a0]+"""scope=read(P/'INDEPENDENT_SCOPE.json')
a.model=str(pathlib.Path(a.model).resolve())
source=ROOT/'s99_candidate/candidate.blend'
assert H(source)==scope['source_sha256']
assert H(P.parent/'S100_BUILD_SCOPE.json')==scope['raw_scope_sha256']
R={'all_passed':False,'model_sha256':H(pathlib.Path(a.model)),'scope_sha256':H(P/'INDEPENDENT_SCOPE.json'),'rows':[]}
"""+p[b0:]
p=p.replace("'blocked_entry','ceiling_penetration','disconnected_pier'","'blocked_turn','broken_tread','beam_contact'")
exec(compile(p,'S99 preserved helper definitions','exec'))
PRE='S100 | '; F=scope['dry_floor']; A,B=scope['wet_clear_x']; W=PRE+'water surface static only'
POOL=PRE+'continuous stepped basin foundation'; VAULT=PRE+'continuous barrel vault stone backing'
WALLS=[PRE+'pool '+s+' continuous retaining wall' for s in ('west','east')]+[PRE+'pool rear retaining wall']
def bounds(g):return g['lo'].min(0),g['hi'].max(0)
def closed(n):
 o=bpy.data.objects.get(n)
 if not o:return False
 ev=o.evaluated_get(bpy.context.evaluated_depsgraph_get()); me=ev.to_mesh(); bm=bmesh.new()
 try:
  bm.from_mesh(me)
  return bool(bm.faces) and all(e.is_manifold for e in bm.edges) and bm.calc_volume(signed=True)>1e-8
 finally:bm.free();ev.to_mesh_clear()
PC.ALLOWED=set(scope['approved_hide_exact'])
if not a.negative:openfile(source);base=snapshot()
openfile(pathlib.Path(a.model))
if not a.negative:
 now=snapshot();old=set(base[0]);new=set(now[0])-old; retire=PC.ALLOWED
 check('all_source_objects_kept',old<=set(now[0]),sorted(old-set(now[0])))
 for ix,n in [(0,'source_raw'),(3,'source_evaluated_binding')]:
  bad=[k for k in sorted(old) if k not in now[ix] or (base[ix][k] if ix==0 else base[ix][k][:2])!=(now[ix][k] if ix==0 else now[ix][k][:2])]
  check(n,not bad,bad[:100])
 bad=[]
 for k in old & set(now[3]):
  vb,vn=base[3][k][2],now[3][k][2]
  ok=(vb[1:]==(False,False,True,True) and vn[1:]==(True,True,False,True) and vb[0]==vn[0]) if k in retire else vb==vn
  if not ok:bad.append(k)
 check('only_frozen_retire_visibility',not bad,bad)
 check('original_material_world_collections',base[2]==now[2] and all(now[1].get(k)==v for k,v in base[1].items()) and all(k in now[4] and v[:2]==now[4][k][:2] and set(v[2])<=set(now[4][k][2]) for k,v in base[4].items()))
G=SceneGeometry(lo=(27.2,55,28.72),hi=(32.1,69.57,32.4));water=G.objects.pop(W,None)
if not a.negative:
 gate={m for q in scope.get('gate_exact',{}).values() for m in q['moving']+q['fixed']}; piv={q['pivot'] for q in scope.get('gate_exact',{}).values()}
 check('exact_gate_required',gate|piv<=new)
 for n in sorted(new):
  o=bpy.data.objects[n];ok=False
  if n.startswith(PRE) and o.visible_get() and not o.hide_render:
   g=water if n==W else G.objects.get(n)
   if o.type=='MESH' and g is not None:
    ds=('gate_sweep_saved_open_and_closed',) if n in gate else ('wet_arch_and_pool','dry_stone_washstand')
    ok=any(insidebox(g,scope['addition_domains'][d]) for d in ds)
   elif o.type=='LIGHT':
    ok=all(l-2e-5<=v<=h+2e-5 for l,v,h in zip(scope['addition_domains']['local_lighting'][0],o.location,scope['addition_domains']['local_lighting'][1]))
   elif o.type=='EMPTY' and n in piv:
    side=next(side for side,q in scope['gate_exact'].items() if q['pivot']==n)
    ok=(o.location-Vector(scope['privacy']['hinge_leaf_'+side])).length<2e-5 and abs(o.rotation_euler.z-math.radians(-90 if side=='west' else 90))<2e-6
   elif o.type=='CAMERA' and n in scope['cameras']:
    c=scope['cameras'][n];direction=(o.matrix_world.to_quaternion()@Vector((0,0,-1))).normalized()
    ok=(o.location-Vector(c['location'])).length<1e-5 and (direction-(Vector(c['target'])-o.location).normalized()).length<1e-5 and abs(o.data.lens-c['lens'])<1e-5
  check('new_domain:'+n,ok)
 check('required_cameras',set(scope['cameras'])<=new)
for name,pts in scope['protected_routes']:
 for r in validate_level_route(G,{'id':name,'points':[(x,y,F) for x,y in pts],'required_clear_width':1.10,'headroom':2.25}):check('dry:'+r['id'],r['passed'],r)
q=G.rectangle('dry turn',[A,58.68],[B,59.79998],F,2.25,.002,.002);check('dry_turn',q['passed'],q)
walk=scope['tread_z_y'];prior=F
for i,(y,Y,z) in enumerate(walk):
 q=G.rectangle(f'tread {i}',[A,y+2e-5],[B,Y-2e-5],z,2.25,.002,.002)
 check(f'tread:{i}',q['passed'] and POOL in q['support_objects'] and Y-y>=.27999 and .12<=abs(z-prior)<=.15,q);prior=z
for n in [POOL,VAULT]+WALLS:check('closed:'+n,closed(n))
g=G.objects[POOL]
samples=[(float(x),float(y)) for x in np.linspace(A,B,7) for y in np.linspace(59.81,62.70,15)]
check('basin_closed_grounded_and_thick',all(any(abs(v-F)<1e-5 for v in vertical(g,x,y)) for x,y in samples) and min(z-F for _,_,z in walk)>=.04)
if water is not None and all(n in G.objects for n in WALLS):
 x,y,z=scope['water_x'],scope['water_y'],scope['water_z']; wl,we,wr=[bounds(G.objects[n]) for n in WALLS]; lip=min(wl[1][2],we[1][2],wr[1][2],walk[3][2])
 check('static_water_below_lip',np.allclose(bounds(water),([x[0],y[0],z],[x[1],y[1],z]),atol=2e-5,rtol=0) and abs(wl[1][0]-x[0])<2e-5 and abs(we[0][0]-x[1])<2e-5 and abs(wr[0][1]-y[1])<2e-5 and lip-z>=.04 and len(water['indices'])==2,dict(dry_lip=float(lip-z),depth=z-walk[-1][2],render_mesh_not_counted_as_walkable=True))
else:check('water_observed',False)
g=G.objects[VAULT]
miss=[(float(x),float(y)) for x in np.linspace(29.85,31.71,35) for y in np.linspace(59.925,62.235,19) if len(vertical(g,float(x),float(y)))<2]
check('continuous_arch_backing',not miss,miss[:20])
for tag,y in [('entrance',60.05),('middle',61.12),('far',62.105)]:
 for side,x in [('west',29.935),('east',31.629)]:
  n=PRE+side+' '+tag+' carved stone spring pier';b=PRE+tag+' integral carved arch band'; w=[]
  xx=np.linspace(x-.105,x+.105,85);yy=np.linspace(y-.034,y+.034,9)
  for X in xx:
   for Y in yy:
    pz=vertical(G.objects[n],float(X),float(Y));rz=vertical(G.objects[b],float(X),float(Y))
    if pz and rz and abs(min(pz)-F)<2e-5 and max(pz)-min(rz)>2e-5:w.append(max(pz)-min(rz))
  ar=len(w)*(xx[1]-xx[0])*(yy[1]-yy[0]);check('arch_contact:'+n,closed(n) and closed(b) and ar>=.001,float(ar))
collisions=[]
for n,g in G.objects.items():
 if not n.startswith(PRE):continue
 lo,hi=bounds(g)
 for k,o in G.objects.items():
  if k.startswith(PRE):continue
  ol,oh=bounds(o); l=np.maximum(lo,ol);h=np.minimum(hi,oh)
  if np.min(h-l)<=3e-5:continue
  mask=(o['hi']>=l).all(1)&(o['lo']<=h).all(1)
  t=o['triangles'][mask].reshape((-1,3))
  if len(t):
   bt=BVHTree.FromPolygons(t.tolist(),[(i,i+1,i+2) for i in range(0,len(t),3)],all_triangles=True)
   hits=tree(g).overlap(bt)
   if hits:collisions.append([n,k,len(hits)])
check('no_old_surface_penetration',not collisions,collisions)
R['failures']=[r['id'] for r in R['rows'] if not r['passed']];R['all_passed']=not R['failures']
if a.negative:
 expect={'blocked_turn':'dry_turn','broken_tread':'tread:','beam_contact':'no_old_surface_penetration'}[a.negative]
 R['expected_semantic_failure']=any(s.startswith(expect) for s in R['failures'])
pathlib.Path(a.out).write_text(json.dumps(R,indent=2,allow_nan=False,default=lambda x:x.item()))
assert R['all_passed'],R['failures']
