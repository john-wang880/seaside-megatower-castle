"""Saved open vs temporarily closed hinge poses; continuous envelope exclusion against old solids and sampled collision against new work."""
import bpy,sys,pathlib,json,hashlib,math,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent.parent/'s98_candidate'))
from geometry_core import SceneGeometry,boxclip
S=json.loads((P/'INDEPENDENT_SCOPE.json').read_text());Q=S['privacy'];D=S['gate_exact'];m=P.parent/'candidate.blend'
bpy.ops.wm.open_mainfile(filepath=str(m),use_scripts=False)
rows=[]
def check(k,p,e=None): rows.append(dict(id=k,passed=bool(p),evidence=e))
def opaque(o):
 return all(not a or (a.diffuse_color[3]>.999 and (not a.use_nodes or all(n.bl_idname not in ('ShaderNodeBsdfTransparent','ShaderNodeBsdfGlass','ShaderNodeBsdfRefraction') and (n.bl_idname!='ShaderNodeBsdfPrincipled' or all(n.inputs[k].default_value>=.999 if k=='Alpha' else n.inputs[k].default_value<=.001 for k in ('Alpha','Transmission Weight') if k in n.inputs)) for n in a.node_tree.nodes))) for a in o.data.materials)
def take():return SceneGeometry(lo=(27,53,28.7),hi=(32,70,33))
def observe(G):
 v=[];f=[];names=[]
 for n,g in G.objects.items():
  if not opaque(bpy.data.objects[n]):continue
  f.extend((g['indices']+len(v)).tolist());v.extend(g['vertices'].tolist());names.extend([n]*len(g['indices']))
 b=BVHTree.FromPolygons(v,f,all_triangles=True)
 groups={'outer':[(29.2,y,30.63) for y in (54,55.1,55.25)],'shared':[(x,y,30.63) for x in (28.72,29.2,29.60) for y in (56.7,57.2,59.23,60.3,61.4,62.7,64,65.5)],'dry_bath':[(x,59.23,30.63) for x in (30.22,30.75,31.27)],'inside_privy':[(29,65.5,30.63),(30.45,67.55,30.63),(29.15,67.55,30.63)]}
 targets={k:[(x,y,z) for x,y in ((30.3,61.95),(30.76,61.95),(31.2,62.21))] for k,z in [('bath_seated',29.89),('bath_standing',30.67)]}
 targets['privy']=[(28.28,68.78,z) for z in (29.46,30.06,30.36)]
 d={}
 for k,eyes in groups.items():
  for j,pts in targets.items():
   cells=[]
   for a,c in ((a,c) for a in eyes for c in pts):
    o=Vector(a);delta=Vector(c)-o
    hit,_,i,_=b.ray_cast(o,delta.normalized(),delta.length-1e-4)
    cells.append(dict(eye=a,target=c,occluder=None if hit is None else names[i],point=None if hit is None else list(hit)))
   d[k+'.'+j]=cells
 return d
def sweep(obj,pivot,A):
 E=bpy.context.evaluated_depsgraph_get();o=obj.evaluated_get(E);me=o.to_mesh();M=pivot.matrix_world.inverted()@o.matrix_world
 points=[tuple(M@u.co) for u in me.vertices];o.to_mesh_clear();lo,hi=sorted((0,A));out=[]
 for x,y,z in points:
  ph=math.atan2(y,x); ts=[lo,hi]+[i*math.pi/2-ph for i in range(-8,9) if lo<=i*math.pi/2-ph<=hi]
  out.extend((pivot.location.x+x*math.cos(t)-y*math.sin(t),pivot.location.y+x*math.sin(t)+y*math.cos(t),pivot.location.z+z) for t in ts)
 return np.min(out,0),np.max(out,0)
G=take();O=observe(G);piv={};domain=S['addition_domains']['gate_sweep_saved_open_and_closed']
for side,A in zip(('west','east'),(-math.pi/2,math.pi/2)):
 q=D[side];o=bpy.data.objects[q['pivot']];piv[side]=(o,A)
 check('exact_hinge:'+side,abs(o.rotation_euler.z-A)<2e-6 and set(q['moving'])==set(c.name for c in o.children))
 for n in q['moving']:
  lo,hi=sweep(bpy.data.objects[n],o,A);a=lo+2e-5;b=hi-2e-5;touch=[]
  for k,g in G.objects.items():
   if k.startswith('S100 | '):continue
   mask=(g['hi']>a).all(1)&(g['lo']<b).all(1)
   if any(boxclip(list(t),a,b) for t in g['triangles'][mask]):touch.append(k)
  check('continuous_old_exclusion:'+n,not touch and np.all(lo>=np.array(domain[0])-2e-5) and np.all(hi<=np.array(domain[1])+2e-5),dict(lo=lo.tolist(),hi=hi.tolist(),old=touch))
def tree(g):return BVHTree.FromPolygons(g['vertices'],g['indices'],all_triangles=True)
hits={}
for t in np.linspace(0,1,37):
 for o,A in piv.values():o.rotation_euler.z=float(t)*A
 bpy.context.view_layer.update()
 geom=SceneGeometry(lo=(29.6,59.55,29.1),hi=(31.8,60.6,31.4)).objects; trees={}
 def get(n):
  if n not in trees:trees[n]=tree(geom[n])
  return trees[n]
 for q in D.values():
  for n in q['moving']:
   g=geom[n];a,b=g['lo'].min(0),g['hi'].max(0)
   for k,h in geom.items():
    if not k.startswith('S100 | ') or k in q['moving']+q['fixed']:continue
    c,d=h['lo'].min(0),h['hi'].max(0)
    if np.all(np.minimum(b,d)-np.maximum(a,c)>2e-5) and get(n).overlap(get(k)):hits.setdefault(n+' -> '+k,[]).append(float(t))
check('sampled_sweep_v_new_parts',not hits,hits)
for o,_ in piv.values():o.rotation_euler.z=0
bpy.context.view_layer.update();closed=take();Z=observe(closed)
for n,r in Z.items():
 if n.startswith('inside_privy'):continue
 check('closed_opaque:'+n,all(x['occluder'] for x in r),dict(open_unblocked=sum(not x['occluder'] for x in O[n]),closed_unblocked=sum(not x['occluder'] for x in r)))
 if n.endswith('.privy'):check('old_privy_open:'+n,all(x['occluder'] for x in O[n]))
q=closed.rectangle('closed gate intentional obstruction',[30.2,60.44],[31.3,60.65],29.428,1.7,.002,.002)
check('closed_gate_intentionally_not_traversable',any('solid opaque oak leaf' in x['object'] for x in q['blocks']),q)
r=dict(all_passed=all(x['passed'] for x in rows),model_sha256=hashlib.sha256(m.read_bytes()).hexdigest(),checks=rows,saved_open=O,closed_hinges_only_in_memory=Z)
(P/'GATE_VALIDATION.json').write_text(json.dumps(r,indent=2,allow_nan=False,default=lambda x:x.item()))
assert r['all_passed'],[x['id'] for x in rows if not x['passed']]
