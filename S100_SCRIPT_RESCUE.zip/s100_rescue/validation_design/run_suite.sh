#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd)
B=$(realpath "${BLENDER:-"$D/../../tools/blender-5.2.3-linux-x64/blender"}")
cd "$D"
bpy() { "$B" -b -t 2 --python-exit-code 2 --python "$@"; }
for p in validate validate_contact_detail validate_gate;do
 [ "${S100_REUSE_TARGETED:-0}" != 1 ] || break
 bpy "$D/$p.py" > "$D/$p.log" 2>&1
done
bpy "$D/make_negatives.py" > negatives_make.log 2>&1
for n in blocked_turn broken_tread beam_contact;do
 result=0
 bpy "$D/validate.py" -- --model "$D/negative_models/$n.blend" --negative "$n" --out "$D/negative_$n.json" > "negative_$n.log" 2>&1 || result=$?
 test "$result" = 2
 python3 - "$n" <<'PY'
import json,sys
d=json.load(open('negative_'+sys.argv[1]+'.json'))
assert d['all_passed'] is False and d['expected_semantic_failure'] is True
PY
done
python3 restore_history.py
cd history
for v in validate_baseline_s90 validate_baseline_s91 validate_baseline_s92 validate_baseline_s93 validate_baseline_s94 validate_s94_fixtures validate_baseline_s95 validate_s95_fixtures validate_baseline_s96 validate_s96_fixtures validate_s96_privacy validate_guards validate_privacy validate_coplanar validate_s97_retained_routes validate_fixtures;do
 bpy "$v.py" > "$v.log" 2>&1
done
cd outdoor_s98
bpy validate_s98_routes.py > validate.log 2>&1
cd "$D"
BLENDER="$B" bash rebuild.sh
python3 collect_suite.py
