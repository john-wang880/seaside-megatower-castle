#!/bin/bash
set -euo pipefail
D=$(cd "$(dirname "$0")" && pwd); P=$(dirname "$D"); BASE=$(dirname "$P")
B=$(realpath "${BLENDER:-"$BASE/tools/blender-5.2.3-linux-x64/blender"}")
R="$D/isolated_rebuild"; mkdir -p "$R/s100" "$R/s99_candidate"
cp "$P/build_s100.py" "$P/S100_BUILD_SCOPE.json" "$R/s100/"
ln -sfn "$BASE/s99_candidate/candidate.blend" "$R/s99_candidate/candidate.blend"
sed 's@isolated_rebuild/s99/@isolated_rebuild/s100/@' "$BASE/s99_candidate/validation_design/compare_all.py" > "$D/compare_all.py"
"$B" -b -t 2 --python-exit-code 2 --python "$R/s100/build_s100.py" > "$R/build.log" 2>&1
"$B" -b -t 2 --python-exit-code 2 --python "$D/compare_all.py" > "$R/compare.log" 2>&1
