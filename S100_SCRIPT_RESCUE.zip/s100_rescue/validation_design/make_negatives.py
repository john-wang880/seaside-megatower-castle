import bpy,pathlib
P=pathlib.Path(__file__).resolve().parent;O=P/'negative_models';O.mkdir(exist_ok=True)
for name in ('blocked_turn','broken_tread','beam_contact'):
 bpy.ops.wm.open_mainfile(filepath=str(P.parent/'candidate.blend'),use_scripts=False)
 bpy.context.preferences.filepaths.save_version=0
 if name=='broken_tread':
  g=bpy.data.objects['S100 | continuous stepped basin foundation']
  for v in g.data.vertices:
   if abs(v.co.z-29.288)<2e-5:v.co.z-=.05
 elif name=='beam_contact':
  g=bpy.data.objects['S100 | far integral carved arch band'];g.location.y+=.37
 else:
  bpy.ops.mesh.primitive_cube_add(size=1,location=(30.75,59.2,29.28));o=bpy.context.object
  o.name='S100 | NEGATIVE TURN';o.dimensions=(.35,.38,.54)
  bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 bpy.ops.wm.save_as_mainfile(filepath=str(O/(name+'.blend')),check_existing=False)
