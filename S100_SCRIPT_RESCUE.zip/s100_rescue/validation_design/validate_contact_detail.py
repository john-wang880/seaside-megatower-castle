import hashlib,json,pathlib,sys
import bpy,numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent.parent/'s98_candidate'))
from geometry_core import SceneGeometry
m=P.parent/'candidate.blend';S=json.loads((P/'INDEPENDENT_SCOPE.json').read_text())
bpy.ops.wm.open_mainfile(filepath=str(m),use_scripts=False)
G=SceneGeometry(lo=(28.4,57.3,28.8),hi=(31.8,63,32.2))
F=S['dry_floor'];pre='S100 | ';rows=[];vs=[];fs=[];names=[]
for n,g in G.objects.items():
 if n.startswith(pre):continue
 fs.extend((g['indices']+len(vs)).tolist());vs.extend(g['vertices'].tolist());names.extend([n]*len(g['indices']))
b=BVHTree.FromPolygons(vs,fs,all_triangles=True)
def sample(xy):
 a=[]
 for x,y in xy:
  hit,_,i,_=b.ray_cast(Vector((x,y,F+.002)),Vector((0,0,-1)),.005)
  a.append(dict(x=float(x),y=float(y),z=None if hit is None else hit.z,support=None if hit is None else names[i]))
 return a
def report(n,ss,p=True):
 rows.append(dict(id=n,passed=bool(p and all(x['z'] is not None and abs(x['z']-F)<.002 for x in ss)),samples=ss))
report('original_support_entire_pool',sample((x,y) for x in np.linspace(29.83,31.665,9) for y in np.linspace(59.86,62.86,11)))
for n in sorted(n for n in G.objects if 'washstand lower ashlar cheek' in n):
 g=G.objects[n];lo,hi=g['lo'].min(0),g['hi'].max(0)
 report(n,sample((x,y) for x in np.linspace(lo[0]+.005,hi[0]-.005,5) for y in np.linspace(lo[1]+.005,hi[1]-.005,3)),abs(lo[2]-F)<2e-5)
q=G.rectangle('recessed stone wash bowl',[30.61,57.77],[31.51,58.36],29.922,.08,.002,.002)
rows.append(dict(id='washstand_recess_real',passed=q['passed'] and pre+'closed-bottom washstone' in q['support_objects'],geometry=q))
r=dict(model_sha256=hashlib.sha256(m.read_bytes()).hexdigest(),all_passed=all(q['passed'] for q in rows),checks=rows)
(P/'CONTACT_DETAIL.json').write_text(json.dumps(r,indent=2,allow_nan=False,default=lambda x:x.item()))
assert r['all_passed']
