from pathlib import Path
P=Path(__file__).resolve().parent
L=P.parent.parent/'s99_candidate/validation_design'
ex=(L/'prepare_legacy.py').read_text()
ns={'__file__':__file__,'__name__':'__main__'}
exec(compile(ex,str(L/'prepare_legacy.py'),'exec'),ns)
D=P/'history'
p=D/'validate_baseline_s96.py';s=p.read_text();a=s.index('fixed=');b=s.index('\ntry:',a)
p.write_text(s[:a]+"fixed=[route('privy around privacy baffle',[(29,65.5),(30.45,65.5),(30.45,67.55),(29.15,67.55),(28.30,67.55)])]"+s[b:])
p=D/'validate_s96_fixtures.py';s=p.read_text()
s=s.replace("for n in sorted(actual):","retired=set(json.loads((P.parent/'INDEPENDENT_SCOPE.json').read_text())['approved_hide_exact'])\n for n in sorted(actual-retired):")
s=s.replace("for kind,lo,hi,z,height in spec:","for kind,lo,hi,z,height in spec:\n  if name(kind) in retired:continue")
s=s.replace("for kind in contacts:","for kind in contacts:\n  if name(kind) in retired:continue")
s=s.replace(",(name('bathing privacy screen'),[[29.845,59.50,29.008],[31.72,59.63,30.8]])","")
a=s.index(" tr=G.objects[name('bathing hollow stoneware tub')]");s=s[:a]+s[s.index(" seat=G.objects",a):];p.write_text(s)
p=D/'validate_s96_privacy.py';s=p.read_text()
p.write_text(s.replace(" and all(q['blocked'] and q['hits_new_bath_screen'] for q in bath)",""))
