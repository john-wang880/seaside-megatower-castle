import pathlib,hashlib,json
P=pathlib.Path(__file__).resolve().parent; Q=P.parent
H=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
model=H(Q/'candidate.blend'); rows=[]
def add(p,kind):
 d=json.loads(p.read_text()); k=d.get('model_sha256',d.get('candidate_sha256')); passed=d.get('all_passed',d.get('passed'))
 if kind=='negative':
  variant=p.stem.removeprefix('negative_')
  assert k==H(P/'negative_models'/f'{variant}.blend')!=model and passed is False and d['expected_semantic_failure'] is True
 else:assert k==model and passed is True,p
 rows.append(dict(path=p.relative_to(Q).as_posix(),sha256=H(p),passed=True,kind=kind))
for f in ('VALIDATION.json','CONTACT_DETAIL.json','GATE_VALIDATION.json','history/outdoor_s98/S98_ROUTE_VALIDATION.json'):add(P/f,'positive')
for f in ('BASELINE_S90_REGRESSION BASELINE_S91_REGRESSION BASELINE_S92_REGRESSION BASELINE_S93_REGRESSION BASELINE_S94_REGRESSION BASELINE_S94_FIXTURES BASELINE_S95_REGRESSION BASELINE_S95_FIXTURES BASELINE_S96_REGRESSION BASELINE_S96_FIXTURES BASELINE_S96_PRIVACY GUARD_INTEGRATION PRIVACY_AUDIT COPLANAR_VALIDATION ROUTE_VALIDATION FIXTURE_VALIDATION').split():add(P/'history'/f'{f}.json','positive')
for n in ('blocked_turn','broken_tread','beam_contact'):add(P/f'negative_{n}.json','negative')
for f in ('REBUILD_VERIFIED.json','SCENE_SETTINGS_REBUILD.json'):add(P/f,'rebuild')
r=dict(all_passed=True,candidate_sha256=model,reports=rows,positive_count=20,negative_count=3,rebuild_count=2,scope='S100 local stone bath, closed gate sampled opacity and open transit; retained S99, no independent catering or plumbing.')
(Q/'S100_VALIDATION_SUITE.json').write_text(json.dumps(r,indent=2)+'\n')
