from pathlib import Path
import bpy, math, hashlib, json
from mathutils import Vector
from math import sin,cos,pi
P=Path(__file__).resolve().parent
S=json.loads((P/'S102_BUILD_SCOPE.json').read_text())
src=P.parent/'s101_candidate/candidate.blend'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(src)==S['source_sha256']
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
sc=bpy.context.scene
C=bpy.data.collections.new('S102 | Sea-glass family chambers');sc.collection.children.link(C)
new=[];hidden=[]
for n in S['approved_hide_exact']:
 o=bpy.data.objects[n]; assert not o.hide_render
 o.hide_render=True;o.hide_viewport=True;hidden.append(n)
def material(name,c,rough=.7,met=0,emit=0,tex=None):
 m=bpy.data.materials.new('S102 | '+name);m.diffuse_color=(*c,1);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=met
 if emit:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emit
 if tex:
  k=n.new('ShaderNodeTexCoord');a=n.new('ShaderNodeTexNoise');a.inputs['Scale'].default_value=2.7;a.inputs['Detail'].default_value=4;l.new(k.outputs['Object'],a.inputs['Vector'])
  r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.21;r.color_ramp.elements[0].color=(*(v*.66 for v in c),1);r.color_ramp.elements[1].position=.83;r.color_ramp.elements[1].color=(*(v*1.34 for v in c),1);l.new(a.outputs['Fac'],r.inputs[0]);l.new(r.outputs['Color'],p.inputs['Base Color'])
  f=n.new('ShaderNodeTexNoise');f.inputs['Scale'].default_value=27;f.inputs['Detail'].default_value=3;l.new(k.outputs['Object'],f.inputs['Vector']);b=n.new('ShaderNodeBump');b.inputs['Distance'].default_value=.035;b.inputs['Strength'].default_value=.29;l.new(f.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],p.inputs['Normal'])
 return m
def mesh(n,v,f,m,mi=None):
 d=bpy.data.meshes.new('S102 | '+n);d.from_pydata(v,[],f);d.update()
 for a in (m if isinstance(m,list) else [m]):d.materials.append(a)
 if mi:
  for a,i in zip(d.polygons,mi):a.material_index=i
 o=bpy.data.objects.new(d.name,d);C.objects.link(o);new.append(o.name);return o
faces=[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
def box(n,lo,hi,m):
 x,y,z=lo;a,b,c=hi
 return mesh(n,[(x,y,z),(a,y,z),(a,b,z),(x,b,z),(x,y,c),(a,y,c),(a,b,c),(x,b,c)],faces,m)
def ring(n,x,y,base,levels,m,N=12):
 v=[(x+rx*cos(2*pi*i/N+pi/12),y+ry*sin(2*pi*i/N+pi/12),base+z) for z,rx,ry in levels for i in range(N)]
 f=[tuple(range(N-1,-1,-1))]
 for j in range(len(levels)-1):
  a=j*N;b=a+N
  for i in range(N):q=(i+1)%N;f.append((a+i,a+q,b+q,b+i))
 a=(len(levels)-1)*N;f.append(tuple(range(a,a+N)));return mesh(n,v,f,m)
import random
rng=random.Random(102)
oak=material('dark finish on ribbed oak',(.143,.073,.040),.56,tex=True)
gold=material('burnished brass inlay',(.36,.21,.077),.36,.61)
stone=material('warm dressed sandstone',(.44,.303,.199),.69,tex=True)
sable=material('shadowed sandstone joints',(.19,.141,.099),.85,tex=True)
sea=material('coastal deep teal soft wool',(.035,.188,.158),.98,tex=True)
cel=material('washed sea-glass fabric',(.16,.33,.235),.92,tex=True)
cream=material('ivory flax silk',(.64,.54,.365),.87,tex=True)
F=29.008
# Supported coherent sleeping bay: ground-bearing stepped masonry foot, raised oak deck, actual bedding.
box('owner bed continuous grounded stone dais',(15.76,65.29,F),(19.27,68.78,29.158),stone)
box('owner bed reduced plinth mould',(15.85,65.38,29.158),(19.18,68.70,29.222),sable)
box('dais inset platform stone',(15.89,65.41,29.222),(19.13,68.66,29.26),stone)
box('bed thick carved oak box bedstead',(16.25,65.89,29.26),(18.77,68.59,29.55),oak)
box('bed support running bottom',(16.31,65.9,29.265),(18.69,68.60,29.41),oak)
box('linen mattress',(16.30,65.95,29.55),(18.72,68.44,29.753),cream)
box('woven teal counterpane',(16.30,65.95,29.753),(18.72,67.78,29.808),sea)
box('counterpane draped facing',(16.32,65.924,29.61),(18.70,65.948,29.793),sea)
for x in (16.52,17.66):
 box('filled linen pillow',(x,67.87,29.755),(x+.85,68.35,29.88),cream)
box('low footboard carved rail',(16.23,65.86,29.55),(18.78,65.922,29.719),oak)
box('thick bedhead carved panel',(16.20,68.47,29.55),(18.82,68.571,30.76),oak)
for i in range(8):
 x=16.31+i*.300
 box('bedhead contrasting fluted inlay',(x,68.462,29.97),(x+.038,68.474,30.629),gold)
for x,y in ((16.02,65.63),(19.02,65.63),(16.02,68.56),(19.02,68.56)):
 ring('true timber canopy column',x,y,29.26,[(0,.102,.104),(.092,.102,.104),(.160,.071,.074),(1.87,.059,.065),(1.98,.106,.107),(2.06,.117,.110)],oak,12)
 ring('column mid brass binding',x,y,29.26,[(1.78,.068,.072),(1.815,.067,.071)],gold,12)
# Cross lintels and contiguous solid canopy panels rely on the four posts, keep old beam above.
for y in (65.63,68.56):
 box('bed canopy cross lintel',(15.90,y-.105,31.31),(19.14,y+.105,31.46),oak)
for x in (16.02,19.02):
 box('bed canopy side shoulder beam',(x-.105,65.52,31.316),(x+.105,68.665,31.46),oak)
for i in range(8):
 x=16.126+i*.36
 box('canopy joined oak deck plank',(x,65.731,31.39),(x+.35,68.45,31.466),oak)
box('loom-weighted green canopy head valance',(16.13,68.43,31.079),(18.90,68.459,31.306),sea)
box('front woven valance',(16.13,65.536,31.027),(18.90,65.568,31.303),sea)
for i in range(8):
 x=16.20+i*.335
 box('vertical gold stitch in canopy',(x,65.531,31.055),(x+.014,65.537,31.257),gold)
# A solid dressed slab screen changes the layout rather than simulating an operable door.
box('opaque privacy screen backing',(14.32,64.47,F),(14.445,67.80,31.26),sable)
for j in range(10):
 y0=64.475+j*.331
 for k in range(7):
  z=29.023+k*.319
  box('screen projecting dressed panels',(14.296,y0,z),(14.334,y0+.320,z+.304),stone)
box('screen timber coping',(14.279,64.457,31.26),(14.485,67.822,31.344),oak)
box('east facing screen teak backing',(14.43,64.49,29.17),(14.457,67.77,31.25),oak)
for j in range(8):
 y=64.56+.39*j
 box('east screen moulded vertical ribs',(14.458,y,29.20),(14.480,y+.042,31.222),oak)
# Solid-backed integrated walnut window seat and L-desk, under the authentic north opening at its east end.
box('window seating sandstone substructure',(8.24,68.29,F),(11.58,69.43-0.023,29.41),stone)
box('continuous window-seat wood cap',(8.19,68.23,29.41),(11.58,69.40,29.468),oak)
for x,X in ((8.26,9.78),(9.81,11.51)):
 box('wide seat woven cushion',(x,68.32,29.468),(X,69.31,29.571),cel)
for x in (8.60,10.88):
 box('floor-bearing writing inset support',(x,65.28,F),(x+.14,66.24,29.727),stone)
box('continuous writing surface',(8.44,65.24,29.727),(11.19,66.26,29.825),oak)
box('fixed writer seat low timber base',(9.40,64.54,F),(10.00,65.12,29.429),oak)
box('fixed writer seat padded top',(9.38,64.52,29.429),(10.02,65.14,29.533),sea)
# A south-end integrated wardrobe/dressing niche occupies the approved east wall strip.
box('wardrobe grounding stone base',(17.12,57.58,F),(19.29,61.10,29.13),stone)
box('wardrobe rear chestnut backing',(19.17,57.61,29.13),(19.29,61.07,31.23),oak)
for ya,yb in ((57.61,57.73),(59.31,59.435),(60.95,61.07)):
 box('wardrobe grounded hardwood partition',(17.15,ya,29.13),(19.19,yb,31.225),oak)
for ya,yb in ((57.73,59.31),(59.435,60.95)):
 box('wardrobe internal continuous raised deck',(17.194,ya,29.13),(19.18,yb,29.205),oak)
 box('wardrobe working upper shelf',(17.2,ya,30.67),(19.17,yb,30.735),oak)
box('wardrobe broad finished oak cornice',(17.085,57.56,31.227),(19.32,61.13,31.376),oak)
for y in (58.01,58.42,58.87,59.73,60.15,60.62):
 box('wardrobe folded woven linen shelves',(17.48,y,30.735),(18.22,y+.25,30.81),cream if y<59 else cel)
box('wardrobe fixed low storage chest',(17.24,59.48,29.204),(18.93,60.89,29.702),oak)
for name,(loc,target,lens) in S['cameras'].items():
 name='S102 | '+name+' camera';d=bpy.data.cameras.new(name);d.lens=lens;d.clip_start=.05;d.clip_end=1000
 o=bpy.data.objects.new(name,d);C.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();new.append(o.name)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(P/'raw.blend'),compress=False)
(P/'BUILD.json').write_text(json.dumps({'source_sha256':H(src),'scope_sha256':H(P/'S102_BUILD_SCOPE.json'),'raw_sha256':H(P/'raw.blend'),'new_objects':new,'hidden_existing':hidden},indent=2))
