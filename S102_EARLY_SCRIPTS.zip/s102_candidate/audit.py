import bpy,sys,json,pathlib,hashlib
from mathutils import Vector
from mathutils.bvhtree import BVHTree
P=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'s99_candidate/validation_design/history'))
from geometry_core import SceneGeometry
from stair_tools import validate_level_route
src=P.parent/'s101_candidate/candidate.blend';h=hashlib.file_digest(src.open('rb'),'sha256').hexdigest();assert h=='0cac6b9d1217ca881f81af8dfbc8d7a7796841ce46b265b3e981b725db13fe64'
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
G=SceneGeometry(lo=(5.5,54.0,28.7),hi=(31.8,72.4,32.25))
obj={}
for n,g in G.objects.items():
 if n.startswith('S89 | '):obj[n]=[g['vertices'].min(0).tolist(),g['vertices'].max(0).tolist()]
rs=[('private room door to center',[(12.8,55.1),(12.8,63)]),('private room to common hall',[(12.8,63),(12.8,55.1),(6.5,55.1)]),('private route to bathing door',[(12.8,55.1),(29.2,55.1),(29.2,59.23)]),('guest entrance remain distinct',[(22.8,55.1),(22.8,64)])]
routes=[q for n,pts in rs for q in validate_level_route(G,{'id':n,'points':[(x,y,29.008)for x,y in pts],'required_clear_width':1.1,'headroom':2.25})]
vs=[];ts=[];nm=[]
for n,g in G.objects.items():
 ts.extend((g['indices']+len(vs)).tolist());vs.extend(g['vertices'].tolist());nm.extend([n]*len(g['indices']))
b=BVHTree.FromPolygons(vs,ts,all_triangles=True)
def first(p,d,L=6):
 q,_,i,dist=b.ray_cast(Vector(p),Vector(d),L);return None if q is None else [nm[i],list(q),dist]
heights={}
for x in [8.35,9.0,10.5,11.8,12.8,14.2,15.5,17.5,18.8]:
 for y in [57.25,58.6,59.5,60.8,62.15,63.6,64.85,66.6,67.5,68.8]:
  heights[f'{x},{y}']={'up':first((x,y,29.01),(0,0,1)),'floor':first((x,y,29.011),(0,0,-1))}
r={'source_sha256':h,'object_bounds':obj,'routes':routes,'heights_90_evaluated_samples':heights}
(P/'RESIDENCE_AUDIT.json').write_text(json.dumps(r,indent=2,default=lambda x:x.item()))
print([(q['id'],q['passed'])for q in routes])
