#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
test "$(/usr/bin/zstd --version | grep -o '1\.5\.7')" = 1.5.7
/usr/bin/zstd -q -3 --single-thread --no-check -f raw.blend -o candidate.blend
python3 - <<'PY'
import json,hashlib,pathlib
H=lambda f:hashlib.file_digest(open(f,'rb'),'sha256').hexdigest()
p=pathlib.Path('BUILD.json');d=json.loads(p.read_text());assert H('raw.blend')==d['raw_sha256'];d.update(candidate_sha256=H('candidate.blend'),recipe='/usr/bin/zstd v1.5.7 -q -3 --single-thread --no-check -f raw.blend -o candidate.blend');p.write_text(json.dumps(d,indent=2))
PY
