from pathlib import Path
import bpy, math, hashlib, json
from mathutils import Vector
from math import sin,cos,pi
P=Path(__file__).resolve().parent
S=json.loads((P/'S103_BUILD_SCOPE.json').read_text())
src=P.parent/'s102_candidate/candidate.blend'
H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(src)==S['source_sha256']
bpy.ops.wm.open_mainfile(filepath=str(src),use_scripts=False)
sc=bpy.context.scene
C=bpy.data.collections.new('S103 | Gorge-side coastal terrace');sc.collection.children.link(C)
new=[];hidden=[]
for n in S['approved_hide_exact']:
 o=bpy.data.objects[n]; assert not o.hide_render
 o.hide_render=True;o.hide_viewport=True;hidden.append(n)
def material(name,c,rough=.7,met=0,emit=0,tex=None):
 m=bpy.data.materials.new('S103 | '+name);m.diffuse_color=(*c,1);m.use_nodes=True;n=m.node_tree.nodes;l=m.node_tree.links;p=n.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Roughness'].default_value=rough;p.inputs['Metallic'].default_value=met
 if emit:p.inputs['Emission Color'].default_value=(*c,1);p.inputs['Emission Strength'].default_value=emit
 if tex:
  k=n.new('ShaderNodeTexCoord');a=n.new('ShaderNodeTexNoise');a.inputs['Scale'].default_value=2.7;a.inputs['Detail'].default_value=4;l.new(k.outputs['Object'],a.inputs['Vector'])
  r=n.new('ShaderNodeValToRGB');r.color_ramp.elements[0].position=.21;r.color_ramp.elements[0].color=(*(v*.66 for v in c),1);r.color_ramp.elements[1].position=.83;r.color_ramp.elements[1].color=(*(v*1.34 for v in c),1);l.new(a.outputs['Fac'],r.inputs[0]);l.new(r.outputs['Color'],p.inputs['Base Color'])
  f=n.new('ShaderNodeTexNoise');f.inputs['Scale'].default_value=27;f.inputs['Detail'].default_value=3;l.new(k.outputs['Object'],f.inputs['Vector']);b=n.new('ShaderNodeBump');b.inputs['Distance'].default_value=.035;b.inputs['Strength'].default_value=.29;l.new(f.outputs['Fac'],b.inputs['Height']);l.new(b.outputs['Normal'],p.inputs['Normal'])
 return m
def mesh(n,v,f,m,mi=None):
 d=bpy.data.meshes.new('S103 | '+n);d.from_pydata(v,[],f);d.update()
 for a in (m if isinstance(m,list) else [m]):d.materials.append(a)
 if mi:
  for a,i in zip(d.polygons,mi):a.material_index=i
 o=bpy.data.objects.new(d.name,d);C.objects.link(o);new.append(o.name);return o
faces=[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
def box(n,lo,hi,m):
 x,y,z=lo;a,b,c=hi
 return mesh(n,[(x,y,z),(a,y,z),(a,b,z),(x,b,z),(x,y,c),(a,y,c),(a,b,c),(x,b,c)],faces,m)
def ring(n,x,y,base,levels,m,N=12):
 v=[(x+rx*cos(2*pi*i/N+pi/12),y+ry*sin(2*pi*i/N+pi/12),base+z) for z,rx,ry in levels for i in range(N)]
 f=[tuple(range(N-1,-1,-1))]
 for j in range(len(levels)-1):
  a=j*N;b=a+N
  for i in range(N):q=(i+1)%N;f.append((a+i,a+q,b+q,b+i))
 a=(len(levels)-1)*N;f.append(tuple(range(a,a+N)));return mesh(n,v,f,m)
import random
from mathutils.bvhtree import BVHTree
R=random.Random(103)
base=material('coastal warm limestone support',(.42,.34,.255),.8,tex=True)
stone=[material('sawn limestone field '+str(i),tuple(f*v for v in (.48,.41,.30)),.77,tex=True) for i,f in enumerate((.87,.95,1.01,1.09))]
coping=material('oyster limestone coping',(.50,.453,.34),.75,tex=True)
path=material('shell-grit circulation paving',(.52,.485,.39),.82,tex=True)
oxide=material('salted old bronze',(.136,.18,.120),.49,.65)
ter=bpy.data.objects['V002 | western headland with solid rock shore'];dg=bpy.context.evaluated_depsgraph_get();e=ter.evaluated_get(dg);m=e.to_mesh();g=BVHTree.FromPolygons([e.matrix_world@v.co for v in m.vertices],[tuple(p.vertices)for p in m.polygons]);e.to_mesh_clear()
def ground(x,y):
 q,*_=g.ray_cast(Vector((x,y,30)),Vector((0,0,-1)),25);assert q is not None,(x,y);return q.z
# Evaluate and preserve both original edge segments and exact XYZ joints.
seam=S['seam_exact_xyz']
stations=[(tuple(p),(-56.5,p[1],18.22)) for p in seam]
ys=[x[0][1]for x in stations]
def vol_rows(n,rows,material,bury=.12):
 # row points in CCW-up order (+x across row, +y between rows).
 nn=len(rows[0]);mm=len(rows);up=[k for r in rows for k in r];k=len(up)
 low=[(x,y,ground(x,y)-bury)for x,y,z in up];v=up+low
 f=[];bd=[]
 for j in range(mm-1):
  for i in range(nn-1):
   a=j*nn+i;b=a+1;c=a+nn+1;d=a+nn
   f.extend([(a,b,c),(a,c,d),(a+k,c+k,b+k),(a+k,d+k,c+k)])
 bd=list(range(nn))+[j*nn+nn-1 for j in range(1,mm)]+[(mm-1)*nn+i for i in range(nn-2,-1,-1)]+[j*nn for j in range(mm-2,0,-1)]
 for i,a in enumerate(bd):
  b=bd[(i+1)%len(bd)];f.append((a,a+k,b+k,b))
 # Unify low vertices shared by opposite banks of a vertical riser into the same topology.
 # Collapsed bottom triangles have zero area and do not belong to the closed stair B-rep.
 unique=[]; ix={}; mp=[]
 for i,v0 in enumerate(v):
  key=(v0 if i>=k else ('upper',i))
  if key not in ix:ix[key]=len(unique);unique.append(v0)
  mp.append(ix[key])
 polys=[]
 for f0 in f:
  q=list(dict.fromkeys(mp[i]for i in f0))
  if len(q)>=3:polys.append(q)
 return mesh(n,unique,polys,material)
# Rectangularized shared-width approach: both sides follow a true cut-free ground surface.
ap=[]
for j in range(49):
 y=ys[0]+(ys[-1]-ys[0])*j/48
 k=0 if y<=ys[1]else 1;a,b=seam[k:k+2];t=(y-a[1])/(b[1]-a[1])
 xx=a[0]+t*(b[0]-a[0]);zz=a[2]+t*(b[2]-a[2])
 ap.append([(xx+(-56.5-xx)*i/40,y,zz+(18.22-zz)*i/40)for i in range(41)])
# Put seam join on an exact sample row instead of linear interpolation across its kink.
ap.append([(seam[1][0]+(-56.5-seam[1][0])*i/40,ys[1],seam[1][2]+(18.22-seam[1][2])*i/40)for i in range(41)])
ap.sort(key=lambda r:r[0][1])
vol_rows('apron continuously supported and edge conforming',ap,path)
# Monolithic stepped slab with sampled buried underside. Each riser is planar and full width.
ys2=[ys[0]+(ys[-1]-ys[0])*j/36 for j in range(37)]
xs=[(-56.5,18.22)]
for i in range(10):
 x=-56.5+i*.3;z=18.22-(i+1)*.17
 xs.extend([(x,z),(x+.3,z)])
xs.append((-53.5,16.35))
vol_rows('eleven true limestone risers', [[(x,y,z)for x,z in xs]for y in ys2],path)
# Terrace as a continuous, manifold stepped retaining volume. Foundation samples 0.15m into terrain.
A,B=-53.50,-50.95;S0,N=-31.55,-25.55;F=16.35
vol_rows('terrace retaining shell buried to surveyed slope',[[(A+(B-.015-A)*i/22,S0+(N-S0)*j/50,F)for i in range(23)]for j in range(51)],base,.17)
# Subtle projecting masonry bands only on the downhill face. Attach physically; never finish-coplanar with shell.
for k,z in enumerate((14.25,14.88,15.51,16.13)):
 for i in range(9):
  y=S0+.023+i*.658
  if y+.63>N:continue
  box('downhill projecting bonded stone course',(B-.041,y,z),(B-.001,y+.635,min(z+.118,F-.032)),stone[(i+k)%4])
# Railing on the platform perimeter not blocking the stair junction. All posts start on the true floor.
def beam(n,a,b,w,h,mat):
 a=Vector(a);b=Vector(b);d=b-a;d.z=0;d.normalize();v=Vector((-d.y,d.x,0))*w*.5;u=Vector((0,0,h))
 return mesh(n,[tuple(p)for p in (a-v,b-v,b+v,a+v,a-v+u,b-v+u,b+v+u,a+v+u)],faces,mat)
def rail(n,pts, count):
 a=Vector(pts[0]);b=Vector(pts[1]);pv=[]
 for j in range(count+1):
  p=a.lerp(b,j/count);pv.append(p)
  box(n+' grounded newel',(p.x-.071,p.y-.071,p.z),(p.x+.071,p.y+.071,p.z+1.10),stone[j%4])
 for i,(a,b) in enumerate(zip(pv,pv[1:])):
  for z in (.38,.76,1.026):
   a1=a+Vector((0,0,z));b1=b+Vector((0,0,z))
   beam(n+' warm rail',a1,b1,.064,.071,oxide)
rail('water facing continuous guard',[(B-.13,S0+.14,F),(B-.13,N-.14,F)],8)
rail('south terrace continuous guard',[(A+.125,S0+.14,F),(B-.24,S0+.14,F)],4)
rail('north terrace continuous guard',[(A+.125,N-.14,F),(B-.24,N-.14,F)],4)
rail('south uphill terrace short guard',[(A+.126,S0+.25,F),(A+.126,ys[0]-.15,F)],2)
rail('north uphill terrace short guard',[(A+.126,ys[-1]+.15,F),(A+.126,N-.25,F)],2)
# Outside the central clear width, the edge rails have continuously graded rise.
for k,dy in ((0,.125),(-1,-.125)):
 s=seam[k]; y=s[1]+dy
 # Reference ground-side apron top follows evaluated x-y interpolation, and step base is the actual tread top.
 lo=s[0]+.23
 emb=[(lo,y,s[2]+.020),(-56.55,y,18.218)]
 rail('apron side continuous guard',emb,4)
 pts=[(-56.35+i*.3,y,18.22-(i+1)*.17)for i in range(10)]
 # Guard connection from approach to each stair midpoint; retain 1100mm+ between newels.
 for i,p in enumerate(pts):
  x,y,z=p
  box('stair stone bearing guard post',(x-.06,y-.06,z),(x+.06,y+.06,z+1.10),stone[i%4])
 for a,b in zip(pts,pts[1:]):
  for z in (.38,.76,1.015):
   beam('stair descending continuous bronze rail',(a[0],a[1],a[2]+z),(b[0],b[1],b[2]+z),.065,.07,oxide)
 # Carry top guard through the final drop down to the corresponding protected platform side.
 for a,b in [(pts[-1],(A+.19,y,F)),((-56.55,y,18.218),pts[0])]:
  for z in (.38,.76,1.015):beam('stair terminal guard link',(a[0],a[1],a[2]+z),(b[0],b[1],b[2]+z),.064,.072,oxide)
# Single reachable bench set against the south guard, not in turning square.
for x in (-52.73,-51.89):box('grounded rest bench end',(x,-31.30,F),(x+.16,-30.89,F+.405),base)
box('continuous seat',(-52.80,-31.31,F+.405),(-51.68,-30.88,F+.49),coping)
for name,(loc,target,lens) in S['cameras'].items():
 name='S103 | '+name+' camera';d=bpy.data.cameras.new(name);d.lens=lens;d.clip_start=.07;d.clip_end=1000
 o=bpy.data.objects.new(name,d);C.objects.link(o);o.location=loc;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();new.append(o.name)
bpy.context.preferences.filepaths.save_version=0
bpy.ops.wm.save_as_mainfile(filepath=str(P/'raw.blend'),compress=False)
(P/'BUILD.json').write_text(json.dumps({'source_sha256':H(src),'scope_sha256':H(P/'S103_BUILD_SCOPE.json'),'raw_sha256':H(P/'raw.blend'),'new_objects':new,'hidden_existing':hidden},indent=2))
